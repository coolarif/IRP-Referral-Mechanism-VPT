#!/usr/bin/env python3
"""
m_mutation_test.py - does the M execution test (verify.run_m_exec) really notice broken M code?

Each case below damages the delivered M text in one small way (a misspelled column, a wrong denominator, a removed
null test, ...).  Every damaged version must make run_m_exec() fail; the undamaged text must pass.  Takes ~8 minutes.
"""
import contextlib
import io
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import build_workbook as B                             # noqa: E402
import gen_data as L                                   # noqa: E402
import verify as V                                     # noqa: E402

K = B.KP.build_kpis(L)
texts, _notes = B.code_file_texts(K)
F1, F2, F3, F5 = (B.CODE_FILES[k_] for k_ in ('referrals', 'summary', 'single', 'calendar'))
def mut(fname, old, new, nth=1):
    t = dict(texts); s = t[fname]
    assert s.count(old) >= nth, (fname, old)
    pos = -1
    for _ in range(nth):
        pos = s.index(old, pos + 1)
    t[fname] = s[:pos] + new + s[pos + len(old):]
    return t
cases = {
 'summary: misspelled column name':            mut(F2, 'each [Referral Priority] = "Emergency")', 'each [Referral Prioroty] = "Emergency")'),
 'summary: wrong value in one KPI':            mut(F2, '"Whole number", CountIf(each [Referral Priority] = "Emergency")}', '"Whole number", CountIf(each [Referral Priority] = "Routine")}'),
 'summary: wrong denominator (HF refusal)':    mut(F2, 'Ratio(CountIf(each [Refusal from HF] = "Yes"), CountIf(each [Referral Accepted] = "Yes"))', 'Ratio(CountIf(each [Refusal from HF] = "Yes"), Total)'),
 'summary: Patient ID filter removed':         mut(F2, 'Table.SelectRows(NoErrors, each [Patient ID] <> null and [Patient ID] <> "")', 'NoErrors'),
 'summary: error replacement removed':         mut(F2, 'Source = Table.Buffer(Table.SelectRows(NoErrors,', 'Source = Table.Buffer(Table.SelectRows(Typed,'),
 'summary: null test removed from a condition': mut(F2, '([Age] <> null and [Age] < 20)', '([Age] < 20)'),
 'summary: tie-break / sort order reversed':    mut(F2, '{"Referrals", Order.Descending}', '{"Referrals", Order.Ascending}'),
 'summary: null dates not removed':             mut(F2, 'List.Max(Values("Date of visit"))', 'List.Max(Table.Column(Source, "Date of visit"))'),
 'summary: unknown function name':             mut(F2, 'List.Median(Values("Age"))', 'List.Medians(Values("Age"))'),
 'summary: wrong argument count':              mut(F2, 'Total = Table.RowCount(Source),', 'Total = Table.RowCount(Source, 1),'),
 'summary: >= changed to > (age 35+)':         mut(F2, '[Age] >= 35', '[Age] > 35'),
 'summary: display format swapped':            mut(F2, 'Number.ToText(value, "0.0%", "en-US")', 'Number.ToText(value, "0.0", "en-US")'),
 'summary: nulls not removed before average':  mut(F2, 'List.Select(Table.Column(Source, columnName), each _ <> null and _ <> "")', 'Table.Column(Source, columnName)'),
 'single: misspelled column in KPI 12':        mut(F3, '[Referral Priority] = "Emergency"', '[Referal Priority] = "Emergency"', 2),
 'single: wrong month arithmetic':             mut(F3, 'Date.AddMonths(CurStart, -1)', 'Date.AddMonths(CurStart, -2)'),
 'single: both-dates filter removed':          mut(F3, 'Both = Table.SelectRows(Source, each [Date of visit] <> null and [Date of Enrollment] <> null),', 'Both = Source,'),
 'calendar: date conversion removed':           mut(F5, 'Visits = Table.TransformColumnTypes(Table.SelectColumns(Referrals, {"Date of visit"}), {{"Date of visit", type date}}),', 'Visits = Table.SelectColumns(Referrals, {"Date of visit"}),'),
 'calendar: error replacement removed':         mut(F5, 'VisitDates = List.RemoveNulls(NoErrors[Date of visit])', 'VisitDates = List.RemoveNulls(Visits[Date of visit])'),
 'calendar: nulls not removed':                 mut(F5, 'VisitDates = List.RemoveNulls(NoErrors[Date of visit])', 'VisitDates = NoErrors[Date of visit]'),
 'calendar: one day too few':                   mut(F5, 'DayCount = Duration.Days(LastDate - FirstDate) + 1,', 'DayCount = Duration.Days(LastDate - FirstDate),'),
 'referrals: file name of the workbook wrong':  mut(F1, B.WORKBOOK_NAME + '",', 'Maternal_Referral_Dashboard.xlsx",'),
 'referrals: MissingField.Ignore removed':     mut(F1, '}, MissingField.Ignore),', '}),'),
 'referrals: misspelled column in type list':  mut(F1, '{"Age", Int64.Type}', '{"Agee", Int64.Type}'),
 'referrals: error replacement removed':       mut(F1, 'Table.TransformColumns(NoErrors, List.Transform(TextColumns,', 'Table.TransformColumns(Typed, List.Transform(TextColumns,'),
 'referrals: rows without Patient ID kept':    mut(F1, 'NonEmpty = Table.SelectRows(Cleaned, each [Patient ID] <> null),', 'NonEmpty = Cleaned,'),
 'referrals: spelling fix removed':            mut(F1, 'Preeclampcia = "Preeclampsia",', 'Preeclampcia = "Preeclampcia",'),
 'referrals: trim removed':                    mut(F1, 'then null else Text.Trim(_), type text', 'then null else _, type text'),
}
caught = missed = 0
for name, t in cases.items():
    if t is None:
        print('SKIPPED (pattern not found):', name); continue
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        try:
            ok = V.run_m_exec(t)
        except Exception as e:
            ok = False; print('EXCEPTION', type(e).__name__, e)
    fails = [l for l in buf.getvalue().splitlines() if 'FAIL' in l or 'EXCEPTION' in l]
    if ok:
        missed += 1; print(f'NOT NOTICED: {name}')
    else:
        caught += 1; print(f'noticed    : {name:45s} -> {len(fails)} failing checks, e.g. {fails[0][7:150] if fails else "?"}')
print(f'mutations noticed={caught} not noticed={missed}')
buf = io.StringIO()
with contextlib.redirect_stdout(buf):
    ok = V.run_m_exec(texts)
print('unmodified text passes:', ok)
