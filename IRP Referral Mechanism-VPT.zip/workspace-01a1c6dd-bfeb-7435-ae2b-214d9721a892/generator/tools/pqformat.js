// Pretty-print Power Query M snippets with Microsoft's official formatter.
// usage: node pqformat.js in.json out.json   (in.json = [{"name": "...", "code": "..."}, ...])
const F = require("@microsoft/powerquery-formatter");
const fs = require("fs");
(async () => {
  const items = JSON.parse(fs.readFileSync(process.argv[2], "utf8"));
  const out = [];
  for (const it of items) {
    let ok = false, text = "";
    try {
      const r = await F.tryFormat(F.DefaultSettings, it.code);
      ok = r.kind === "Ok";
      text = ok ? r.value : String((r.error && r.error.message) || r.error);
    } catch (e) {
      text = String(e && e.message || e);
    }
    out.push({ name: it.name, ok: ok, text: text });
  }
  fs.writeFileSync(process.argv[3], JSON.stringify(out));
  console.log(`formatted=${out.filter(o => o.ok).length} failed=${out.filter(o => !o.ok).length}`);
})();
