// Syntax-check Power Query M snippets with Microsoft's official parser.
// usage: node pqcheck.js file.json   (file.json = [{"name": "...", "code": "..."}, ...])
const PQP = require("@microsoft/powerquery-parser");
const fs = require("fs");
(async () => {
  const items = JSON.parse(fs.readFileSync(process.argv[2], "utf8"));
  let bad = 0;
  for (const it of items) {
    const task = await PQP.TaskUtils.tryLexParse(PQP.DefaultSettings, it.code);
    if (PQP.TaskUtils.isParseStageOk(task)) {
      // ok
    } else {
      bad++;
      let msg = "";
      if (task.error) msg = (task.error.innerError && task.error.innerError.message) || task.error.message || String(task.error);
      console.log("FAIL:", it.name, "=>", msg);
    }
  }
  console.log(`checked=${items.length} failed=${bad}`);
})();
