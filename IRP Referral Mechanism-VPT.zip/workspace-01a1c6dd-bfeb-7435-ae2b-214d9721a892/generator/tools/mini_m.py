#!/usr/bin/env python3
"""
mini_m.py - a small interpreter for the subset of the Power Query M language used by this project's queries.

Why it exists: Power BI / Excel (the real M engine) is not available where the workbook is generated.  To make sure the
generated M code at least *runs* and returns the right numbers, the queries are executed here against the register
data and compared with values calculated independently in Python.

What it is NOT: Microsoft's engine.  It implements the M language rules that matter for these queries (lazy "let",
each / implicit field access, null propagation, three-valued logic, strict operator typing, cell-level errors) and
about 80 library functions.  Every call to a library function is validated against Microsoft's published signatures
(m_library.json, extracted from github.com/microsoft/vscode-powerquery): unknown names, wrong argument counts and wrong
argument types raise an error.  Behaviour the real engine leaves undocumented is refused (MUnsupported) rather than
guessed - e.g. List.Average over a list that still contains nulls.
"""
import datetime as dt
import json
import math
import os
import re
from decimal import Decimal, ROUND_HALF_UP

HERE = os.path.dirname(os.path.abspath(__file__))


class MRuntimeError(Exception):
    """An error the M engine would raise (Expression.Error, DataFormat.Error, ...)."""


class MUnsupported(Exception):
    """A language feature / library behaviour this mini interpreter does not implement."""


# =====================================================================================================================
# values
# =====================================================================================================================
class MErrorValue:
    """A cell-level error (what Power Query shows as 'Error' in a cell)."""
    __slots__ = ('msg',)

    def __init__(self, msg):
        self.msg = msg

    def __repr__(self):
        return f'<Error {self.msg}>'


class MRecord(dict):
    pass


class MBinary:
    def __init__(self, path):
        self.path = path


class MType:
    def __init__(self, kind, nullable=False, facet=None, columns=None):
        self.kind, self.nullable, self.facet, self.columns = kind, nullable, facet, columns

    def __repr__(self):
        return f'type {"nullable " if self.nullable else ""}{self.facet or self.kind}'


class MTable:
    """Rows are shared between tables and never mutated in place."""

    def __init__(self, columns, rows, types=None):
        self.columns = list(columns)
        if len(set(self.columns)) != len(self.columns):
            raise MRuntimeError('A table cannot have two columns with the same name.')
        self.rows = rows if isinstance(rows, list) else list(rows)
        self.types = dict(types or {})
        self._records = None
        self._index = {c: i for i, c in enumerate(self.columns)}

    def records(self):
        if self._records is None:
            cols = self.columns
            self._records = [MRecord(zip(cols, r)) for r in self.rows]
        return self._records

    def col(self, name):
        if name not in self._index:
            raise MRuntimeError(f"The column '{name}' of the table wasn't found.")
        return self._index[name]

    def column_values(self, name):
        i = self.col(name)
        out = [r[i] for r in self.rows]
        for v in out:
            if isinstance(v, MErrorValue):
                raise MRuntimeError(v.msg)
        return out


class MFunction:
    def __init__(self, interp, params, ret, body, env, name='function'):
        self.interp, self.params, self.ret, self.body, self.env, self.name = interp, params, ret, body, env, name
        self.n_required = sum(1 for p in params if not p[2])


class MBuiltin:
    def __init__(self, name, fn, sig):
        self.name, self.fn, self.sig = name, fn, sig


def kind_of(v):
    if v is None:
        return 'null'
    if isinstance(v, bool):
        return 'logical'
    if isinstance(v, (int, float)):
        return 'number'
    if isinstance(v, str):
        return 'text'
    if isinstance(v, dt.datetime):
        return 'datetime'
    if isinstance(v, dt.date):
        return 'date'
    if isinstance(v, dt.timedelta):
        return 'duration'
    if isinstance(v, list):
        return 'list'
    if isinstance(v, MRecord):
        return 'record'
    if isinstance(v, MTable):
        return 'table'
    if isinstance(v, (MFunction, MBuiltin)):
        return 'function'
    if isinstance(v, MType):
        return 'type'
    if isinstance(v, MBinary):
        return 'binary'
    if isinstance(v, MErrorValue):
        raise MRuntimeError(v.msg)
    raise MUnsupported(f'unknown python value {type(v)}')


def cap(kind):
    return {'datetime': 'DateTime'}.get(kind, kind.capitalize())


def m_eq(a, b):
    ka, kb = kind_of(a), kind_of(b)
    if ka != kb:
        return False
    if ka == 'list':
        return len(a) == len(b) and all(m_eq(x, y) for x, y in zip(a, b))
    if ka == 'record':
        return set(a) == set(b) and all(m_eq(a[k], b[k]) for k in a)
    if ka in ('table', 'function', 'type', 'binary'):
        return a is b
    return a == b


ORDERED = ('number', 'text', 'date', 'datetime', 'duration', 'logical')


def m_rel(op, a, b):
    if a is None or b is None:
        return None                                     # M: a relational operator with a null operand returns null
    ka, kb = kind_of(a), kind_of(b)
    if ka != kb or ka not in ORDERED:
        raise MRuntimeError(f'We cannot apply operator {op} to types {cap(ka)} and {cap(kb)}.')
    if op == '<':
        return a < b
    if op == '<=':
        return a <= b
    if op == '>':
        return a > b
    return a >= b


def hkey(v):
    """Hashable key that follows M equality (1 = 1.0, but 1 <> true and 1 <> "1")."""
    k = kind_of(v)
    if k == 'list':
        return (k, tuple(hkey(x) for x in v))
    if k == 'record':
        return (k, tuple(sorted((n, hkey(x)) for n, x in v.items())))
    return (k, v)


# =====================================================================================================================
# lexer
# =====================================================================================================================
KEYWORDS = {'and', 'as', 'each', 'else', 'error', 'false', 'if', 'in', 'is', 'let', 'meta', 'not', 'null', 'or', 'otherwise',
            'section', 'shared', 'then', 'true', 'try', 'type'}
TOKEN_RE = re.compile(r'''
    (?P<ws>\s+) |
    (?P<lc>//[^\n]*) |
    (?P<bc>/\*.*?\*/) |
    (?P<qid>\#"(?:[^"]|"")*") |
    (?P<str>"(?:[^"]|"")*") |
    (?P<hash>\#[a-z]+) |
    (?P<num>(?:\d+\.\d+|\d+)(?:[eE][+-]?\d+)?) |
    (?P<id>[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*) |
    (?P<op>=>|<=|>=|<>|\.\.\.|\.\.|\?\?|[,;=<>+\-*/&()\[\]{}@?!])
''', re.S | re.X)


class Tok:
    __slots__ = ('kind', 'val', 'start', 'end', 'quoted')

    def __init__(self, kind, val, start, end, quoted=False):
        self.kind, self.val, self.start, self.end, self.quoted = kind, val, start, end, quoted

    def __repr__(self):
        return f'{self.kind}:{self.val!r}'


def tokenize(src):
    toks, pos = [], 0
    while pos < len(src):
        m = TOKEN_RE.match(src, pos)
        if not m:
            raise SyntaxError(f'M lexer: unexpected character {src[pos]!r} at {pos}: {src[max(0, pos - 30):pos + 30]!r}')
        kind = m.lastgroup
        text = m.group()
        if kind in ('ws', 'lc', 'bc'):
            pass
        elif kind == 'qid':
            toks.append(Tok('id', text[2:-1].replace('""', '"'), m.start(), m.end(), True))
        elif kind == 'str':
            toks.append(Tok('str', text[1:-1].replace('""', '"'), m.start(), m.end()))
        elif kind == 'hash':
            toks.append(Tok('id', text, m.start(), m.end()))
        elif kind == 'num':
            toks.append(Tok('num', float(text) if re.search(r'[.eE]', text) else int(text), m.start(), m.end()))
        elif kind == 'id':
            toks.append(Tok('kw' if text in KEYWORDS else 'id', text, m.start(), m.end()))
        else:
            toks.append(Tok('op', text, m.start(), m.end()))
        pos = m.end()
    toks.append(Tok('eof', None, len(src), len(src)))
    return toks


# =====================================================================================================================
# parser  ->  nested tuples
# =====================================================================================================================
PRIMS = {'any', 'anynonnull', 'binary', 'date', 'datetime', 'datetimezone', 'duration', 'function', 'list', 'logical', 'none',
         'null', 'number', 'record', 'table', 'text', 'time', 'type'}


class Parser:
    def __init__(self, src):
        self.src = src
        self.toks = tokenize(src)
        self.i = 0

    # ---- token helpers
    def peek(self, k=0):
        return self.toks[min(self.i + k, len(self.toks) - 1)]

    def next(self):
        t = self.toks[self.i]
        self.i += 1
        return t

    def at_op(self, v, k=0):
        t = self.peek(k)
        return t.kind == 'op' and t.val == v

    def at_kw(self, v):
        t = self.peek()
        return t.kind == 'kw' and t.val == v

    def accept_op(self, v):
        if self.at_op(v):
            self.i += 1
            return True
        return False

    def fail(self, what):
        t = self.peek()
        raise SyntaxError(f'M parser: expected {what} but found {t!r} near {self.src[max(0, t.start - 40):t.start + 40]!r}')

    def expect_op(self, v):
        if not self.accept_op(v):
            self.fail(repr(v))

    def expect_kw(self, v):
        if not self.at_kw(v):
            self.fail(v)
        self.i += 1

    # ---- entry
    def parse_document(self):
        e = self.parse_expression()
        if self.peek().kind != 'eof':
            self.fail('end of expression')
        return e

    def parse_expression(self):
        t = self.peek()
        if t.kind == 'kw':
            if t.val == 'let':
                return self.parse_let()
            if t.val == 'if':
                self.next()
                c = self.parse_expression()
                self.expect_kw('then')
                a = self.parse_expression()
                self.expect_kw('else')
                return ('if', c, a, self.parse_expression())
            if t.val == 'each':
                self.next()
                return ('each', self.parse_expression())
            if t.val in ('try', 'error', 'section', 'shared'):
                raise MUnsupported(f'"{t.val}" expressions are not implemented in the mini interpreter')
        if t.kind == 'op' and t.val == '(' and self.is_function_literal():
            return self.parse_function()
        return self.parse_or()

    def parse_let(self):
        self.expect_kw('let')
        binds = []
        while True:
            t = self.next()
            if t.kind != 'id':
                self.i -= 1
                self.fail('a variable name')
            self.expect_op('=')
            binds.append((t.val, self.parse_expression()))
            if not self.accept_op(','):
                break
        self.expect_kw('in')
        return ('let', binds, self.parse_expression())

    def is_function_literal(self):
        depth, j = 0, self.i
        while True:
            t = self.toks[j]
            if t.kind == 'eof':
                return False
            if t.kind == 'op' and t.val in '([{':
                depth += 1
            elif t.kind == 'op' and t.val in ')]}':
                depth -= 1
                if depth == 0:
                    break
            j += 1
        nxt = self.toks[j + 1]
        if nxt.kind == 'op' and nxt.val == '=>':
            return True
        if nxt.kind == 'kw' and nxt.val == 'as':
            k = j + 2
            if self.toks[k].kind == 'id' and self.toks[k].val == 'nullable':
                k += 1
            return self.toks[k + 1].kind == 'op' and self.toks[k + 1].val == '=>'
        return False

    def parse_function(self):
        self.expect_op('(')
        params = []
        while not self.at_op(')'):
            optional = False
            t = self.next()
            if t.kind == 'id' and t.val == 'optional' and self.peek().kind == 'id':
                optional, t = True, self.next()
            if t.kind != 'id':
                self.i -= 1
                self.fail('a parameter name')
            typ = None
            if self.at_kw('as'):
                self.next()
                typ = self.parse_nullable_primitive_type()
            params.append((t.val, typ, optional))
            if not self.accept_op(','):
                break
        self.expect_op(')')
        ret = None
        if self.at_kw('as'):
            self.next()
            ret = self.parse_nullable_primitive_type()
        self.expect_op('=>')
        return ('func', params, ret, self.parse_expression())

    # ---- operators (lowest precedence first)
    def parse_or(self):
        left = self.parse_and()
        while self.at_kw('or'):
            self.next()
            left = ('or', left, self.parse_and())
        return left

    def parse_and(self):
        left = self.parse_is()
        while self.at_kw('and'):
            self.next()
            left = ('and', left, self.parse_is())
        return left

    def parse_is(self):
        left = self.parse_as()
        while self.at_kw('is'):
            self.next()
            left = ('is', left, self.parse_nullable_primitive_type())
        return left

    def parse_as(self):
        left = self.parse_equality()
        while self.at_kw('as'):
            self.next()
            left = ('as', left, self.parse_nullable_primitive_type())
        return left

    def _binary(self, ops, sub):
        left = sub()
        while self.peek().kind == 'op' and self.peek().val in ops:
            op = self.next().val
            left = ('bin', op, left, sub())
        return left

    def parse_equality(self):
        return self._binary(('=', '<>'), self.parse_relational)

    def parse_relational(self):
        return self._binary(('<', '<=', '>', '>='), self.parse_additive)

    def parse_additive(self):
        return self._binary(('+', '-', '&'), self.parse_multiplicative)

    def parse_multiplicative(self):
        return self._binary(('*', '/'), self.parse_unary)

    def parse_unary(self):
        t = self.peek()
        if t.kind == 'op' and t.val in ('+', '-'):
            self.next()
            return ('unary', t.val, self.parse_unary())
        if t.kind == 'kw' and t.val == 'not':
            self.next()
            return ('unary', 'not', self.parse_unary())
        if t.kind == 'kw' and t.val == 'type':
            self.next()
            return ('typeexpr', self.parse_type())
        return self.parse_postfix()

    def parse_postfix(self):
        e = self.parse_primary()
        while True:
            if self.at_op('('):
                self.next()
                args = []
                while not self.at_op(')'):
                    args.append(self.parse_expression())
                    if not self.accept_op(','):
                        break
                self.expect_op(')')
                e = ('call', e, args)
            elif self.at_op('{'):
                self.next()
                idx = self.parse_expression()
                self.expect_op('}')
                e = ('item', e, idx, self.accept_op('?'))
            elif self.at_op('['):
                name = self.parse_field_selector()
                e = ('field', e, name, self.accept_op('?'))
            else:
                return e

    def parse_primary(self):
        t = self.peek()
        if t.kind == 'num':
            self.next()
            return ('num', t.val)
        if t.kind == 'str':
            self.next()
            return ('str', t.val)
        if t.kind == 'kw' and t.val in ('null', 'true', 'false'):
            self.next()
            return ('null',) if t.val == 'null' else ('bool', t.val == 'true')
        if t.kind == 'id':
            self.next()
            return ('id', t.val)
        if t.kind == 'op' and t.val == '(':
            self.next()
            e = self.parse_expression()
            self.expect_op(')')
            return e
        if t.kind == 'op' and t.val == '{':
            self.next()
            items = []
            while not self.at_op('}'):
                items.append(self.parse_expression())
                if self.at_op('..'):
                    raise MUnsupported('list ranges (..) are not implemented')
                if not self.accept_op(','):
                    break
            self.expect_op('}')
            return ('list', items)
        if t.kind == 'op' and t.val == '[':
            if self.is_record_literal():
                return self.parse_record()
            name = self.parse_field_selector()
            return ('ifield', name, self.accept_op('?'))
        if t.kind == 'op' and t.val == '...':
            self.next()
            return ('notimpl',)
        self.fail('an expression')

    def is_record_literal(self):
        """'[' starts a record literal when it is empty or has a top-level '=' before its closing bracket."""
        if self.at_op(']', 1):
            return True
        depth, j = 0, self.i + 1
        while True:
            t = self.toks[j]
            if t.kind == 'eof':
                return False
            if t.kind == 'op':
                if t.val in '([{':
                    depth += 1
                elif t.val in ')]}':
                    if depth == 0:
                        return False
                    depth -= 1
                elif t.val == '=' and depth == 0:
                    return True
            j += 1

    def generalized_name(self, stops):
        """Field name: a quoted identifier or keyword/identifier parts separated by blanks, up to one of the stop operators."""
        first = self.peek()
        if first.kind == 'id' and first.quoted:
            self.next()
            return first.val
        parts = []
        while not (self.peek().kind == 'op' and self.peek().val in stops):
            t = self.next()
            if t.kind not in ('id', 'kw', 'num'):
                self.i -= 1
                self.fail('a field name')
            parts.append(self.src[t.start:t.end])
        if not parts:
            self.fail('a field name')
        return ' '.join(parts)

    def parse_field_selector(self):
        self.expect_op('[')
        if self.at_op('['):
            raise MUnsupported('field projection [[a],[b]] is not implemented')
        name = self.generalized_name((']',))
        self.expect_op(']')
        return name

    def parse_record(self):
        self.expect_op('[')
        fields = []
        while not self.at_op(']'):
            name = self.generalized_name(('=',))
            self.expect_op('=')
            fields.append((name, self.parse_expression()))
            if not self.accept_op(','):
                break
        self.expect_op(']')
        return ('record', fields)

    # ---- types
    def parse_nullable_primitive_type(self):
        nullable = False
        t = self.next()
        if t.kind == 'id' and t.val == 'nullable':
            nullable, t = True, self.next()
        if t.val not in PRIMS:
            self.i -= 1
            self.fail('a primitive type name')
        return ('prim', t.val, nullable)

    def parse_type(self):
        t = self.peek()
        if t.kind == 'id' and t.val == 'nullable':
            self.next()
            return ('nullable', self.parse_type())
        if t.kind == 'id' and t.val == 'table':
            self.next()
            if self.at_op('['):
                return ('tabletype', self.parse_field_specs())
            return ('prim', 'table', False)
        if t.kind == 'op' and t.val == '[':
            return ('recordtype', self.parse_field_specs())
        if t.kind == 'op' and t.val == '{':
            self.next()
            inner = self.parse_type()
            self.expect_op('}')
            return ('listtype', inner)
        if (t.kind == 'id' and t.val in PRIMS) or (t.kind == 'kw' and t.val in ('null', 'type')):
            self.next()
            return ('prim', t.val, False)
        return ('texpr', self.parse_postfix())

    def parse_field_specs(self):
        self.expect_op('[')
        specs = []
        while not self.at_op(']'):
            name = self.generalized_name(('=',))
            self.expect_op('=')
            specs.append((name, self.parse_type()))
            if not self.accept_op(','):
                break
        self.expect_op(']')
        return specs


# =====================================================================================================================
# environment
# =====================================================================================================================
class Thunk:
    __slots__ = ('expr', 'env', 'val', 'state', 'interp', 'name')

    def __init__(self, interp, expr, env, name):
        self.interp, self.expr, self.env, self.name, self.state, self.val = interp, expr, env, name, 0, None

    def get(self):
        if self.state == 2:
            return self.val
        if self.state == 1:
            raise MRuntimeError(f"A cyclic reference was encountered during evaluation ('{self.name}').")
        self.state = 1
        try:
            # inside its own initialiser a variable / field is not in scope: the name refers to the enclosing scope
            self.val = self.interp.ev(self.expr, Env(self.env, hidden=self.name))
        except Exception:
            self.state = 0
            raise
        self.state = 2
        return self.val


class Env:
    __slots__ = ('vars', 'parent', 'hidden')

    def __init__(self, parent=None, vars_=None, hidden=None):
        self.vars = vars_ if vars_ is not None else {}
        self.parent = parent
        self.hidden = hidden          # name that must be resolved one scope further out (see Thunk)

    def lookup(self, name):
        e = self
        skip = None
        while e is not None:
            if e.hidden is not None and name == e.hidden:
                skip = e.parent       # the scope that defines the variable currently being initialised
            elif name in e.vars and e is not skip:
                v = e.vars[name]
                return v.get() if type(v) is Thunk else v
            e = e.parent
        raise MRuntimeError(f"The name '{name}' wasn't recognized. Make sure it's spelled correctly.")


# =====================================================================================================================
# conversions used by Table.TransformColumnTypes / *.From
# =====================================================================================================================
OLE_EPOCH = dt.datetime(1899, 12, 30)


class ConversionError(Exception):
    pass


def number_text(x):
    if isinstance(x, float) and x.is_integer() and abs(x) < 1e15:
        return str(int(x))
    return repr(x) if isinstance(x, float) else str(x)


def to_text(v):
    k = kind_of(v)
    if k == 'text':
        return v
    if k == 'number':
        return number_text(v)
    if k == 'logical':
        return 'true' if v else 'false'
    if k in ('date', 'datetime', 'duration'):
        raise MUnsupported('converting a date/datetime/duration to text depends on the regional settings - not implemented')
    raise ConversionError(f'We cannot convert a value of type {cap(k)} to type Text.')


def to_number(v):
    k = kind_of(v)
    if k == 'number':
        return v
    if k == 'logical':
        return 1 if v else 0
    if k == 'text':
        s = v.strip()
        if re.fullmatch(r'[+-]?(\d+(\.\d*)?|\.\d+)([eE][+-]?\d+)?', s):
            return float(s) if re.search(r'[.eE]', s) else int(s)
        if re.fullmatch(r'[+-]?(\d+(\.\d*)?|\.\d+)\s*%', s):
            return float(Decimal(s.rstrip('%').strip()) / 100)
        raise ConversionError("DataFormat.Error: We couldn't convert to Number.")
    if k == 'datetime':
        return (v - OLE_EPOCH).total_seconds() / 86400
    if k == 'date':
        return (dt.datetime(v.year, v.month, v.day) - OLE_EPOCH).days
    raise ConversionError(f'We cannot convert a value of type {cap(k)} to type Number.')


def to_int64(v):
    n = to_number(v)
    if isinstance(n, float):
        if math.isnan(n) or math.isinf(n):
            raise ConversionError('The number is out of range of a 64 bit integer value.')
        n = int(round(n))                              # Int64.From rounds half to even, like Python's round()
    return n


def to_date(v):
    k = kind_of(v)
    if k == 'date':
        return v
    if k == 'datetime':
        return v.date()
    if k == 'number':
        return (OLE_EPOCH + dt.timedelta(days=float(v))).date()
    if k == 'text':
        s = v.strip()
        m = re.fullmatch(r'(\d{4})-(\d{1,2})-(\d{1,2})', s)
        if m:
            try:
                return dt.date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
            except ValueError:
                pass
        elif re.search(r'\d', s) and re.fullmatch(r'[\d\s./\-:A-Za-z,]+', s):
            raise MUnsupported(f'parsing the text {v!r} as a date depends on the regional settings - not implemented')
        raise ConversionError("DataFormat.Error: We couldn't parse the input provided as a Date value.")
    raise ConversionError(f'We cannot convert a value of type {cap(k)} to type Date.')


def convert_cell(v, t):
    if v is None or isinstance(v, MErrorValue):
        return v
    try:
        if t.kind == 'any':
            return v
        if t.kind == 'text':
            return to_text(v)
        if t.kind == 'number':
            return to_int64(v) if t.facet == 'Int64' else to_number(v)
        if t.kind == 'date':
            return to_date(v)
        if t.kind == 'datetime':
            if isinstance(v, dt.datetime):
                return v
            d = to_date(v)                                # text that is not a date -> ConversionError -> error cell
            return dt.datetime(d.year, d.month, d.day)
        if t.kind == 'logical':
            if isinstance(v, bool):
                return v
            raise MUnsupported('conversion to logical is not implemented')
    except ConversionError as e:
        return MErrorValue(str(e))
    raise MUnsupported(f'conversion to {t!r} is not implemented')


# ---------------------------------------------------------------------------------------------------------------------
# .NET style formatting (only the patterns the queries use)
# ---------------------------------------------------------------------------------------------------------------------
def _fixed(x, digits):
    d = Decimal(repr(float(x))) if isinstance(x, float) else Decimal(x)
    return d.quantize(Decimal(1).scaleb(-digits), rounding=ROUND_HALF_UP)       # .NET rounds midpoints away from zero


def net_number_format(x, fmt):
    if fmt == '0.0%':
        d = Decimal(repr(float(x))) * 100
        return f'{d.quantize(Decimal("0.1"), rounding=ROUND_HALF_UP)}%'
    if fmt == '#,##0':
        return f'{int(_fixed(x, 0)):,}'
    if fmt == '0.0':
        return str(_fixed(x, 1))
    if fmt == '0.00':
        return str(_fixed(x, 2))
    raise MUnsupported(f'number format {fmt!r} is not implemented in the mini interpreter')


def net_date_format(d, fmt):
    table = [('yyyy', '%Y'), ('MMMM', '%B'), ('MMM', '%b'), ('MM', '%m'), ('dddd', '%A'), ('ddd', '%a'), ('dd', '%d')]
    out, i = '', 0
    while i < len(fmt):
        for net, py in table:
            if fmt.startswith(net, i):
                out += d.strftime(py)
                i += len(net)
                break
        else:
            if fmt[i].isalpha():
                raise MUnsupported(f'date format {fmt!r} is not implemented in the mini interpreter')
            out += fmt[i]
            i += 1
    return out


# =====================================================================================================================
# interpreter
# =====================================================================================================================
class Interp:
    def __init__(self, files=None, queries=None):
        self.signatures = json.load(open(os.path.join(HERE, 'm_library.json')))
        self.files = files or {}                         # path -> MTable returned by Excel.Workbook
        self.globals = Env()
        self.used = {}                                   # library symbol -> number of calls / references
        self._install_library()
        for name, value in (queries or {}).items():
            self.globals.vars[name] = value
        self._ast_cache = {}

    # ---- public
    def run(self, src, extra=None):
        ast = self._ast_cache.get(src)
        if ast is None:
            ast = self._ast_cache[src] = Parser(src).parse_document()
        env = Env(self.globals, dict(extra)) if extra else self.globals
        return self.ev(ast, env)

    def define(self, name, value):
        self.globals.vars[name] = value

    # ---- type helpers
    def make_type(self, t, env):
        k = t[0]
        if k == 'prim':
            return MType(t[1], nullable=t[2])
        if k == 'nullable':
            inner = self.make_type(t[1], env)
            return MType(inner.kind, True, inner.facet, inner.columns)
        if k == 'tabletype':
            return MType('table', columns=[(n, self.make_type(x, env)) for n, x in t[1]])
        if k == 'recordtype':
            return MType('record', columns=[(n, self.make_type(x, env)) for n, x in t[1]])
        if k == 'listtype':
            return MType('list')
        if k == 'texpr':
            v = self.ev(t[1], env)
            if not isinstance(v, MType):
                raise MRuntimeError(f'We cannot convert a value of type {cap(kind_of(v))} to type Type.')
            return v
        raise MUnsupported(f'type expression {k}')

    @staticmethod
    def check_prim(value, name, nullable, what):
        if value is None:
            if nullable or name in ('any', 'null'):
                return
            raise MRuntimeError(f'We cannot convert the value null to type {cap(name)}. ({what})')
        if name in ('any', 'anynonnull'):
            return
        k = kind_of(value)
        if k != name:
            raise MRuntimeError(f'We cannot convert a value of type {cap(k)} to type {cap(name)}. ({what})')

    # ---- calls
    def call(self, f, args):
        if type(f) is MFunction:
            ps = f.params
            if len(args) < f.n_required or len(args) > len(ps):
                raise MRuntimeError(f'{len(args)} arguments were passed to a function which expects '
                                    f'{f.n_required if f.n_required == len(ps) else f"between {f.n_required} and {len(ps)}"}.')
            vars_ = {}
            for i, (name, typ, _opt) in enumerate(ps):
                v = args[i] if i < len(args) else None
                if typ is not None:
                    self.check_prim(v, typ[1], typ[2], f'parameter {name}')
                vars_[name] = v
            r = self.ev(f.body, Env(f.env, vars_))
            if f.ret is not None:
                self.check_prim(r, f.ret[1], f.ret[2], 'function result')
            return r
        if type(f) is MBuiltin:
            sig = f.sig
            if sig is not None:
                n_req = sum(1 for p in sig if p[2])
                if len(args) < n_req or len(args) > len(sig):
                    raise MRuntimeError(f'{len(args)} arguments were passed to {f.name}, which expects '
                                        f'{n_req if n_req == len(sig) else f"between {n_req} and {len(sig)}"}.')
                for (pname, ptype, _req, pnull), v in zip(sig, args):
                    base = ptype
                    nullable = pnull
                    if base.startswith('nullable '):
                        base, nullable = base[9:], True
                    if base.startswith('list'):
                        base = 'list'
                    self.check_prim(v, base, nullable, f'{f.name}, argument {pname}')
            self.used[f.name] = self.used.get(f.name, 0) + 1
            return f.fn(*args)
        raise MRuntimeError(f'We cannot convert a value of type {cap(kind_of(f))} to type Function.')

    # ---- field / item access
    @staticmethod
    def field(base, name, optional):
        if type(base) is MRecord:
            if name in base:
                v = base[name]
                if type(v) is MErrorValue:
                    raise MRuntimeError(v.msg)
                return v
            if optional:
                return None
            raise MRuntimeError(f"The field '{name}' of the record wasn't found.")
        if type(base) is MTable:
            if name not in base._index and optional:
                return None
            return base.column_values(name)
        raise MRuntimeError(f'We cannot apply field access to the type {cap(kind_of(base))}.')

    def item(self, base, idx, optional):
        if isinstance(base, list):
            seq = base
        elif isinstance(base, MTable):
            if isinstance(idx, MRecord):                                   # key lookup:  table{[Col = value, ...]}
                hits = [r for r in base.records() if all(k in r and m_eq(r[k], v) for k, v in idx.items())]
                for k in idx:
                    base.col(k)
                if len(hits) == 1:
                    return hits[0]
                if not hits and optional:
                    return None
                raise MRuntimeError("The key didn't match any rows in the table." if not hits else 'The key matched more than one row in the table.')
            seq = base.records()
        else:
            raise MRuntimeError(f'We cannot apply item access to the type {cap(kind_of(base))}.')
        if kind_of(idx) != 'number' or idx != int(idx):
            raise MRuntimeError('The index of an item access must be a whole number.')
        i = int(idx)
        if i < 0:
            raise MRuntimeError('The index cannot be negative.')
        if i >= len(seq):
            if optional:
                return None
            raise MRuntimeError("There weren't enough elements in the enumeration to complete the operation.")
        v = seq[i]
        if type(v) is MErrorValue:
            raise MRuntimeError(v.msg)
        return v

    # ---- operators
    @staticmethod
    def binary(op, a, b):
        if op == '=':
            return m_eq(a, b)
        if op == '<>':
            return not m_eq(a, b)
        if op in ('<', '<=', '>', '>='):
            return m_rel(op, a, b)
        ka, kb = kind_of(a), kind_of(b)
        if op == '&':
            if ka == 'text' and kb == 'text':
                return a + b
            if ka == 'list' and kb == 'list':
                return a + b
            if ka == 'record' and kb == 'record':
                return MRecord({**a, **b})
            if (a is None and kb in ('text', 'null')) or (b is None and ka == 'text'):
                return None
            raise MRuntimeError(f'We cannot apply operator & to types {cap(ka)} and {cap(kb)}.')
        if a is None or b is None:                                         # arithmetic propagates null
            other = kb if a is None else ka
            if other in ('null', 'number', 'date', 'datetime', 'duration'):
                return None
            raise MRuntimeError(f'We cannot apply operator {op} to types {cap(ka)} and {cap(kb)}.')
        if ka == 'number' and kb == 'number':
            if op == '+':
                return a + b
            if op == '-':
                return a - b
            if op == '*':
                return a * b
            if b == 0:
                return math.nan if a == 0 else math.copysign(math.inf, a)   # M: x / 0 is +/-infinity or NaN, not an error
            return a / b
        if op == '-' and ka == kb and ka in ('date', 'datetime'):
            return a - b
        if op in ('+', '-') and ka in ('date', 'datetime') and kb == 'duration':
            if ka == 'date' and (b.seconds or b.microseconds):
                raise MUnsupported('date +/- a duration with a time part')
            return a + b if op == '+' else a - b
        if op == '+' and ka == 'duration' and kb in ('date', 'datetime'):
            return b + a
        if op in ('+', '-') and ka == 'duration' and kb == 'duration':
            return a + b if op == '+' else a - b
        if op in ('*', '/') and ka == 'duration' and kb == 'number':
            return a * b if op == '*' else a / b
        raise MRuntimeError(f'We cannot apply operator {op} to types {cap(ka)} and {cap(kb)}.')

    @staticmethod
    def logical_operand(v, op):
        if v is None or isinstance(v, bool):
            return v
        raise MRuntimeError(f'We cannot convert a value of type {cap(kind_of(v))} to type Logical. (operand of "{op}")')

    # ---- evaluation
    def ev(self, n, env):
        k = n[0]
        if k == 'ifield':
            return self.field(env.lookup('_'), n[1], n[2])
        if k == 'bin':
            return self.binary(n[1], self.ev(n[2], env), self.ev(n[3], env))
        if k == 'id':
            return env.lookup(n[1])
        if k == 'str' or k == 'num' or k == 'bool':
            return n[1]
        if k == 'null':
            return None
        if k == 'and':
            a = self.logical_operand(self.ev(n[1], env), 'and')
            if a is False:
                return False
            b = self.logical_operand(self.ev(n[2], env), 'and')
            if b is False:
                return False
            return None if (a is None or b is None) else True
        if k == 'or':
            a = self.logical_operand(self.ev(n[1], env), 'or')
            if a is True:
                return True
            b = self.logical_operand(self.ev(n[2], env), 'or')
            if b is True:
                return True
            return None if (a is None or b is None) else False
        if k == 'call':
            f = self.ev(n[1], env)
            return self.call(f, [self.ev(a, env) for a in n[2]])
        if k == 'field':
            return self.field(self.ev(n[1], env), n[2], n[3])
        if k == 'if':
            c = self.ev(n[1], env)
            if c is True:
                return self.ev(n[2], env)
            if c is False:
                return self.ev(n[3], env)
            if c is None:
                raise MRuntimeError('We cannot convert the value null to type Logical. (condition of "if")')
            raise MRuntimeError(f'We cannot convert a value of type {cap(kind_of(c))} to type Logical. (condition of "if")')
        if k == 'let':
            e2 = Env(env)
            for name, expr in n[1]:
                if name in e2.vars:
                    raise MRuntimeError(f"The variable named '{name}' is already defined in this scope.")
                e2.vars[name] = Thunk(self, expr, e2, name)
            return self.ev(n[2], e2)
        if k == 'each':
            return MFunction(self, [('_', None, False)], None, n[1], env, 'each')
        if k == 'func':
            return MFunction(self, n[1], n[2], n[3], env)
        if k == 'list':
            out = []
            for x in n[1]:
                try:
                    out.append(self.ev(x, env))
                except MRuntimeError as e:            # list items are lazy in M: the error surfaces when the item is read
                    out.append(MErrorValue(str(e)))
            return out
        if k == 'notimpl':
            raise MRuntimeError('Expression.Error: Not Implemented')
        if k == 'record':
            e2 = Env(env)
            names = [nm for nm, _ in n[1]]
            if len(set(names)) != len(names):
                raise MRuntimeError('A record cannot have two fields with the same name.')
            for nm, expr in n[1]:
                e2.vars[nm] = Thunk(self, expr, e2, nm)
            return MRecord((nm, e2.vars[nm].get()) for nm in names)
        if k == 'item':
            return self.item(self.ev(n[1], env), self.ev(n[2], env), n[3])
        if k == 'unary':
            v = self.ev(n[2], env)
            if n[1] == 'not':
                v = self.logical_operand(v, 'not')
                return None if v is None else (not v)
            if v is None:
                return None
            if kind_of(v) not in ('number', 'duration'):
                raise MRuntimeError(f'We cannot apply operator {n[1]} to type {cap(kind_of(v))}.')
            return -v if n[1] == '-' else v
        if k == 'typeexpr':
            return self.make_type(n[1], env)
        if k == 'as':
            v = self.ev(n[1], env)
            self.check_prim(v, n[2][1], n[2][2], '"as" expression')
            return v
        if k == 'is':
            v = self.ev(n[1], env)
            name, nullable = n[2][1], n[2][2]
            if v is None:
                return nullable or name in ('any', 'null')
            return name in ('any', 'anynonnull') or kind_of(v) == name
        raise MUnsupported(f'AST node {k}')

    # =================================================================================================================
    # library
    # =================================================================================================================
    def _install_library(self):
        I = self
        lib = {}

        def reg(name):
            def deco(fn):
                lib[name] = fn
                return fn
            return deco

        def as_list_of_lists(x, what):
            """M lets many 'list of pairs' arguments also be given as a single pair."""
            if not isinstance(x, list):
                raise MRuntimeError(f'{what}: a list was expected.')
            if x and not isinstance(x[0], list):
                return [x]
            return x

        def text_list(x, what):
            if isinstance(x, str):
                return [x]
            if isinstance(x, list) and all(isinstance(c, str) for c in x):
                return x
            raise MRuntimeError(f'{what}: a column name or a list of column names was expected.')

        def call(f, *args):
            return I.call(f, list(args))

        def no_errors(values):
            for v in values:
                if type(v) is MErrorValue:
                    raise MRuntimeError(v.msg)
            return values

        def same_kind(values, fname):
            kinds = {kind_of(v) for v in values}
            if len(kinds) > 1:
                raise MRuntimeError(f'{fname}: the list mixes values of types {sorted(kinds)}.')
            if kinds and next(iter(kinds)) not in ORDERED:
                raise MRuntimeError(f'{fname}: values of type {next(iter(kinds))} cannot be compared.')

        # ---------------------------------------------------------------- data access (mocked)
        @reg('File.Contents')
        def _(path, options=None):
            if path not in I.files:
                raise MRuntimeError(f"DataSource.Error: Could not find file '{path}'.")       # like the real engine
            return MBinary(path)

        @reg('Excel.Workbook')
        def _(workbook, useHeaders=None, delayTypes=None):
            return I.files[workbook.path]

        # ---------------------------------------------------------------- Table.*
        @reg('Table.RowCount')
        def _(table):
            return len(table.rows)

        @reg('Table.IsEmpty')
        def _(table):
            return len(table.rows) == 0

        @reg('Table.ColumnNames')
        def _(table):
            return list(table.columns)

        @reg('Table.Column')
        def _(table, column):
            return table.column_values(column)

        @reg('Table.ToRecords')
        def _(table):
            for r in table.rows:
                no_errors(r)
            return list(table.records())

        @reg('Table.Buffer')
        def _(table, options=None):
            for r in table.rows:
                no_errors(r)                              # buffering evaluates every cell, so cell errors surface here
            return table

        @reg('Table.SelectRows')
        def _(table, condition):
            out = []
            for rec, row in zip(table.records(), table.rows):
                r = call(condition, rec)
                if r is True:
                    out.append(row)
                elif r is False:
                    pass
                elif r is None:
                    raise MUnsupported('a Table.SelectRows condition returned null. The queries of this project test for null first '
                                       '(e.g. [Age] <> null and [Age] < 20) instead of relying on how the engine treats a null condition.')
                else:
                    raise MRuntimeError(f'We cannot convert a value of type {cap(kind_of(r))} to type Logical. (Table.SelectRows condition)')
            return MTable(table.columns, out, table.types)

        @reg('Table.RenameColumns')
        def _(table, renames, missingField=None):
            cols = list(table.columns)
            for pair in as_list_of_lists(renames, 'Table.RenameColumns'):
                if len(pair) != 2 or not all(isinstance(p, str) for p in pair):
                    raise MRuntimeError('Table.RenameColumns: each rename must be {old name, new name}.')
                old, new = pair
                if old not in cols:
                    if missingField in (1, 2):            # MissingField.Ignore / UseNull
                        continue
                    raise MRuntimeError(f"The column '{old}' of the table wasn't found.")
                if new in cols and new != old:
                    raise MRuntimeError(f"The field '{new}' already exists in the record.")
                cols[cols.index(old)] = new
            types = {dict(zip(table.columns, cols))[c]: t for c, t in table.types.items()}
            return MTable(cols, table.rows, types)

        @reg('Table.SelectColumns')
        def _(table, columns, missingField=None):
            names = text_list(columns, 'Table.SelectColumns')
            idx = []
            for c in names:
                if c in table._index:
                    idx.append(table._index[c])
                elif missingField == 2:                   # MissingField.UseNull
                    idx.append(None)
                elif missingField == 1:                   # MissingField.Ignore
                    idx.append(-1)
                else:
                    raise MRuntimeError(f"The column '{c}' of the table wasn't found.")
            keep = [(c, i) for c, i in zip(names, idx) if i != -1]
            rows = [[None if i is None else r[i] for _, i in keep] for r in table.rows]
            return MTable([c for c, _ in keep], rows, {c: t for c, t in table.types.items() if c in names})

        @reg('Table.RemoveColumns')
        def _(table, columns, missingField=None):
            names = text_list(columns, 'Table.RemoveColumns')
            for c in names:
                if c not in table._index and missingField not in (1, 2):
                    raise MRuntimeError(f"The column '{c}' of the table wasn't found.")
            keep = [i for i, c in enumerate(table.columns) if c not in names]
            return MTable([table.columns[i] for i in keep], [[r[i] for i in keep] for r in table.rows],
                          {c: t for c, t in table.types.items() if c not in names})

        @reg('Table.TransformColumnTypes')
        def _(table, typeTransformations, culture=None):
            if culture is not None:
                raise MUnsupported('Table.TransformColumnTypes with a culture / options argument')
            ops = as_list_of_lists(typeTransformations, 'Table.TransformColumnTypes')
            plan = {}
            for op in ops:
                if len(op) != 2 or not isinstance(op[0], str) or not isinstance(op[1], MType):
                    raise MRuntimeError('Table.TransformColumnTypes: each item must be {column name, type}.')
                plan[table.col(op[0])] = op[1]
            rows = [[convert_cell(v, plan[i]) if i in plan else v for i, v in enumerate(r)] for r in table.rows]
            types = dict(table.types)
            types.update({table.columns[i]: t for i, t in plan.items()})
            return MTable(table.columns, rows, types)

        @reg('Table.ReplaceErrorValues')
        def _(table, errorReplacement):
            plan = {}
            for op in as_list_of_lists(errorReplacement, 'Table.ReplaceErrorValues'):
                if len(op) != 2 or not isinstance(op[0], str):
                    raise MRuntimeError('Table.ReplaceErrorValues: each item must be {column name, value}.')
                plan[table.col(op[0])] = op[1]
            rows = [[plan[i] if (i in plan and type(v) is MErrorValue) else v for i, v in enumerate(r)] for r in table.rows]
            return MTable(table.columns, rows, table.types)

        @reg('Table.TransformColumns')
        def _(table, transformOperations, defaultTransformation=None, missingField=None):
            plan, types, added = {}, dict(table.types), []
            for op in as_list_of_lists(transformOperations, 'Table.TransformColumns'):
                if len(op) not in (2, 3) or not isinstance(op[0], str) or kind_of(op[1]) != 'function':
                    raise MRuntimeError('Table.TransformColumns: each item must be {column name, function} or {column name, function, type}.')
                if op[0] not in table._index:
                    if missingField == 2:                 # MissingField.UseNull: the column is added, filled with null
                        added.append(op[0])
                        continue
                    if missingField == 1:                 # MissingField.Ignore
                        continue
                    raise MRuntimeError(f"The column '{op[0]}' of the table wasn't found.")
                plan[table._index[op[0]]] = op[1]
                if len(op) == 3:
                    if not isinstance(op[2], MType):
                        raise MRuntimeError('Table.TransformColumns: the third item must be a type.')
                    types[op[0]] = op[2]
            rows = []
            for r in table.rows:
                new = list(r)
                for i, f in plan.items():
                    if type(r[i]) is MErrorValue:
                        continue
                    new[i] = call(f, r[i])
                if defaultTransformation is not None:
                    for i in range(len(new)):
                        if i not in plan and type(r[i]) is not MErrorValue:
                            new[i] = call(defaultTransformation, r[i])
                rows.append(new + [None] * len(added))
            return MTable(table.columns + added, rows, types)

        @reg('Table.AddColumn')
        def _(table, newColumnName, columnGenerator, columnType=None):
            if newColumnName in table._index:
                raise MRuntimeError(f"The field '{newColumnName}' already exists in the record.")
            rows = [r + [call(columnGenerator, rec)] for rec, r in zip(table.records(), table.rows)]
            types = dict(table.types)
            if columnType is not None:
                types[newColumnName] = columnType
            return MTable(table.columns + [newColumnName], rows, types)

        @reg('Table.Group')
        def _(table, key, aggregatedColumns, groupKind=None, comparer=None):
            if comparer is not None or groupKind == 0:
                raise MUnsupported('Table.Group with a comparer or GroupKind.Local')
            keys = text_list(key, 'Table.Group')
            kidx = [table.col(c) for c in keys]
            aggs = as_list_of_lists(aggregatedColumns, 'Table.Group')
            for a in aggs:
                if len(a) not in (2, 3) or not isinstance(a[0], str) or kind_of(a[1]) != 'function':
                    raise MRuntimeError('Table.Group: each aggregation must be {name, function} or {name, function, type}.')
            groups, order = {}, []
            for r in table.rows:
                kv = [r[i] for i in kidx]
                hk = tuple(hkey(v) for v in no_errors(kv))
                if hk not in groups:
                    groups[hk] = (kv, [])
                    order.append(hk)
                groups[hk][1].append(r)
            rows = []
            for hk in order:
                kv, grp = groups[hk]
                sub = MTable(table.columns, grp, table.types)
                rows.append(kv + [call(a[1], sub) for a in aggs])
            return MTable(keys + [a[0] for a in aggs], rows)

        @reg('Table.Sort')
        def _(table, comparisonCriteria):
            crit = comparisonCriteria
            if isinstance(crit, str):
                crit = [[crit, 0]]
            elif isinstance(crit, list) and len(crit) == 2 and isinstance(crit[0], str) and kind_of(crit[1]) == 'number':
                crit = [crit]
            elif isinstance(crit, list):
                crit = [[c, 0] if isinstance(c, str) else c for c in crit]
            else:
                raise MUnsupported('Table.Sort with a comparison function')
            rows = list(table.rows)
            for c in reversed(crit):
                if not (isinstance(c, list) and len(c) == 2 and isinstance(c[0], str) and c[1] in (0, 1)):
                    raise MRuntimeError('Table.Sort: each criterion must be {column name, Order.Ascending | Order.Descending}.')
                i = table.col(c[0])
                vals = no_errors([r[i] for r in rows])
                same_kind([v for v in vals if v is not None], 'Table.Sort')
                rows.sort(key=lambda r, i=i: (r[i] is not None, r[i] if r[i] is not None else 0), reverse=(c[1] == 1))
            return MTable(table.columns, rows, table.types)

        @reg('Table.FromRows')
        def _(rows, columns=None):
            for r in rows:
                if not isinstance(r, list):
                    raise MRuntimeError('Table.FromRows: every row must be a list.')
            if isinstance(columns, MType):
                if columns.kind != 'table' or columns.columns is None:
                    raise MRuntimeError('Table.FromRows: a table type was expected.')
                names, types = [c for c, _ in columns.columns], dict(columns.columns)
            elif isinstance(columns, list):
                names, types = text_list(columns, 'Table.FromRows'), {}
            elif columns is None:
                names, types = [f'Column{i + 1}' for i in range(len(rows[0]) if rows else 0)], {}
            else:
                raise MUnsupported('Table.FromRows with a column count')
            for r in rows:
                if len(r) != len(names):
                    raise MRuntimeError(f'Table.FromRows: a row has {len(r)} values but the table has {len(names)} columns.')
            return MTable(names, [list(r) for r in rows], types)

        @reg('Table.FromRecords')
        def _(records, columns=None, missingField=None):
            if isinstance(columns, MType):
                names = [c for c, _t in (columns.columns or [])]
            elif columns is not None:
                names = text_list(columns, 'Table.FromRecords')
            else:
                names = list(records[0].keys()) if records else []
            rows = []
            for r in records:
                if not isinstance(r, MRecord):
                    raise MRuntimeError('Table.FromRecords: every item must be a record.')
                row = []
                for c in names:
                    if c in r:
                        row.append(r[c])
                    elif missingField == 2:
                        row.append(None)
                    else:
                        raise MRuntimeError(f"The field '{c}' of the record wasn't found.")
                rows.append(row)
            return MTable(names, rows)

        @reg('#table')
        def _(columns, rows):
            if isinstance(columns, MType):
                names = [c for c, _t in (columns.columns or [])]
            elif isinstance(columns, list):
                names = text_list(columns, '#table')
            else:
                raise MUnsupported('#table with a column count')
            for r in rows:
                if not isinstance(r, list) or len(r) != len(names):
                    raise MRuntimeError('#table: every row must be a list with one value per column.')
            return MTable(names, [list(r) for r in rows])

        @reg('Table.FromList')
        def _(list_, splitter=None, columns=None, default=None, extraValues=None):
            if splitter is None:
                raise MUnsupported('Table.FromList without a splitter (the default splitter splits text by commas)')
            names = [columns] if isinstance(columns, str) else (columns if columns is not None else ['Column1'])
            rows = []
            for v in list_:
                parts = call(splitter, v)
                if len(parts) != len(names):
                    raise MRuntimeError('Table.FromList: the number of values does not match the number of columns.')
                rows.append(list(parts))
            return MTable(text_list(names, 'Table.FromList'), rows)

        @reg('Table.Combine')
        def _(tables, columns=None):
            if columns is not None:
                raise MUnsupported('Table.Combine with a column list')
            names = []
            for t in tables:
                for c in t.columns:
                    if c not in names:
                        names.append(c)
            rows = []
            for t in tables:
                idx = [t._index.get(c) for c in names]
                rows += [[None if i is None else r[i] for i in idx] for r in t.rows]
            return MTable(names, rows)

        @reg('Splitter.SplitByNothing')
        def _():
            return MBuiltin('<splitter>', lambda v: [v], None)

        # ---------------------------------------------------------------- List.*
        @reg('List.Count')
        def _(list_):
            return len(list_)

        @reg('List.IsEmpty')
        def _(list_):
            return len(list_) == 0

        @reg('List.RemoveNulls')
        def _(list_):
            return [v for v in no_errors(list_) if v is not None]

        @reg('List.Distinct')
        def _(list_, equationCriteria=None):
            if equationCriteria is not None:
                raise MUnsupported('List.Distinct with equation criteria')
            seen, out = set(), []
            for v in no_errors(list_):
                h = hkey(v)
                if h not in seen:
                    seen.add(h)
                    out.append(v)
            return out

        @reg('List.Contains')
        def _(list_, value, equationCriteria=None):
            if equationCriteria is not None:
                raise MUnsupported('List.Contains with equation criteria')
            return any(m_eq(v, value) for v in list_)

        @reg('List.Transform')
        def _(list_, transform):
            return [call(transform, v) for v in no_errors(list_)]

        @reg('List.Select')
        def _(list_, selection):
            out = []
            for v in no_errors(list_):
                r = call(selection, v)
                if r is True:
                    out.append(v)
                elif r is not False:
                    raise MRuntimeError(f'List.Select: the selection function returned {cap(kind_of(r))}, a logical value is required.')
            return out

        def min_max(list_, default, comparisonCriteria, includeNulls, fname, pick):
            if comparisonCriteria is not None or includeNulls is not None:
                raise MUnsupported(f'{fname} with comparison criteria / includeNulls')
            vals = no_errors(list_)
            if any(v is None for v in vals):
                raise MUnsupported(f'{fname} was called on a list that contains null. The queries of this project remove nulls first '
                                   f'(List.RemoveNulls) instead of relying on how the engine treats them.')
            if not vals:
                return default
            same_kind(vals, fname)
            return pick(vals)

        @reg('List.Min')
        def _(list_, default=None, comparisonCriteria=None, includeNulls=None):
            return min_max(list_, default, comparisonCriteria, includeNulls, 'List.Min', min)

        @reg('List.Max')
        def _(list_, default=None, comparisonCriteria=None, includeNulls=None):
            return min_max(list_, default, comparisonCriteria, includeNulls, 'List.Max', max)

        def numeric(list_, fname):
            vals = no_errors(list_)
            if any(v is None for v in vals):
                raise MUnsupported(f'{fname} was called on a list that contains null. The queries of this project remove nulls first '
                                   f'(List.RemoveNulls) instead of relying on how the engine treats them.')
            for v in vals:
                if kind_of(v) in ('date', 'datetime', 'duration'):
                    raise MUnsupported(f'{fname} of {kind_of(v)} values')
                if kind_of(v) != 'number':
                    raise MRuntimeError(f'{fname}: a value of type {cap(kind_of(v))} cannot be aggregated as a number.')
            return vals

        @reg('List.Sum')
        def _(list_, precision=None):
            vals = numeric(list_, 'List.Sum')
            return sum(vals) if vals else None

        @reg('List.Average')
        def _(list_, precision=None):
            vals = numeric(list_, 'List.Average')
            return (math.fsum(vals) / len(vals)) if vals else None

        @reg('List.Median')
        def _(list_, comparisonCriteria=None):
            if comparisonCriteria is not None:
                raise MUnsupported('List.Median with comparison criteria')
            vals = sorted(numeric(list_, 'List.Median'))
            if not vals:
                return None
            mid = len(vals) // 2
            return vals[mid] if len(vals) % 2 else (vals[mid - 1] + vals[mid]) / 2

        @reg('List.Dates')
        def _(start, count, step):
            if count != int(count) or count < 0:
                raise MRuntimeError('List.Dates: count must be a non-negative whole number.')
            return [start + step * i for i in range(int(count))]

        # ---------------------------------------------------------------- Record.*
        @reg('Record.Field')
        def _(record, field):
            return I.field(record, field, False)

        @reg('Record.FieldOrDefault')
        def _(record, field, defaultValue=None):
            if record is None or field not in record:
                return defaultValue
            return I.field(record, field, False)

        # ---------------------------------------------------------------- Text.* / Number.*
        @reg('Text.Trim')
        def _(text, trim=None):
            if trim is not None:
                raise MUnsupported('Text.Trim with custom trim characters')
            return None if text is None else text.strip()

        @reg('Text.From')
        def _(value, culture=None):
            return None if value is None else to_text(value)

        @reg('Number.ToText')
        def _(number, format=None, culture=None):
            if number is None:
                return None
            if format is None:
                return number_text(number)
            return net_number_format(number, format)

        @reg('Number.From')
        def _(value, culture=None):
            if value is None:
                return None
            try:
                return to_number(value)
            except ConversionError as e:
                raise MRuntimeError(str(e))

        @reg('Number.Round')
        def _(number, digits=None, roundingMode=None):
            if number is None:
                return None
            if roundingMode is not None:
                raise MUnsupported('Number.Round with a rounding mode')
            return round(number, int(digits or 0))        # default rounding mode is RoundingMode.ToEven

        # ---------------------------------------------------------------- Date.* / Duration.*
        def date_arg(v, fname):
            if v is not None and kind_of(v) not in ('date', 'datetime'):
                if kind_of(v) == 'datetimezone':
                    raise MUnsupported('datetimezone')
                raise MRuntimeError(f'We cannot convert a value of type {cap(kind_of(v))} to type Date. ({fname})')
            return v

        def month_end_day(y, m):
            return ((dt.date(y + (m == 12), m % 12 + 1, 1)) - dt.timedelta(days=1)).day

        @reg('Date.Year')
        def _(dateTime):
            return None if date_arg(dateTime, 'Date.Year') is None else dateTime.year

        @reg('Date.Month')
        def _(dateTime):
            return None if date_arg(dateTime, 'Date.Month') is None else dateTime.month

        @reg('Date.Day')
        def _(dateTime):
            return None if date_arg(dateTime, 'Date.Day') is None else dateTime.day

        @reg('Date.QuarterOfYear')
        def _(dateTime):
            return None if date_arg(dateTime, 'Date.QuarterOfYear') is None else (dateTime.month - 1) // 3 + 1

        @reg('Date.StartOfMonth')
        def _(dateTime):
            v = date_arg(dateTime, 'Date.StartOfMonth')
            if v is None:
                return None
            return dt.datetime(v.year, v.month, 1) if isinstance(v, dt.datetime) else dt.date(v.year, v.month, 1)

        @reg('Date.EndOfMonth')
        def _(dateTime):
            v = date_arg(dateTime, 'Date.EndOfMonth')
            if v is None:
                return None
            last = month_end_day(v.year, v.month)
            if isinstance(v, dt.datetime):
                return dt.datetime(v.year, v.month, last, 23, 59, 59, 999999)
            return dt.date(v.year, v.month, last)

        @reg('Date.AddMonths')
        def _(dateTime, numberOfMonths):
            v = date_arg(dateTime, 'Date.AddMonths')
            if v is None:
                return None
            if numberOfMonths != int(numberOfMonths):
                raise MRuntimeError('Date.AddMonths: numberOfMonths must be a whole number.')
            total = v.year * 12 + (v.month - 1) + int(numberOfMonths)
            y, m = divmod(total, 12)
            return v.replace(year=y, month=m + 1, day=min(v.day, month_end_day(y, m + 1)))

        @reg('Date.DayOfWeek')
        def _(dateTime, firstDayOfWeek=None):
            v = date_arg(dateTime, 'Date.DayOfWeek')
            if v is None:
                return None
            if firstDayOfWeek is None:
                raise MUnsupported('Date.DayOfWeek without firstDayOfWeek depends on the regional settings')
            sunday_based = (v.weekday() + 1) % 7           # Day.Sunday = 0 ... Day.Saturday = 6
            return (sunday_based - int(firstDayOfWeek)) % 7

        @reg('Date.ToText')
        def _(date, options=None, culture=None):
            if date is None:
                return None
            if not isinstance(options, str) or culture != 'en-US':
                raise MUnsupported('Date.ToText is only implemented for (date, format text, "en-US")')
            return net_date_format(date, options)

        @reg('Date.From')
        def _(value, culture=None):
            if value is None:
                return None
            try:
                return to_date(value)
            except ConversionError as e:
                raise MRuntimeError(str(e))

        @reg('Duration.Days')
        def _(duration):
            return None if duration is None else duration.days

        @reg('#date')
        def _(year, month, day):
            try:
                return dt.date(int(year), int(month), int(day))
            except ValueError:
                raise MRuntimeError('The Date value must contain the Date component.')

        @reg('#datetime')
        def _(year, month, day, hour, minute, second):
            whole = int(second)
            return dt.datetime(int(year), int(month), int(day), int(hour), int(minute), whole, int(round((second - whole) * 1e6)))

        @reg('Date.AddDays')
        def _(dateTime, numberOfDays):
            v = date_arg(dateTime, 'Date.AddDays')
            return None if v is None else v + dt.timedelta(days=numberOfDays)

        @reg('Number.FromText')
        def _(text, culture=None):
            if text is None:
                return None
            try:
                return to_number(text)
            except ConversionError as e:
                raise MRuntimeError(str(e))

        @reg('Text.Contains')
        def _(text, substring, comparer=None):
            if comparer is not None:
                raise MUnsupported('Text.Contains with a comparer')
            return None if text is None else substring in text

        @reg('Text.Lower')
        def _(text, culture=None):
            return None if text is None else text.lower()

        @reg('Text.Upper')
        def _(text, culture=None):
            return None if text is None else text.upper()

        @reg('Text.Length')
        def _(text):
            return None if text is None else len(text)

        @reg('List.Reverse')
        def _(list_):
            return list(reversed(list_))

        @reg('Record.FieldValues')
        def _(record):
            return [I.field(record, k, False) for k in record]

        @reg('#duration')
        def _(days, hours, minutes, seconds):
            return dt.timedelta(days=days, hours=hours, minutes=minutes, seconds=seconds)

        # ---------------------------------------------------------------- constants (official values)
        consts = {
            'MissingField.Error': 0, 'MissingField.Ignore': 1, 'MissingField.UseNull': 2,
            'Order.Ascending': 0, 'Order.Descending': 1,
            'Day.Sunday': 0, 'Day.Monday': 1, 'Day.Tuesday': 2, 'Day.Wednesday': 3, 'Day.Thursday': 4, 'Day.Friday': 5, 'Day.Saturday': 6,
            'Int64.Type': MType('number', facet='Int64'), 'Number.Type': MType('number'), 'Text.Type': MType('text'),
            'Date.Type': MType('date'), 'Logical.Type': MType('logical'), 'Any.Type': MType('any'),
        }

        for name, fn in lib.items():
            sig = self.signatures.get(name)
            if sig is None or sig['params'] is None and sig['kind'] != 3:
                raise MUnsupported(f'{name} is implemented here but is not a function in the official library definition')
            self.globals.vars[name] = MBuiltin(name, fn, sig['params'] or [])
        for name, value in consts.items():
            if name not in self.signatures:
                raise MUnsupported(f'{name} is not in the official library definition')
            self.globals.vars[name] = value
        self.implemented = set(lib) | set(consts)


# =====================================================================================================================
# static helpers
# =====================================================================================================================
def library_identifiers(src):
    """All dotted / #-prefixed identifiers used in a piece of M code (outside strings, comments and field names)."""
    return {t.val for t in tokenize(src) if t.kind == 'id' and not t.quoted and ('.' in t.val or t.val.startswith('#'))}


def check_identifiers(src, signatures):
    """Return the dotted identifiers that are NOT part of Microsoft's standard library."""
    return sorted(n for n in library_identifiers(src) if n not in signatures)


def deep_equal(a, b, tol=1e-9):
    """Structural comparison of two M values (tables: same columns and the same rows in the same order)."""
    if isinstance(a, MTable) and isinstance(b, MTable):
        return a.columns == b.columns and len(a.rows) == len(b.rows) and all(
            len(x) == len(y) and all(deep_equal(p, q, tol) for p, q in zip(x, y)) for x, y in zip(a.rows, b.rows))
    if isinstance(a, MRecord) and isinstance(b, MRecord):
        return list(a) == list(b) and all(deep_equal(a[k], b[k], tol) for k in a)
    if isinstance(a, list) and isinstance(b, list):
        return len(a) == len(b) and all(deep_equal(x, y, tol) for x, y in zip(a, b))
    if isinstance(a, MErrorValue) or isinstance(b, MErrorValue):
        return isinstance(a, MErrorValue) and isinstance(b, MErrorValue)
    if kind_of(a) == 'number' and kind_of(b) == 'number':
        return abs(a - b) <= tol * max(1.0, abs(a), abs(b))
    return m_eq(a, b)


def table_from_rows(columns, rows, types=None):
    return MTable(columns, [list(r) for r in rows], types)
