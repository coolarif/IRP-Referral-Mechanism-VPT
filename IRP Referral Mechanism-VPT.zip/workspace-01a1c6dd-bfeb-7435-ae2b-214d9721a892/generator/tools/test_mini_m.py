#!/usr/bin/env python3
"""Unit tests for mini_m.py: language rules (null handling, laziness, typing) and the library wrappers."""
import datetime as dt
import math
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import mini_m as M                                     # noqa: E402


def run_tests(verbose=False):
    I = M.Interp()
    I.define('T', M.table_from_rows(['n', 't'], [[1, 'a'], [None, 'b'], [3, None], [5, 'a']]))
    result = {'passed': 0, 'failed': 0}

    def t(src, expect):
        try:
            got = I.run(src)
        except (M.MRuntimeError, M.MUnsupported) as e:
            got = ('ERR', type(e).__name__, str(e)[:70])
        if callable(expect):
            good = expect(got)
        elif expect == 'ERR':
            good = isinstance(got, tuple) and got and got[0] == 'ERR' and got[1] == 'MRuntimeError'
        elif expect == 'UNSUP':
            good = isinstance(got, tuple) and got and got[0] == 'ERR' and got[1] == 'MUnsupported'
        else:
            good = ((got == expect) and type(got) is type(expect)) or (
                isinstance(expect, float) and isinstance(got, (int, float)) and not isinstance(got, bool) and abs(got - expect) < 1e-12)
        result['passed' if good else 'failed'] += 1
        if not good or verbose:
            print(('ok   ' if good else 'FAIL ') + src + ('' if good else f'\n      got {got!r}, expected {expect!r}'))

    # arithmetic, text, null propagation
    t('1 + 2 * 3', 7); t('(1 + 2) * 3', 9); t('7 / 2', 3.5); t('-3 + 1', -2)
    t('"a" & "b"', 'ab'); t('"a" + "b"', 'ERR'); t('1 & 2', 'ERR'); t('"a" & null', None)
    t('null + 1', None); t('1 - null', None); t('null * null', None)
    t('1 / 0', lambda g: g == math.inf); t('0 / 0', lambda g: isinstance(g, float) and math.isnan(g))
    # equality, relational operators, three-valued logic
    t('null = null', True); t('null = 1', False); t('1 = "1"', False); t('1 = 1.0', True); t('1 <> 2', True); t('"A" = "a"', False)
    t('#date(2024, 1, 1) = ""', False); t('#date(2024, 1, 1) <> ""', True)
    t('1 < null', None); t('null >= null', None); t('1 < "a"', 'ERR'); t('"a" < "b"', True); t('2 >= 2', True)
    t('true and null', None); t('false and null', False); t('null and false', False); t('null or true', True); t('null or false', None)
    t('not null', None); t('not true', False); t('1 and true', 'ERR')
    t('if null then 1 else 2', 'ERR'); t('if 1 < null then 1 else 2', 'ERR'); t('if 1 < 2 then "y" else "n"', 'y')
    t('false and (1 < "a")', False); t('true or (1 < "a")', True)                       # short circuit
    # let (lazy, forward references, own name = outer scope), functions, each
    t('let a = 1, b = a + 1 in b', 2); t('let x = 1 < "a", y = 5 in y', 5); t('let b = a + 1, a = 1 in b', 2); t('let a = a + 1 in a', 'ERR')
    t('let x = 1 in let x = x + 1 in x', 2); t('let D = 5 in [D = D][D]', 5); t('let a = b, b = a in a', 'ERR')
    t('let f = (x) => x + 1 in f(2)', 3); t('let f = (x as number) as number => x * 2 in f(4)', 8); t('let f = (x as number) => x in f("a")', 'ERR')
    t('let f = (x as number) as text => x in f(1)', 'ERR'); t('let f = (x as nullable number) => x in f(null)', None)
    t('let f = (x as number) => x in f(null)', 'ERR'); t('let f = (x, optional y) => if y = null then x else x + y in f(1) + f(1, 2)', 4)
    t('let f = (x) => x in f(1, 2)', 'ERR'); t('let f = (x, y) => x in f(1)', 'ERR')
    t('(each _ * 2)(4)', 8); t('(each [a] + 1)([a = 4])', 5); t('Undefined.Name', 'ERR'); t('undefinedName + 1', 'ERR')
    # lists, records, item / field access
    t('{1, 2, 3}{1}', 2); t('{1, 2}{5}', 'ERR'); t('{1, 2}{5}?', None); t('[a = 1, b = a + 1][b]', 2); t('[a = 1][z]', 'ERR'); t('[a = 1][z]?', None)
    t('[#"x y" = 2][#"x y"]', 2); t('[x y = 2][x y]', 2); t('[Any anomaly in scan = "Yes"][Any anomaly in scan]', 'Yes')
    t('{1, 2} & {3}', [1, 2, 3]); t('{}', []); t('[]', lambda g: g == {})
    t('{[a = 1], [a = 2]}{1}[a]', 2); t('{{1, 2}, {3, 4}}{1}{0}', 3); t('[a = 1] = [a = 1]', True); t('{1, "a"} = {1, "a"}', True)
    t('{1, ...}{0}', 1); t('{1, ...}{1}', 'ERR')                                         # list items are lazy
    # dates and durations
    t('#date(2024, 1, 31) - #date(2024, 1, 1)', dt.timedelta(days=30)); t('Duration.Days(#date(2024, 3, 1) - #date(2024, 2, 1))', 29)
    t('Duration.Days(null)', None); t('Date.EndOfMonth(#date(2024, 2, 10))', dt.date(2024, 2, 29))
    t('Date.StartOfMonth(#date(2026, 10, 31))', dt.date(2026, 10, 1)); t('Date.StartOfMonth(null)', None)
    t('Date.StartOfMonth(#datetime(2026, 10, 31, 8, 5, 0))', dt.datetime(2026, 10, 1))
    t('Date.AddMonths(#date(2024, 1, 31), 1)', dt.date(2024, 2, 29)); t('Date.AddMonths(#date(2026, 10, 1), -1)', dt.date(2026, 9, 1))
    t('Date.AddMonths(#date(2026, 1, 15), -1)', dt.date(2025, 12, 15)); t('#date(2024, 1, 1) + #duration(1, 0, 0, 0)', dt.date(2024, 1, 2))
    t('#date(2024, 1, 1) < #date(2024, 1, 2)', True); t('#date(2024, 1, 1) < 5', 'ERR'); t('#date(2024, 1, 1) - null', None)
    t('#date(2024, 1, 1) < #datetime(2024, 1, 2, 0, 0, 0)', 'ERR'); t('#date(2024, 1, 1) - #datetime(2024, 1, 2, 0, 0, 0)', 'ERR')
    t('Date.Year("2024")', 'ERR'); t('#date(2024, 2, 30)', 'ERR')
    t('Date.DayOfWeek(#date(2026, 11, 9), Day.Monday)', 0); t('Date.DayOfWeek(#date(2026, 11, 15), Day.Monday)', 6)
    t('Date.ToText(#date(2026, 11, 9), "MMM", "en-US")', 'Nov'); t('Date.ToText(#date(2026, 1, 9), "yyyy-MM", "en-US")', '2026-01')
    t('Date.ToText(#datetime(2026, 1, 9, 0, 0, 0), "MMM", "en-US")', 'ERR')              # the function takes a date, not a datetime
    t('List.Count(List.Dates(#date(2024, 11, 1), 3, #duration(1, 0, 0, 0)))', 3)
    # library: lists (nulls must be removed before aggregating - undocumented behaviour is refused)
    t('List.Max({1, 3})', 3); t('List.Max({1, null, 3})', 'UNSUP'); t('List.Max(List.RemoveNulls({1, null, 3}))', 3); t('List.Min({})', None)
    t('List.Max({1, "a"})', 'ERR'); t('List.Median({1, 2, 3, 4})', 2.5); t('List.Median({5, 1, 3})', 3); t('List.Median({})', None)
    t('List.Average({1, 2, 6})', 3.0); t('List.Average({})', None); t('List.Average({1, null})', 'UNSUP')
    t('List.Count(List.Distinct({"a", "b", "a", null, null}))', 3); t('List.Contains({"a", "b"}, null)', False); t('List.Contains({"a", "b"}, "b")', True)
    t('List.Transform({1, 2}, each _ * 2)', [2, 4]); t('List.Select({1, null, "", "x"}, each _ <> null and _ <> "")', [1, 'x'])
    t('List.Select({1, null}, each _ > 0)', 'ERR'); t('List.IsEmpty(List.RemoveNulls({null}))', True)
    # library: every call is checked against Microsoft's signatures
    t('Table.RowCount()', 'ERR'); t('Table.RowCount(T, 1)', 'ERR'); t('Table.RowCount(null)', 'ERR'); t('Table.RowCount({1})', 'ERR')
    t('List.Count(T)', 'ERR'); t('Text.Trim(5)', 'ERR'); t('Text.Trim(null)', None); t('Table.SelectRows(T, 5)', 'ERR')
    t('Date.AddMonths(#date(2024, 1, 1), null)', 'ERR'); t('List.Dates(null, 1, #duration(1, 0, 0, 0))', 'ERR'); t('Table.Rowcount(T)', 'ERR')
    # library: tables
    t('Table.RowCount(T)', 4); t('T[n]', [1, None, 3, 5]); t('T[zz]', 'ERR'); t('T{0}[t]', 'a'); t('T{[t = "b"]}[n]', None)
    t('T{[t = "a"]}', 'ERR'); t('T{[t = "zz"]}', 'ERR')
    t('Table.RowCount(Table.SelectRows(T, each [n] <> null and [n] > 1))', 2); t('Table.RowCount(Table.SelectRows(T, each [t] = "a"))', 2)
    t('Table.SelectRows(T, each [zz] = 1)', 'ERR'); t('Table.RowCount(Table.SelectRows(T, each [t]))', 'ERR')
    t('Table.ColumnNames(Table.RenameColumns(T, {{"n", "N"}, {"zz", "ZZ"}}, MissingField.Ignore))', ['N', 't'])
    t('Table.RenameColumns(T, {{"zz", "ZZ"}})', 'ERR'); t('Table.ColumnNames(Table.SelectColumns(T, {"t", "q"}, MissingField.UseNull))', ['t', 'q'])
    t('Table.SelectColumns(T, {"t", "q"})', 'ERR'); t('Table.AddColumn(T, "d", each [n] * 2)[d]', [2, None, 6, 10]); t('Table.AddColumn(T, "n", each 1)', 'ERR')
    t('Table.TransformColumns(T, {{"t", each if _ = null then "?" else _ & "!", type text}})[t]', ['a!', 'b!', '?', 'a!'])
    t('Table.Sort(Table.Group(Table.SelectRows(T, each [t] <> null), {"t"}, {{"c", each Table.RowCount(_), Int64.Type}}), '
      '{{"c", Order.Descending}, {"t", Order.Ascending}}){0}[t]', 'a')
    t('Table.Sort(T, {{"n", Order.Descending}})[n]', [5, 3, 1, None]); t('Table.Sort(T, {{"t", Order.Ascending}, {"n", Order.Descending}})[n]', [3, 5, 1, None])
    t('Table.FromRows({{1, "x"}, {2, "y"}}, {"a", "b"})[b]', ['x', 'y']); t('Table.FromRows({{1, "x"}}, {"a"})', 'ERR')
    t('Table.FromRows({{1, "x"}}, type table [No = Int64.Type, #"Text Value" = nullable text]){0}[Text Value]', 'x')
    t('Table.TransformColumnTypes(Table.FromRows({{"5"}, {"x"}, {null}, {2.5}}, {"a"}), {{"a", Int64.Type}}){0}[a]', 5)
    t('Table.TransformColumnTypes(Table.FromRows({{"5"}, {"x"}}, {"a"}), {{"a", Int64.Type}})[a]', 'ERR')              # an error cell is read
    t('Table.Buffer(Table.TransformColumnTypes(Table.FromRows({{"x"}}, {"a"}), {{"a", Int64.Type}}))', 'ERR')
    t('Table.ReplaceErrorValues(Table.TransformColumnTypes(Table.FromRows({{"5"}, {"x"}, {null}, {2.5}, {3.5}}, {"a"}), {{"a", Int64.Type}}), '
      '{{"a", null}})[a]', [5, None, None, 2, 4])
    t('Table.TransformColumnTypes(Table.FromRows({{#datetime(2024, 5, 1, 0, 0, 0)}, {"n/a"}}, {"d"}), {{"d", type date}}){0}[d]', dt.date(2024, 5, 1))
    t('Table.TransformColumnTypes(Table.FromRows({{1}}, {"a"}), {{"zz", type text}})', 'ERR')
    t('Table.FromList({1, 2}, Splitter.SplitByNothing(), {"Date"})[Date]', [1, 2]); t('Table.RowCount(Table.Buffer(T))', 4)
    t('Table.IsEmpty(Table.SelectRows(T, each false))', True)
    t('Record.FieldOrDefault([a = "x"], "a", "d") & Record.FieldOrDefault([a = "x"], "q", "d")', 'xd'); t('Record.Field([a = 1], "q")', 'ERR')
    t('Number.ToText(0.6125, "0.0%", "en-US")', '61.3%'); t('Number.ToText(1200, "#,##0", "en-US")', '1,200')
    t('Number.ToText(27.0775, "0.0", "en-US")', '27.1'); t('Number.ToText(1.148325, "0.00", "en-US")', '1.15')
    t('Number.ToText(-0.162162, "0.0%", "en-US")', '-16.2%'); t('Text.From(3) & "/" & Text.From(2.5)', '3/2.5')
    t('let Source = T, CountIf = (c as function) as number => Table.RowCount(Table.SelectRows(Source, c)) '
      'in CountIf(each [t] = "a") / CountIf(each [n] <> null)', 2 / 3)
    t('try 1 otherwise 2', 'UNSUP')
    return result


if __name__ == '__main__':
    r = run_tests('-v' in sys.argv)
    print(f'mini_m unit tests: {r["passed"]} passed, {r["failed"]} failed')
    sys.exit(1 if r['failed'] else 0)
