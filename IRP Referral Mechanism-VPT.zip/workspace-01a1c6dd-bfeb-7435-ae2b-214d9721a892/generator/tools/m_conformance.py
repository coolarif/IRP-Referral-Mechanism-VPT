#!/usr/bin/env python3
"""
m_conformance.py - does mini_m.py behave like the real Power Query engine?

For every library function that mini_m implements, the page of Microsoft's M function reference is downloaded
(learn.microsoft.com/powerquery-m/<function>) and each documented example is run: the "Usage" expression and the
"Output" expression are both evaluated by mini_m and compared.  Examples that need features mini_m does not implement
are reported as "not runnable" - they neither confirm nor contradict anything.
"""
import glob
import os
import re
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import mini_m as MM                                    # noqa: E402

DOCS = '/tmp/mrd_m_docs'


def slug(name):
    return (('sharp' + name[1:]) if name.startswith('#') else name).lower().replace('.', '-')


def download(names):
    os.makedirs(DOCS, exist_ok=True)
    missing = []
    for n in names:
        f = os.path.join(DOCS, slug(n) + '.md')
        if os.path.exists(f) and os.path.getsize(f) > 300:
            continue
        url = f'https://learn.microsoft.com/en-us/powerquery-m/{slug(n)}?accept=text/markdown'
        r = subprocess.run(['curl', '-s', '-L', '--max-time', '40', '-o', f, '-w', '%{http_code}', url], capture_output=True, text=True)
        if r.stdout.strip() != '200' or os.path.getsize(f) < 300:
            missing.append(n)
            if os.path.exists(f):
                os.remove(f)
    return missing


def examples(md):
    md = md.replace('\r\n', '\n')
    out = []
    for m in re.finditer(r'\*\*Usage\*\*\s*\n+```[a-z-]*\n(.*?)\n```\s*\n+\*\*Output\*\*\s*\n+(?:```[a-z-]*\n(.*?)\n```|`([^`\n]*)`)', md, re.S):
        out.append((m.group(1).strip(), (m.group(2) if m.group(2) is not None else m.group(3)).strip()))
    n_usage = len(re.findall(r'\*\*Usage\*\*', md))
    return out, n_usage

def run(I, src):
    try:
        return I.run(src), None
    except MM.MUnsupported as e:
        return None, 'unsupported: ' + str(e)[:110]
    except MM.MRuntimeError as e:
        return None, 'M error: ' + str(e)[:110]
    except SyntaxError as e:
        return None, 'syntax: ' + str(e)[:110]

def main(verbose=True):
    I = MM.Interp()
    names = sorted(n for n in I.implemented if I.signatures[n]['kind'] in (3, 4) or n.startswith('#'))
    missing = download(names)
    stats = {'pass': 0, 'fail': 0, 'skip': 0, 'functions': len(names), 'pages_missing': len(missing)}
    rows = []
    for f in sorted(glob.glob(os.path.join(DOCS, '*.md'))):
        md = open(f, encoding='utf-8').read()
        title = re.search(r'^# (\S+)', md, re.M).group(1)
        exs, n_usage = examples(md)
        res = []
        for usage, output in exs:
            a, ea = run(I, usage)
            if output.startswith('[Expression.Error]'):                      # the documented result is an error
                res.append(('pass' if (ea or '').startswith('M error') else 'fail', usage, output, ea or f'no error, got {a!r}'[:120]))
                continue
            b, eb = run(I, output)
            if ea or eb:
                both = (ea or '') + (eb or '')
                kind = 'skip' if ((ea or '').startswith(('unsupported', 'syntax')) or (eb or '').startswith(('unsupported', 'syntax'))
                                  or "wasn't recognized" in both or 'DataSource.Error' in both) else 'fail'
                res.append((kind, usage, output, ea or eb))
            else:
                good = MM.deep_equal(a, b)
                res.append(('pass' if good else 'fail', usage, output, None if good else f'got {a!r}'[:160]))
        for r in res:
            stats[r[0]] += 1
        rows.append((title, n_usage, res))
    stats['functions_confirmed'] = sum(1 for _t, _n, res in rows if any(r[0] == 'pass' for r in res))
    if verbose:
        for title, n_usage, res in rows:
            line = ' '.join({'pass': 'P', 'fail': 'F', 'skip': 's'}[r[0]] for r in res)
            print(f'{title:28s} examples on page={n_usage} parsed={len(res)}  {line}')
            for kind, usage, output, why in res:
                if kind != 'pass':
                    print(f'      {kind.upper()}: {why}\n         usage : {" ".join(usage.split())[:150]}\n         output: {" ".join(output.split())[:120]}')
    print('TOTAL', stats)
    return stats, rows

if __name__ == '__main__':
    main()
