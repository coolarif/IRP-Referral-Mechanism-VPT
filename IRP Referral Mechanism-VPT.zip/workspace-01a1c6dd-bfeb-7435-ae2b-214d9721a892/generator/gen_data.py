"""
Synthetic maternal-referral register generator.
Schema + dropdown values follow the user's template image (spelling normalised).
All records are fictitious. Deterministic (fixed seed).
"""
import datetime as dt
import math
import numpy as np
import pandas as pd

SEED = 20261110
N_ROWS = 1200
N_PATIENTS = 1045
START = dt.date(2024, 11, 1)
END = dt.date(2026, 10, 31)

# ----------------------------------------------------------------------------
# Lists ("filter data" from the template image; 'a' placeholder slots ignored)
# ----------------------------------------------------------------------------
SITES = ['Ali Akber Shah', 'Ibrahim Hyderi', 'Rehri Goth', 'Bhains Colony']
SITE_PREFIX = {'Ali Akber Shah': 'AB', 'Ibrahim Hyderi': 'IH', 'Rehri Goth': 'RG', 'Bhains Colony': 'BC'}
SITE_W = [0.30, 0.28, 0.24, 0.18]
YESNO = ['Yes', 'No']
PRIORITY = ['Routine', 'Emergency']
HISTORY = ['Still Birth', 'Miscarriage', 'Neonatal Death', 'Placenta Previa', 'Placenta Abruptio',
           'Pregnancy Induced Hypertension', 'Other']
CONDITION = ['Stable', 'Unstable']
REASONS = ['PPH-Post Partum Hemorrhage', 'Preeclampsia', 'Eclampsia', 'Obstructed Labor', 'Sepsis',
           'Severe Anemia', 'Placenta Abruptio', 'Placenta Previa', 'Uterine Rupture', 'Other']
SHIFTS = ['Morning', 'Evening', 'Night']
STAFF = ['Samina', 'Sadia', 'Rukhsana', 'Rabia', 'Sumaira', 'Ambreen', 'Naheed', 'Shelina', 'Shehnaz',
         'Bakhtawar', 'Sonia', 'Fahmida', 'Salwa', 'Anousha', 'Warda']
FACILITIES = ['JPMC', 'Creek', 'PPHI', 'AKUH', 'Mamji', 'RDA', 'PTO', 'Sindh', 'KMC', 'EDHI', 'SAYLANI']
REFUSAL_REASONS = ['Financial Constraint', 'Previous bad Experience', 'Fear of procedure',
                   'Not Satisfied with services', 'Cultural Issues', 'Distance issues', 'Other']
HF_REASONS = ["Patient's own complication", 'Bed occupancy', 'Infrastructure Issues', 'Staff unavailability', 'Other']
STATUS = ['Completed', 'Partial Complete', 'Incomplete']

COLUMNS = ['Patient ID', 'Patient Name', 'Husband Name', 'Age', 'Site', 'Date of Enrollment',
           'Gestational Age (wks)', 'Any anomaly in scan', 'Date of visit', 'Number of visit',
           'Referral Priority', 'Previous history', 'Condition on Arrival', 'Reason of Referral',
           'Referral Shift', 'Referred by staff name', 'Referred facility', 'Referral Accepted',
           'Reason for refusal', 'Refusal from HF', 'Reason of facility refusal', 'Referral Status']

FEMALE = """Ayesha Fatima Zainab Maryam Khadija Amna Sana Hina Nadia Saima Shazia Rubina Nasreen Parveen Shabana
Farzana Rukhsar Sakina Zubaida Haleema Hajra Kulsoom Sughra Naseem Shamim Tahira Uzma Asma Bushra Farah Gulnaz
Iqra Javeria Kiran Lubna Mehwish Nazia Sidra Tayyaba Zara Aliya Benazir Dua Erum Fozia Ghazala Humaira Irum
Jamila Komal Laiba Mahnoor Noreen Rida Sabeen Tehmina Yasmeen Zeenat Anum Nimra Saba Samreen Shaista Sumbul
Tasleem Zohra Hafsa Madiha Maham Mehreen Momina Muskan Nargis Neelam Rozina Rehana Razia Safia Salma Shagufta
Shahida Shama Shehla Sobia Sultana Tabassum Zahida Zakia Zarina Zulekha Marvi Sassi Moomal Hoor Aasiya Aqsa
Areeba Bisma Fiza Hira Huma Kainat Kinza Mahjabeen Naila Nida Noor Ramsha Sahar Saira Sehrish Shumaila Tania
Urooj Wajiha Zunaira Amina Haseena Hameeda Khursheed Latifa Mumtaz Rasheeda Saeeda Sajida Waheeda Jasmeen
Gulshan Hawa Jannat Mehrunnisa Nusrat Qamar Rahila Shireen Tanzila Yasmin Zaitoon Afshan Anila Asiya Durdana""".split()

MALE = """Ahmed Ali Hassan Hussain Abdullah Imran Kamran Rizwan Salman Usman Bilal Asif Arif Akbar Aslam Anwar
Bashir Dilawar Ghulam Habib Iqbal Javed Khalid Liaquat Majid Nadeem Naeem Noman Qasim Rashid Saleem Shahid
Tariq Waseem Yousuf Zahid Zubair Irfan Faisal Farhan Adnan Amir Azhar Fahad Hamza Junaid Kashif Mansoor
Mushtaq Nasir Pervez Rafiq Sajid Shakeel Tahir Umar Waqar Yasir Zafar Sikandar Nawaz Riaz Shabbir Sohail
Talha Wahid Yaqoob Ismail Ibrahim Idrees Ilyas Haroon Moosa Essa Dawood Suleman Ayub Younus Siddique Farooq
Usama Shoaib Naveed Nabeel Danish Shahzad Sarfaraz Mehboob Maqsood Manzoor Munawar Nisar Niaz Rehmat Rustam
Saeed Shafiq Sharif Sultan Wali Zaheer Zameer Bahadur Jameel Latif Mukhtar Nazeer Qadir Raheem Sattar Karim
Jabbar Ghaffar Hameed Hanif Inayat Lal Mithal Punhal Sajjan Dodo Gul Murad Sher Jan Bux Peeral""".split()

# reason -> probability
REASON_P = {'PPH-Post Partum Hemorrhage': 0.10, 'Preeclampsia': 0.17, 'Eclampsia': 0.05, 'Obstructed Labor': 0.09,
            'Sepsis': 0.06, 'Severe Anemia': 0.21, 'Placenta Abruptio': 0.05, 'Placenta Previa': 0.07,
            'Uterine Rupture': 0.02, 'Other': 0.18}
# reason -> list of (weight, mean, sd, lo, hi) gestational-age components (weeks)
GA_DIST = {
    'PPH-Post Partum Hemorrhage': [(1.0, 38.6, 1.8, 30, 41)],
    'Preeclampsia': [(1.0, 33.0, 3.6, 21, 40)],
    'Eclampsia': [(1.0, 34.0, 3.2, 22, 41)],
    'Obstructed Labor': [(1.0, 39.2, 1.3, 36, 42)],
    'Sepsis': [(0.3, 13.0, 4.0, 6, 22), (0.7, 35.0, 4.0, 24, 41)],
    'Severe Anemia': [(1.0, 25.0, 7.5, 8, 40)],
    'Placenta Abruptio': [(1.0, 33.0, 3.6, 22, 40)],
    'Placenta Previa': [(1.0, 31.0, 3.6, 20, 38)],
    'Uterine Rupture': [(1.0, 38.0, 1.8, 32, 42)],
    'Other': [(1.0, 21.0, 9.0, 6, 41)],
}
SITE_REASON_TILT = {
    'Ali Akber Shah': {},
    'Ibrahim Hyderi': {'Preeclampsia': 1.15, 'Placenta Previa': 1.1},
    'Rehri Goth': {'Severe Anemia': 1.30, 'Obstructed Labor': 1.20},
    'Bhains Colony': {'Sepsis': 1.25, 'PPH-Post Partum Hemorrhage': 1.1},
}
P_EMERGENCY = {'PPH-Post Partum Hemorrhage': 0.92, 'Preeclampsia': 0.22, 'Eclampsia': 0.97, 'Obstructed Labor': 0.80,
               'Sepsis': 0.55, 'Severe Anemia': 0.10, 'Placenta Abruptio': 0.88, 'Placenta Previa': 0.35,
               'Uterine Rupture': 1.00, 'Other': 0.08}
P_UNSTABLE_EMERG = {'PPH-Post Partum Hemorrhage': 0.60, 'Preeclampsia': 0.30, 'Eclampsia': 0.75, 'Obstructed Labor': 0.30,
                    'Sepsis': 0.50, 'Severe Anemia': 0.35, 'Placenta Abruptio': 0.55, 'Placenta Previa': 0.40,
                    'Uterine Rupture': 0.85, 'Other': 0.30}
AGE_DIST = {'Eclampsia': (23.0, 5.5), 'Uterine Rupture': (32.0, 4.5), 'Placenta Previa': (30.0, 5.5),
            'PPH-Post Partum Hemorrhage': (28.5, 6.0)}
HISTORY_P = {'Still Birth': 0.13, 'Miscarriage': 0.27, 'Neonatal Death': 0.09, 'Placenta Previa': 0.06,
             'Placenta Abruptio': 0.05, 'Pregnancy Induced Hypertension': 0.17, 'Other': 0.23}
SHIFT_P = {'Routine': [0.68, 0.26, 0.06], 'Emergency': [0.36, 0.34, 0.30]}
# site -> staff -> (workload weight, (morning, evening, night) affinity)
STAFF_SITE = {
    'Ali Akber Shah': {'Samina': (1.3, (1.5, 0.7, 0.2)), 'Sadia': (1.0, (1.1, 1.2, 0.5)),
                       'Rukhsana': (0.9, (0.5, 1.4, 1.3)), 'Rabia': (0.8, (0.4, 0.9, 2.2))},
    'Ibrahim Hyderi': {'Sumaira': (1.2, (1.5, 0.7, 0.2)), 'Ambreen': (1.0, (1.1, 1.2, 0.5)),
                       'Naheed': (0.9, (0.6, 1.5, 0.9)), 'Shelina': (0.7, (0.4, 0.8, 2.4))},
    'Rehri Goth': {'Shehnaz': (1.2, (1.5, 0.7, 0.2)), 'Bakhtawar': (1.0, (1.1, 1.2, 0.5)),
                   'Sonia': (0.8, (0.6, 1.3, 1.3)), 'Fahmida': (0.7, (0.4, 0.8, 2.3))},
    'Bhains Colony': {'Salwa': (1.2, (1.4, 1.0, 0.4)), 'Anousha': (1.0, (1.0, 1.1, 1.0)),
                      'Warda': (0.8, (0.6, 1.2, 1.8))},
}
FAC_P = {
    'Routine':   {'JPMC': .11, 'Creek': .11, 'PPHI': .16, 'AKUH': .05, 'Mamji': .07, 'RDA': .07, 'PTO': .06,
                  'Sindh': .13, 'KMC': .11, 'EDHI': .06, 'SAYLANI': .07},
    'Emergency': {'JPMC': .29, 'Creek': .15, 'PPHI': .03, 'AKUH': .12, 'Mamji': .05, 'RDA': .03, 'PTO': .02,
                  'Sindh': .15, 'KMC': .09, 'EDHI': .04, 'SAYLANI': .03},
}
SITE_FAC_TILT = {
    'Ali Akber Shah': {'Creek': 1.3},
    'Ibrahim Hyderi': {'Creek': 1.5, 'JPMC': 1.1},
    'Rehri Goth': {'PPHI': 1.4, 'Sindh': 1.2},
    'Bhains Colony': {'Sindh': 1.5, 'KMC': 1.2},
}
HF_REFUSE_P = {'JPMC': .14, 'Sindh': .12, 'KMC': .11, 'PPHI': .11, 'Creek': .07, 'AKUH': .03, 'Mamji': .06,
               'RDA': .09, 'PTO': .09, 'EDHI': .08, 'SAYLANI': .08}
PRIVATE = {'AKUH', 'Mamji'}
PUBLIC = {'JPMC', 'Sindh', 'KMC'}
SMALL = {'PPHI', 'EDHI', 'SAYLANI', 'RDA', 'PTO'}


def _norm_pdf(x, m, s):
    return math.exp(-0.5 * ((x - m) / s) ** 2) / (s * math.sqrt(2 * math.pi))


def ga_likelihood(reason, ga):
    tot = 0.0
    for w, m, s, lo, hi in GA_DIST[reason]:
        if lo <= ga <= hi:
            tot += w * _norm_pdf(ga, m, s)
    return tot


def pick(rng, options, weights):
    w = np.asarray(weights, dtype=float)
    w = w / w.sum()
    return options[int(rng.choice(len(options), p=w))]


def draw_ga(rng, reason):
    comps = GA_DIST[reason]
    w, m, s, lo, hi = comps[int(rng.choice(len(comps), p=[c[0] for c in comps]))]
    for _ in range(200):
        g = int(round(rng.normal(m, s)))
        if lo <= g <= hi:
            return g
    return int(round(min(max(m, lo), hi)))


def draw_visit_dates(rng, n):
    """Visit dates over the 24-month window: upward trend, mild seasonality, fewer Sunday referrals."""
    months = pd.period_range(START, END, freq='M')
    k = len(months)
    w = np.linspace(0.74, 1.26, k) * rng.normal(1.0, 0.07, k)
    for i, p in enumerate(months):
        if p.month in (7, 8):
            w[i] *= 0.93          # monsoon dip
        if p.month in (12, 1):
            w[i] *= 1.05
    w = w / w.sum()
    out = []
    m_idx = rng.choice(k, size=n, p=w)
    for mi in m_idx:
        p = months[int(mi)]
        days = pd.date_range(p.start_time.normalize(), p.end_time.normalize(), freq='D')
        dw = np.array([0.5 if d.weekday() == 6 else 1.0 for d in days])
        d = days[int(rng.choice(len(days), p=dw / dw.sum()))]
        out.append(d.date())
    return out


def clinical_record(rng, site, age, visit_date, ga, reason):
    """Draw every referral-level field given site / age / date / GA / reason."""
    t = (visit_date - START).days / max(1, (END - START).days)       # 0..1 position in window
    priority = 'Emergency' if rng.random() < P_EMERGENCY[reason] else 'Routine'
    p_unst = P_UNSTABLE_EMERG[reason] if priority == 'Emergency' else 0.04
    condition = 'Unstable' if rng.random() < p_unst else 'Stable'

    hw = dict(HISTORY_P)
    if reason in ('Preeclampsia', 'Eclampsia'):
        hw['Pregnancy Induced Hypertension'] *= 2.6
    if reason == 'Placenta Previa':
        hw['Placenta Previa'] *= 4.0
    if reason == 'Placenta Abruptio':
        hw['Placenta Abruptio'] *= 4.0
        hw['Pregnancy Induced Hypertension'] *= 1.5
    if reason == 'Severe Anemia':
        hw['Miscarriage'] *= 1.2
    history = pick(rng, HISTORY, [hw[h] for h in HISTORY])

    p_anom = {'Placenta Previa': 0.30, 'Placenta Abruptio': 0.22, 'Preeclampsia': 0.12, 'Other': 0.10}.get(reason, 0.07)
    if history in ('Still Birth', 'Neonatal Death'):
        p_anom *= 1.3
    if age >= 35:
        p_anom *= 1.5
    anomaly = 'Yes' if rng.random() < min(p_anom, 0.9) else 'No'

    shift = pick(rng, SHIFTS, SHIFT_P[priority])
    staff_tbl = STAFF_SITE[site]
    names = list(staff_tbl)
    sidx = SHIFTS.index(shift)
    staff = pick(rng, names, [staff_tbl[s][0] * staff_tbl[s][1][sidx] for s in names])

    fw = dict(FAC_P[priority])
    for f, m in SITE_FAC_TILT[site].items():
        fw[f] *= m
    facility = pick(rng, FACILITIES, [fw[f] for f in FACILITIES])

    # --- patient acceptance of the referral --------------------------------
    p_acc = 0.93 if priority == 'Emergency' else 0.80
    if facility == 'AKUH':
        p_acc -= 0.13
    if facility == 'Mamji':
        p_acc -= 0.05
    p_acc += {'Rehri Goth': -0.05, 'Bhains Colony': -0.02}.get(site, 0.0)
    if shift == 'Night':
        p_acc -= 0.04
    if condition == 'Unstable':
        p_acc += 0.03
    if age < 20:
        p_acc -= 0.03
    p_acc += 0.06 * (t - 0.5)
    p_acc = min(max(p_acc, 0.40), 0.99)
    accepted = 'Yes' if rng.random() < p_acc else 'No'

    refusal_reason = None
    hf_refusal = 'No'
    hf_reason = None
    if accepted == 'No':
        rw = {'Financial Constraint': 0.30, 'Previous bad Experience': 0.10, 'Fear of procedure': 0.15,
              'Not Satisfied with services': 0.08, 'Cultural Issues': 0.13, 'Distance issues': 0.18, 'Other': 0.06}
        if facility in PRIVATE:
            rw['Financial Constraint'] *= 2.2
        if facility in PUBLIC:
            rw['Previous bad Experience'] *= 1.6
            rw['Not Satisfied with services'] *= 1.6
        if site == 'Rehri Goth':
            rw['Distance issues'] *= 1.8
        if shift == 'Night':
            rw['Cultural Issues'] *= 1.6
            rw['Distance issues'] *= 1.3
        if priority == 'Emergency':
            rw['Fear of procedure'] *= 1.4
        refusal_reason = pick(rng, REFUSAL_REASONS, [rw[r] for r in REFUSAL_REASONS])
        status = 'Incomplete'
    else:
        p_hf = HF_REFUSE_P[facility]
        if shift == 'Night':
            p_hf *= 1.5
        if priority == 'Emergency':
            p_hf *= 1.15
        if condition == 'Unstable':
            p_hf *= 1.2
        p_hf *= (1.10 - 0.20 * t)                       # slow improvement over time
        if rng.random() < min(p_hf, 0.5):
            hf_refusal = 'Yes'
            qw = {"Patient's own complication": 0.16, 'Bed occupancy': 0.36, 'Infrastructure Issues': 0.18,
                  'Staff unavailability': 0.22, 'Other': 0.08}
            if facility in ('JPMC', 'Sindh'):
                qw['Bed occupancy'] *= 1.8
            if shift == 'Night':
                qw['Staff unavailability'] *= 2.0
            if facility in SMALL:
                qw['Infrastructure Issues'] *= 1.8
                qw["Patient's own complication"] *= 1.5
            if condition == 'Unstable':
                qw["Patient's own complication"] *= 1.6
            hf_reason = pick(rng, HF_REASONS, [qw[r] for r in HF_REASONS])
            status = 'Incomplete' if rng.random() < 0.72 else 'Partial Complete'
        else:
            p_done = 0.84 + (0.04 if priority == 'Emergency' else 0.0) + 0.05 * (t - 0.5)
            p_part = 0.11 + (0.03 if condition == 'Unstable' else 0.0)
            u = rng.random()
            status = 'Completed' if u < p_done else ('Partial Complete' if u < p_done + p_part else 'Incomplete')

    return dict(anomaly=anomaly, priority=priority, history=history, condition=condition, reason=reason,
                shift=shift, staff=staff, facility=facility, accepted=accepted, refusal_reason=refusal_reason,
                hf_refusal=hf_refusal, hf_reason=hf_reason, status=status)


def generate():
    rng = np.random.default_rng(SEED)
    first_dates = draw_visit_dates(rng, N_PATIENTS)
    patients = []
    records = []           # dicts with patient index

    for pi in range(N_PATIENTS):
        site = pick(rng, SITES, SITE_W)
        rw = dict(REASON_P)
        for r, m in SITE_REASON_TILT[site].items():
            rw[r] *= m
        reason = pick(rng, REASONS, [rw[r] for r in REASONS])
        ga = draw_ga(rng, reason)
        am, asd = AGE_DIST.get(reason, (27.0, 5.8))
        age = int(round(min(max(rng.normal(am, asd), 15), 45)))
        vdate = first_dates[pi]
        # visit number at the time of referral
        lam = min(max((ga - 8) / 8.0, 0.0), 4.2) * rng.beta(4, 2)
        n_visit = 1 + int(rng.poisson(lam))
        n_visit = int(min(n_visit, 1 + ((ga - 5) * 7) // 14, 9))
        n_visit = max(n_visit, 1)
        if n_visit == 1:
            back = 0 if rng.random() < 0.85 else int(rng.integers(1, 8))
        else:
            back = int(sum(min(max(rng.normal(26, 6), 14), 40) for _ in range(n_visit - 1)))
            back = min(back, (ga - 5) * 7)
        back = max(0, min(back, (ga - 4) * 7))
        enroll = vdate - dt.timedelta(days=back)
        patients.append(dict(site=site, age=age, enroll=enroll,
                             name=FEMALE[int(rng.integers(len(FEMALE)))],
                             husband=MALE[int(rng.integers(len(MALE)))]))
        rec = clinical_record(rng, site, age, vdate, ga, reason)
        rec.update(pi=pi, vdate=vdate, ga=ga, n_visit=n_visit, seq=len(records))
        records.append(rec)

    # --- the sample row from the user's template: AB-1234 / Jasmeen / Bahadur / 25 / Ali Akber Shah ------
    patients[0].update(site='Ali Akber Shah', age=25, enroll=START, name='Jasmeen', husband='Bahadur')
    records[0].update(vdate=START, ga=24, n_visit=1, anomaly='No', priority='Routine', history='Still Birth',
                      condition='Stable', reason='Severe Anemia', shift='Morning', staff='Samina', facility='JPMC',
                      accepted='Yes', refusal_reason=None, hf_refusal='No', hf_reason=None, status='Completed')

    # --- repeat referrals (same patient, later visit in the same pregnancy) ---------------------------------
    eligible_reasons = {'Severe Anemia', 'Preeclampsia', 'Placenta Previa', 'Other'}
    base = list(records)
    order = rng.permutation(len(base))
    n_needed = N_ROWS - N_PATIENTS
    added = 0
    queue = [base[i] for i in order]
    qi = 0
    while added < n_needed and qi < len(queue):
        r1 = queue[qi]
        qi += 1
        if r1['reason'] not in eligible_reasons or r1['ga'] > 33:
            continue
        gap = int(rng.integers(21, 71))
        ga2 = r1['ga'] + int(round(gap / 7.0))
        d2 = r1['vdate'] + dt.timedelta(days=gap)
        if ga2 > 41 or d2 > END:
            continue
        p = patients[r1['pi']]
        rw = {}
        for r in REASONS:
            w = REASON_P[r] * ga_likelihood(r, ga2)
            if r1['reason'] == 'Preeclampsia' and r == 'Eclampsia':
                w *= 3.0
            if r1['reason'] == 'Preeclampsia' and r == 'Preeclampsia':
                w *= 2.0
            if r1['reason'] == 'Placenta Previa' and r == 'Placenta Previa':
                w *= 3.0
            if r1['reason'] == 'Placenta Previa' and r == 'PPH-Post Partum Hemorrhage':
                w *= 1.5
            if r1['reason'] == 'Severe Anemia' and r == 'Severe Anemia':
                w *= 2.0
            rw[r] = w
        if sum(rw.values()) <= 0:
            continue
        reason2 = pick(rng, REASONS, [rw[r] for r in REASONS])
        rec = clinical_record(rng, p['site'], p['age'], d2, ga2, reason2)
        extra = 1 + int(rng.integers(0, max(1, gap // 24)))
        rec.update(pi=r1['pi'], vdate=d2, ga=ga2, n_visit=min(r1['n_visit'] + extra, 12), seq=len(records))
        records.append(rec)
        added += 1
        if rng.random() < 0.12 and reason2 in eligible_reasons:     # a few women are referred a third time
            queue.append(rec)
    assert added == n_needed, (added, n_needed)

    # --- patient IDs: site prefix + running number in order of enrolment --------------------------------
    for site in SITES:
        idx = [i for i, p in enumerate(patients) if p['site'] == site]
        idx.sort(key=lambda i: (patients[i]['enroll'], i))
        if site == 'Ali Akber Shah':
            start_no = 1234 - idx.index(0)            # sample patient (index 0) becomes AB-1234
        else:
            start_no = 1001
        for k, i in enumerate(idx):
            patients[i]['pid'] = f"{SITE_PREFIX[site]}-{start_no + k:04d}"

    records.sort(key=lambda r: (r['vdate'], 0 if r['seq'] == 0 else 1, r['seq']))
    rows = []
    for r in records:
        p = patients[r['pi']]
        rows.append([p['pid'], p['name'], p['husband'], p['age'], p['site'], p['enroll'], r['ga'], r['anomaly'],
                     r['vdate'], r['n_visit'], r['priority'], r['history'], r['condition'], r['reason'], r['shift'],
                     r['staff'], r['facility'], r['accepted'], r['refusal_reason'], r['hf_refusal'], r['hf_reason'],
                     r['status']])
    df = pd.DataFrame(rows, columns=COLUMNS)
    return df


def validate(df):
    assert len(df) == N_ROWS
    assert list(df.columns) == COLUMNS
    assert df['Patient ID'].str.match(r'^(AB|IH|RG|BC)-\d{4}$').all()
    assert df.iloc[0][['Patient ID', 'Patient Name', 'Husband Name', 'Age', 'Site']].tolist() == \
        ['AB-1234', 'Jasmeen', 'Bahadur', 25, 'Ali Akber Shah']
    # one identity per patient id
    g = df.groupby('Patient ID')
    for c in ['Patient Name', 'Husband Name', 'Age', 'Site', 'Date of Enrollment']:
        assert (g[c].nunique() == 1).all(), c
    assert (df['Date of Enrollment'] <= df['Date of visit']).all()
    assert df['Date of visit'].min() == START and df['Date of visit'].max() <= END
    assert df['Gestational Age (wks)'].between(5, 42).all()
    assert df['Age'].between(15, 45).all()
    assert (df['Number of visit'] >= 1).all()
    # gestational age at enrolment must be >= 4 weeks
    ga_enrol = df['Gestational Age (wks)'] - (pd.to_datetime(df['Date of visit']) - pd.to_datetime(df['Date of Enrollment'])).dt.days / 7
    assert (ga_enrol >= 3.9).all(), ga_enrol.min()
    for col, allowed in [('Site', SITES), ('Any anomaly in scan', YESNO), ('Referral Priority', PRIORITY),
                         ('Previous history', HISTORY), ('Condition on Arrival', CONDITION),
                         ('Reason of Referral', REASONS), ('Referral Shift', SHIFTS),
                         ('Referred by staff name', STAFF), ('Referred facility', FACILITIES),
                         ('Referral Accepted', YESNO), ('Refusal from HF', YESNO), ('Referral Status', STATUS)]:
        assert df[col].isin(allowed).all(), col
        assert set(df[col]) == set(allowed), (col, set(allowed) - set(df[col]))
    acc = df['Referral Accepted'] == 'Yes'
    hf = df['Refusal from HF'] == 'Yes'
    assert df.loc[acc, 'Reason for refusal'].isna().all()
    assert df.loc[~acc, 'Reason for refusal'].isin(REFUSAL_REASONS).all()
    assert set(df.loc[~acc, 'Reason for refusal']) == set(REFUSAL_REASONS)
    assert not (hf & ~acc).any()
    assert df.loc[hf, 'Reason of facility refusal'].isin(HF_REASONS).all()
    assert set(df.loc[hf, 'Reason of facility refusal']) == set(HF_REASONS)
    assert df.loc[~hf, 'Reason of facility refusal'].isna().all()
    assert (df.loc[~acc, 'Referral Status'] == 'Incomplete').all()
    assert (df.loc[hf, 'Referral Status'] != 'Completed').all()
    # repeat referrals: later visit => higher visit number and consistent gestational age
    for pid, grp in g:
        if len(grp) > 1:
            grp = grp.sort_values('Date of visit')
            assert grp['Number of visit'].is_monotonic_increasing and grp['Number of visit'].is_unique, pid
            d = (pd.to_datetime(grp['Date of visit']).diff().dt.days.dropna() / 7).round().values
            gdiff = grp['Gestational Age (wks)'].diff().dropna().values
            assert (abs(d - gdiff) <= 1).all(), pid
    # every month of the window has data
    months = pd.to_datetime(df['Date of visit']).dt.to_period('M')
    assert months.nunique() == 24
    return True


if __name__ == '__main__':
    df = generate()
    validate(df)
    df.to_pickle('referrals.pkl')
    print('rows', len(df), '| unique patients', df['Patient ID'].nunique())
    pd.set_option('display.width', 250, 'display.max_columns', 30)
    print(df.head(6).to_string())
