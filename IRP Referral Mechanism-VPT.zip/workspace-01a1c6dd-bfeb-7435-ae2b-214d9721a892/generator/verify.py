#!/usr/bin/env python3
"""
Independent verification of the workbook "IRP Referral Mechanism-VPT.xlsx" and of the Power BI code files.

1. RECALC   - for several filter scenarios the workbook is built with every cached formula result replaced by a
              sentinel (-999), recalculated from scratch by LibreOffice, and each of the ~3,600 formula results is
              compared with the value computed independently in Python (pandas).
2. STRUCT   - the delivered file: sheet order, table, defined names, structured references, data validations, charts,
              and that nothing in the package still refers to the removed sheets (KPIs, Power Query M, DAX Measures).
3. M        - every Power Query query of the text files is parsed with Microsoft's own parser
              (@microsoft/powerquery-parser), every library name it uses is looked up in Microsoft's published library
              definition, and the single-KPI queries are pretty-printed with Microsoft's formatter.
4. MEXEC    - the delivered M text files are EXECUTED by a small M interpreter (tools/mini_m.py - not Microsoft's
              engine, but it checks every library call against the official signatures) on a clean register, a messy
              register and one with text typed into number/date cells; all KPI values are compared with independently
              calculated values.
   MENGINE  - the interpreter itself is tested: its own unit tests, plus the examples of Microsoft's M function
              reference (downloaded from learn.microsoft.com) for every library function it implements.
5. DAX      - every measure, and the delivered DAX text file as a whole, is parsed by SQLBI's DAX Formatter service.

Needs: LibreOffice (soffice), node + npm, internet access for the DAX Formatter.  Work files go to /tmp.
Run:   python3 -W ignore verify.py            (or any of: recalc dax struct m mexec)
"""
import datetime as dt
import html
import json
import math
import os
import re
import shutil
import subprocess
import sys
import urllib.request
import zipfile

import openpyxl

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import build_workbook as B                      # noqa: E402
import gen_data as L                            # noqa: E402

SCRATCH = '/tmp/mrd_verify'
LO_PROFILE_DIR = '/tmp/mrd_lo_profile'
LO_PROFILE = 'file://' + LO_PROFILE_DIR
PQ_DIR = '/tmp/mrd_pq'
EPOCH = dt.datetime(1899, 12, 30)

# LibreOffice profile that recalculates every formula when a file is loaded (0 = always)
LO_SETTINGS = '''<?xml version="1.0" encoding="UTF-8"?>
<oor:items xmlns:oor="http://openoffice.org/2001/registry" xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
<item oor:path="/org.openoffice.Office.Calc/Formula/Load"><prop oor:name="ODFRecalcMode" oor:op="fuse"><value>0</value></prop></item>
<item oor:path="/org.openoffice.Office.Calc/Formula/Load"><prop oor:name="OOXMLRecalcMode" oor:op="fuse"><value>0</value></prop></item>
</oor:items>
'''


def ensure_lo_profile():
    f = os.path.join(LO_PROFILE_DIR, 'user', 'registrymodifications.xcu')
    if not os.path.exists(f):
        os.makedirs(os.path.dirname(f), exist_ok=True)
        open(f, 'w').write(LO_SETTINGS)


def ensure_pq_parser():
    os.makedirs(PQ_DIR, exist_ok=True)
    for js in ('pqcheck.js', 'pqformat.js'):
        shutil.copy(os.path.join(HERE, 'tools', js), os.path.join(PQ_DIR, js))
    have = all(os.path.isdir(os.path.join(PQ_DIR, 'node_modules', '@microsoft', pkg)) for pkg in ('powerquery-parser', 'powerquery-formatter'))
    if not have:
        subprocess.run(['npm', 'install', '--silent', '--no-audit', '--no-fund', '@microsoft/powerquery-parser@0.18.4',
                        '@microsoft/powerquery-formatter@0.3.19'], cwd=PQ_DIR, check=True, capture_output=True, text=True)


def dirty(df):
    """Messy register: blanks in every kind of column, values missing from the dropdown lists, rows without a
    Patient ID, completely empty rows, date errors and refusals without a reason."""
    from kpis import (PID, AGE, SITE, ENR, GA, VIS, NVIS, PRI, COND, REAS, STAFF, FAC, ACC, RREF, HFR, HFREAS, STAT)
    ix = df.index
    for c in (AGE, GA, NVIS):
        df[c] = df[c].astype(float)

    def setv(rows, col, val):
        for r in rows:
            df.at[ix[r], col] = val
    setv(range(5, 10), AGE, float('nan'))
    setv(range(10, 13), GA, float('nan'))
    setv(range(13, 15), NVIS, float('nan'))
    setv(range(20, 23), VIS, None)
    setv(range(23, 25), ENR, None)
    setv([25], VIS, None)
    setv([25], ENR, None)
    for r in (30, 31):                                             # enrollment after the visit
        df.at[ix[r], ENR] = df.at[ix[r], VIS] + dt.timedelta(days=10)
    setv(range(40, 43), SITE, 'New Site X')                        # not in the Site list
    setv(range(43, 45), STAFF, None)
    setv([45], FAC, None)
    setv([46], PRI, None)
    setv([47], STAT, None)
    setv([48], COND, None)
    setv([49], REAS, None)
    setv([49], ACC, None)
    setv([i for i in range(100, 600) if df.at[ix[i], ACC] == 'No'][:3], RREF, None)
    setv([i for i in range(100, 900) if df.at[ix[i], HFR] == 'Yes'][:2], HFREAS, None)
    setv(range(60, 65), PID, None)                                 # rows without Patient ID are not records
    for r in (65, 66):                                             # completely empty rows inside the table
        for c in df.columns:
            df.at[ix[r], c] = float('nan') if c in (AGE, GA, NVIS) else None
    setv([70], FAC, 'Unknown Hospital')                            # not in the Facility list
    setv([71, 72], STAFF, 'Temp Nurse')                            # not in the Staff list
    return df


def no_dates(df):
    """Register without any visit date in the rows in view (all visit dates of one site removed)."""
    from kpis import SITE, VIS
    df.loc[df[SITE] == 'Bhains Colony', VIS] = None
    return df


# name -> (dashboard filter values, optional data mutation)
SCENARIOS = {
    'A_default': ({}, None),
    'B_site_priority': ({'Site': 'Rehri Goth', 'Priority': 'Emergency'}, None),
    'C_dates_status': ({'DateFrom': dt.date(2025, 6, 1), 'DateTo': dt.date(2025, 12, 31), 'Status': 'Incomplete'}, None),
    'D_refusal_reason': ({'RefusalReason': 'Financial Constraint'}, None),
    'E_zero_rows': ({'Accepted': 'No', 'HFRefusal': 'Yes'}, None),
    'F_hf_reason_facility': ({'HFReason': 'Bed occupancy', 'Facility': 'JPMC'}, None),
    'G_small_slice': ({'Staff': L.STAFF[-1], 'Shift': 'Night', 'Anomaly': 'Yes'}, None),
    'H_one_month': ({'DateFrom': dt.date(2026, 10, 1), 'History': 'Other', 'Condition': 'Unstable'}, None),
    'I_dirty_no_filter': ({}, dirty),
    'J_dirty_date_to': ({'DateTo': dt.date(2025, 12, 31)}, dirty),
    'K_dirty_site_priority': ({'Site': 'Ali Akber Shah', 'Priority': 'Emergency'}, dirty),
    'L_no_visit_dates': ({'Site': 'Bhains Colony'}, no_dates),
}


def lo_recalc(path, outdir):
    ensure_lo_profile()
    os.makedirs(outdir, exist_ok=True)
    cmd = ['soffice', '--headless', '--norestore', f'-env:UserInstallation={LO_PROFILE}',
           '--convert-to', 'xlsx:Calc MS Excel 2007 XML', '--outdir', outdir, path]
    res = subprocess.run(cmd, capture_output=True, text=True, timeout=900)
    out = os.path.join(outdir, os.path.basename(path))
    if not os.path.exists(out):
        raise RuntimeError(f'LibreOffice failed: {res.stdout} {res.stderr}')
    return out


def norm(v):
    if isinstance(v, dt.datetime):
        return (v - EPOCH).total_seconds() / 86400
    if isinstance(v, dt.date):
        return (dt.datetime(v.year, v.month, v.day) - EPOCH).days
    if isinstance(v, dt.time):
        return (v.hour * 3600 + v.minute * 60 + v.second) / 86400
    if isinstance(v, bool):
        return int(v)
    return v


def same(exp, act):
    exp, act = norm(exp), norm(act)
    if exp == '' or exp is None:
        return act in ('', None)
    if isinstance(exp, (int, float)):
        if not isinstance(act, (int, float)):
            return False
        return abs(exp - act) <= 1e-9 * max(1.0, abs(exp))
    return exp == act


def compare(expected, recalculated):
    wb = openpyxl.load_workbook(recalculated, data_only=True)
    bad, poisoned = [], 0
    for (sheet, r, c), exp in expected.items():
        act = wb[sheet].cell(row=r + 1, column=c + 1).value
        if act == B.POISON:
            poisoned += 1
        if not same(exp, act):
            bad.append((sheet, B.xl_rowcol_to_cell(r, c), exp, act))
    return bad, poisoned


def run_recalc(names=None):
    shutil.rmtree(SCRATCH, ignore_errors=True)
    os.makedirs(SCRATCH + '/in', exist_ok=True)
    ok = True
    for name, (flt, mut) in SCENARIOS.items():
        if names and name not in names:
            continue
        src = f'{SCRATCH}/in/{name}.xlsx'
        expected, info = B.build(src, filters=flt, poison=True, quiet=True, mutate=mut)
        out = lo_recalc(src, f'{SCRATCH}/out')
        bad, poisoned = compare(expected, out)
        status = 'OK ' if not bad and not poisoned else 'FAIL'
        ok &= (status == 'OK ')
        print(f'RECALC {status} {name:22s} rows in view={info["in_view"]:5d}  formulas checked={len(expected)}  mismatches={len(bad)}  '
              f'not recalculated={poisoned}')
        for b in bad[:12]:
            print('      ', b)
    return ok


def run_struct(path):
    ok = True
    wb = openpyxl.load_workbook(path)
    order = wb.sheetnames
    print('STRUCT sheets:', order)
    ok &= order == B.SHEETS and order[0] == 'Dashboard'
    ws = wb['Raw Data']
    tbl = ws.tables['tblReferrals']
    headers = [c.value for c in ws[1]]
    n_rows = ws.max_row - 1
    print(f'STRUCT table {tbl.name} ref={tbl.ref} data rows={n_rows} columns={len(headers)}')
    ok &= headers[:22] == L.COLUMNS and headers[22] == 'In Filter' and n_rows >= 1000
    tcols = [c.name for c in tbl.tableColumns]
    ok &= tcols == headers
    # every structured reference used anywhere must name an existing table column
    refs, unknown = set(), set()
    z = zipfile.ZipFile(path)
    for nm in z.namelist():
        if nm.endswith('.xml'):
            txt = z.read(nm).decode('utf-8')
            for m in re.finditer(r'tblReferrals\[(\[#This Row\],)?\[?([^\[\]]+)\]?\]', txt):
                col = m.group(2)
                refs.add(col)
                if col not in headers:
                    unknown.add(col)
    print(f'STRUCT structured references: {len(refs)} distinct columns referenced, unknown={sorted(unknown)}')
    ok &= not unknown
    names = sorted(wb.defined_names.keys()) if hasattr(wb.defined_names, 'keys') else sorted(d.name for d in wb.defined_names.definedName)
    need = [f'lst_{k}' for k, _, _ in B.LISTS] + [f'flt_{k}' for k, _, _ in B.LISTS] + [f'f_{k}' for k, _ in B.FILTERS] + \
           ['c_AllRows', 'c_Total', 'c_MinDate', 'c_MaxDate', 'c_LastMonthStart', 'c_ActiveFilters', 'c_TrendEnd', 'c_TopReason',
            'c_TopRefusalReason', 'c_TopHFReason', 'c_TopStaff', 'c_TopFacility', 'c_TopFacilityCount', 'c_TopSite']
    missing = [x for x in need if x not in names]
    used = set()
    for nm in z.namelist():
        if nm.startswith('xl/worksheets/sheet') or nm == 'xl/workbook.xml':
            used |= set(re.findall(r'\b((?:lst|flt|f|c)_[A-Za-z]+)\b', z.read(nm).decode('utf-8')))
    undefined = sorted(u for u in used if u not in names)
    print(f'STRUCT defined names: {len(names)} defined, missing={missing}, used-but-undefined={undefined}')
    ok &= not missing and not undefined
    dv = {s: len(wb[s].data_validations.dataValidation) for s in ('Dashboard', 'Raw Data')}
    charts = len([nm for nm in z.namelist() if re.fullmatch(r'xl/charts/chart\d+\.xml', nm)])
    print(f'STRUCT data validations: {dv}   charts in the package: {charts}')
    ok &= dv == {'Dashboard': 16, 'Raw Data': 19} and charts == 14
    # the workbook no longer has the KPI / code sheets: nothing may still point at them
    gone = ('KPIs', 'Power Query M', 'DAX Measures')
    pattern = re.compile(r"""\bKPIs!|'KPIs'|"KPIs"|KPIs sheet|Power Query M\b|DAX Measures|column [GH] of""")
    leftovers = []
    for nm in z.namelist():
        if nm.endswith(('.xml', '.rels', '.vml')):
            txt = html.unescape(z.read(nm).decode('utf-8'))
            leftovers += [(nm, m.group(0)) for m in pattern.finditer(txt)]
    print(f'STRUCT removed sheets present: {[g for g in gone if g in order]}   references to them left in the package: {leftovers[:6] or "none"}')
    ok &= not any(g in order for g in gone) and not leftovers
    # data rows respect the dropdown lists
    lists = {col: set(vals) for _, col, vals in B.LISTS}
    col_idx = {h: i for i, h in enumerate(headers)}
    viol = 0
    for row in ws.iter_rows(min_row=2, values_only=True):
        for col, allowed in lists.items():
            v = row[col_idx[col]]
            if v is not None and v not in allowed:
                viol += 1
    print(f'STRUCT values outside the dropdown lists: {viol}')
    ok &= viol == 0
    return ok


def refresh_m_cache():
    """Pretty-print every single-KPI query with Microsoft's formatter and store the result for the text file."""
    ensure_pq_parser()
    K = B.KP.build_kpis(L)
    os.makedirs(SCRATCH, exist_ok=True)
    src, out = f'{SCRATCH}/m_format_in.json', f'{SCRATCH}/m_format_out.json'
    json.dump([{'name': k.key, 'code': k.m} for k in K], open(src, 'w'))
    res = subprocess.run(['node', 'pqformat.js', src, out], capture_output=True, text=True, cwd=PQ_DIR)
    items = json.load(open(out)) if os.path.exists(out) else []
    cache, failed = {}, []
    for k, it in zip(K, items):
        if it.get('ok') and it.get('text', '').strip():
            cache[k.key] = {'src': k.m, 'formatted': it['text'].replace('\r\n', '\n').rstrip() + '\n'}
        else:
            failed.append((k.name, it.get('text')))
    json.dump(cache, open(B.M_CACHE, 'w'), indent=1)
    for name, err in failed:
        print('M FORMAT FAIL:', name, '=>', err)
    print(f'M      formatter: queries formatted={len(cache)} failed={len(failed) + (len(K) - len(items))}   {res.stderr.strip()[:200]}')
    return len(cache) == len(K)


def split_single_kpi_file(text):
    """3_KPIs_one_by_one.txt -> {kpi number: M code of that block}."""
    marks = [(m.start(), int(m.group(1))) for m in re.finditer(r'^// KPI (\d+)  \|', text, re.M)]
    return {no: text[pos:(marks[i + 1][0] if i + 1 < len(marks) else len(text))] for i, (pos, no) in enumerate(marks)}


def run_m(K, texts):
    """Syntax (Microsoft parser) + library names (Microsoft library definition) for all M text that is delivered."""
    sys.path.insert(0, os.path.join(HERE, 'tools'))
    import mini_m as MM
    items = [{'name': f'file {B.CODE_FILES[key]}', 'code': texts[B.CODE_FILES[key]]} for key in ('referrals', 'summary', 'calendar')]
    blocks = split_single_kpi_file(texts[B.CODE_FILES['single']])
    items += [{'name': f'file {B.CODE_FILES["single"]}, KPI {no}', 'code': code} for no, code in sorted(blocks.items())]
    items += [{'name': f'unformatted source of KPI {k.no} {k.name}', 'code': k.m} for k in K]
    ensure_pq_parser()
    p = f'{SCRATCH}/m_items.json'
    os.makedirs(SCRATCH, exist_ok=True)
    json.dump(items, open(p, 'w'))
    res = subprocess.run(['node', 'pqcheck.js', p], capture_output=True, text=True, cwd=PQ_DIR)
    out = res.stdout.strip()
    print('M      parser:', out.replace('\n', '\n       '))
    ok = 'failed=0' in out and f'checked={len(items)}' in out and len(blocks) == len(K)
    # library names
    sig = json.load(open(os.path.join(HERE, 'tools', 'm_library.json')))
    used, unknown = set(), {}
    for it in items:
        ids = MM.library_identifiers(it['code'])
        used |= ids
        for n in ids:
            if n not in sig and n != 'Excel.CurrentWorkbook':
                unknown.setdefault(n, it['name'])
    print(f'M      library: {len(used)} different library functions / constants used, not in Microsoft\'s library definition: {unknown or "none"}')
    return ok and not unknown


def run_m_engine_check():
    """Is the mini interpreter itself trustworthy?  Unit tests + Microsoft's documented examples."""
    sys.path.insert(0, os.path.join(HERE, 'tools'))
    import m_conformance
    import test_mini_m
    unit = test_mini_m.run_tests()
    print(f'MENGINE unit tests of the interpreter: {unit["passed"]} passed, {unit["failed"]} failed')
    import contextlib
    import io
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        stats, rows = m_conformance.main(verbose=True)
    for line in buf.getvalue().splitlines():
        if 'FAIL' in line:
            print('MENGINE', line.strip())
    print(f'MENGINE Microsoft documentation examples: reproduced={stats["pass"]} contradicted={stats["fail"]} not runnable here={stats["skip"]} '
          f'(functions implemented={stats["functions"]}, with at least one reproduced example={stats["functions_confirmed"]}, '
          f'pages not downloaded={stats["pages_missing"]})')
    return unit['failed'] == 0 and stats['fail'] == 0 and stats['pages_missing'] == 0 and stats['pass'] >= 80


# ---------------------------------------------------------------------------------------------------------------------
# MEXEC: run the delivered M text
# ---------------------------------------------------------------------------------------------------------------------
M_PATH = B.M_FILE_PATH                                            # the path written in the Referrals query
TEMPLATE_HEADERS = {'Referral Priority': 'Referral Prioroty', 'Previous history': 'Previous hsitory', 'Referral Shift': 'Refferal Shif',
                    'Referral Status': 'Referal Status'}
TEMPLATE_VALUES = {'PPH-Post Partum Hemorrhage': 'PPH-Post Partum Hamerage', 'Preeclampsia': 'Preeclampcia', 'Eclampsia': 'Eclampcia',
                   'Financial Constraint': 'Financial Constrain'}


def excel_cells(df):
    """Rows of the register as Excel.Workbook() hands them to Power Query: text, doubles, datetimes, nulls + helper column."""
    import pandas as pd
    rows = []
    for rec in df[L.COLUMNS].itertuples(index=False, name=None):
        row = []
        for v in rec:
            if v is None or (not isinstance(v, str) and pd.isna(v)):
                row.append(None)
            elif isinstance(v, dt.datetime):
                row.append(v)
            elif isinstance(v, dt.date):
                row.append(dt.datetime(v.year, v.month, v.day))
            elif isinstance(v, str):
                row.append(v)
            else:
                row.append(float(v))
        row.append(1.0 if row[0] is not None else 0.0)             # cached result of the "In Filter" formula
        rows.append(row)
    return rows


def workbook_mock(MM, columns, rows):
    table = MM.MTable(columns, rows)
    sheet = MM.MTable([f'Column{i + 1}' for i in range(len(columns))], [list(columns)] + rows)
    return MM.MTable(['Name', 'Data', 'Item', 'Kind', 'Hidden'],
                     [['Raw Data', sheet, 'Raw Data', 'Sheet', False], ['tblReferrals', table, 'tblReferrals', 'Table', False]])


def ui_import_query(date_type):
    """The query Power BI writes by itself for  Get data > Excel workbook > tblReferrals  (source, navigation, changed type)."""
    from kpis import AGE, GA, NVIS, ENR, VIS, FLAG
    types = {AGE: 'Int64.Type', GA: 'Int64.Type', NVIS: 'Int64.Type', ENR: date_type, VIS: date_type, FLAG: 'Int64.Type'}
    pairs = ', '.join('{"%s", %s}' % (c, types.get(c, 'type text')) for c in list(L.COLUMNS) + [FLAG])
    return ('let\n    Source = Excel.Workbook(File.Contents("%s"), null, true),\n'
            '    tblReferrals_Table = Source{[Item="tblReferrals",Kind="Table"]}[Data],\n'
            '    #"Changed Type" = Table.TransformColumnTypes(tblReferrals_Table,{%s})\nin\n    #"Changed Type"' % (M_PATH, pairs))


def expected_m_values(df, kvals, K):
    """Expected KPI values for the M code. Same as the workbook values, except where the M / DAX definition looks at every
    value in the data and the Excel sheet only at the values of the dropdown lists (identical on clean data)."""
    from kpis import PID, SITE, STAFF, FAC, REAS, RREF, HFREAS, UND
    d = df[df[PID].notna()]
    n = len(d)
    exp = {k.key: (None if isinstance(kvals[k.key], str) and kvals[k.key] == UND else kvals[k.key]) for k in K}

    def top(col):
        vc = d[col].dropna().value_counts()
        return None if vc.empty else sorted(v for v, c in vc.items() if c == vc.max())[0]
    exp['sites'], exp['staff'], exp['facilities'] = int(d[SITE].nunique()), int(d[STAFF].nunique()), int(d[FAC].nunique())
    exp['per_staff'] = n / exp['staff'] if exp['staff'] else None
    for key, col in (('top_reason', REAS), ('top_refusal', RREF), ('top_hf_reason', HFREAS), ('top_staff', STAFF), ('top_facility', FAC), ('top_site', SITE)):
        exp[key] = top(col)
    exp['top_fac_share'] = (int(d[FAC].value_counts().max()) / n) if (n and d[FAC].notna().any()) else None
    return exp


def same_value(got, exp):
    if exp is None or got is None:
        return got is None and exp is None
    if isinstance(exp, str) or isinstance(got, str):
        return got == exp
    return abs(float(got) - float(exp)) <= 1e-9 * max(1.0, abs(float(exp)))


def display_text(v, fmt):
    if v is None:
        return 'n/a'
    return {'int': B.t_int, 'pct': lambda x: B.t_pct(x, 1).replace(',', ''), 'dec1': lambda x: B.t_dec(x, 1), 'dec2': lambda x: B.t_dec(x, 2),
            'text': lambda x: x}[fmt](v)


def run_m_exec(texts):
    sys.path.insert(0, os.path.join(HERE, 'tools'))
    import mini_m as MM
    import pandas as pd
    from kpis import FLAG, FMT_LABEL
    K = B.KP.build_kpis(L)
    q_ref, q_sum = texts[B.CODE_FILES['referrals']], texts[B.CODE_FILES['summary']]
    blocks = split_single_kpi_file(texts[B.CODE_FILES['single']])
    calendar = texts[B.CODE_FILES['calendar']]
    assert f'FilePath = "{M_PATH}"' in q_ref, 'the Referrals query does not point at the workbook file name'
    columns = list(L.COLUMNS) + [FLAG]
    all_ok, used = True, {}

    def run_query(I, code, extra=None):
        try:
            return I.run(code, extra), None
        except (MM.MRuntimeError, MM.MUnsupported, SyntaxError) as e:
            return None, f'{type(e).__name__}: {e}'

    def check_summary(I, exp, label):
        t, err = run_query(I, q_sum)
        problems = []
        if err:
            problems = [err] * (len(K) + 1)
        elif t.columns != ['No', 'Category', 'KPI', 'Value', 'Display', 'Format'] or len(t.rows) != len(K):
            problems = [f'shape {t.columns} x {len(t.rows)}'] * (len(K) + 1)
        else:
            for k, (no, cat, name, value, display, fmt) in zip(K, t.rows):
                e = exp[k.key]
                e_val = None if k.is_text else e
                if (no, cat, name, fmt) != (k.no, k.cat, k.name, FMT_LABEL[k.fmt]) or not same_value(value, e_val) or display != display_text(e, k.fmt):
                    problems.append(f'KPI {k.no} {k.name}: got ({value!r}, {display!r}) expected ({e_val!r}, {display_text(e, k.fmt)!r})')
        print(f'MEXEC  {"OK  " if not problems else "FAIL"} {label:44s} KPI_Summary: {max(0, len(K) - len(problems))}/{len(K)} KPIs match')
        for p_ in problems[:4]:
            print('         ', p_)
        return not problems

    def check_blocks(I, exp, label):
        problems = []
        for k in K:
            got, err = run_query(I, blocks.get(k.no, 'missing block'))
            if err or not same_value(got, exp[k.key]):
                problems.append(f'KPI {k.no} {k.name}: got {err or repr(got)} expected {exp[k.key]!r}')
        print(f'MEXEC  {"OK  " if not problems else "FAIL"} {label:44s} single queries: {len(K) - len(problems)}/{len(K)} KPIs match')
        for p_ in problems[:4]:
            print('         ', p_)
        return not problems

    def check_calendar(I, label):
        cal, err = run_query(I, calendar)
        ok = (not err and len(cal.rows) == 730 and cal.rows[-1][0] == dt.date(2026, 10, 31)
              and dict(zip(cal.columns, cal.rows[0])) == {'Date': dt.date(2024, 11, 1), 'Year': 2024, 'Quarter': 'Q4', 'Month No': 11, 'Month': 'Nov',
                                                           'Year-Month': '2024-11', 'Month Start': dt.date(2024, 11, 1), 'Day Name': 'Fri', 'Day No': 5})
        print(f'MEXEC  {"OK  " if ok else "FAIL"} {label:44s} Calendar: ' + (err or f'rows={len(cal.rows)} first={cal.rows[0][0]} last={cal.rows[-1][0]}'))
        return ok

    def load_register(I, label, n_exp):
        loaded, err = run_query(I, q_ref)
        ok = (not err and len(loaded.rows) == n_exp
              and loaded.columns == list(L.COLUMNS) + ['Visit Month', 'Age Group', 'Trimester', 'Days Enrollment to Visit'])
        print(f'MEXEC  {"OK  " if ok else "FAIL"} {label:44s} ' + (err or f'rows loaded={len(loaded.rows)} (expected {n_exp}), columns={len(loaded.columns)}'))
        return loaded if ok else None

    def garbage(df):
        """Text typed into number and date cells (shows up as cell errors once Power Query sets the column types)."""
        return dirty(df)

    GARBAGE = {(3, B.AGE): 'abc', (4, B.AGE): 'not known', (5, B.GA): 'x', (6, B.VIS): 'n/a', (7, B.ENR): 'pending', (8, B.NVIS): '?'}

    for scen, mutate in (('clean register', None), ('messy register', dirty), ('text in number/date cells', garbage)):
        df = pd.read_pickle(os.path.join(HERE, 'referrals.pkl'))
        if mutate is not None:
            df = mutate(df.copy())
        bad_cells = {}
        if mutate is garbage:                                           # the bad cells count as blank everywhere
            for (r, c), txt in GARBAGE.items():
                bad_cells[(r, L.COLUMNS.index(c))] = txt
                df.at[df.index[r], c] = float('nan') if c in (B.AGE, B.GA, B.NVIS) else None
        tmp = f'{SCRATCH}/mexec.xlsx'
        os.makedirs(SCRATCH, exist_ok=True)
        _, info = B.build(tmp, quiet=True, mutate=(lambda _df, df=df: df))
        exp = expected_m_values(df, info['kvals'], K)
        if mutate is None:                                              # on clean data both definitions must agree
            diff = [k.key for k in K if not same_value(exp[k.key], None if info['kvals'][k.key] == B.UND else info['kvals'][k.key])]
            if diff:
                all_ok = False
                print('MEXEC  FAIL expected values: M definition and workbook definition differ on clean data for', diff)
        rows = excel_cells(df)
        for (r, j), txt in bad_cells.items():
            rows[r][j] = txt
        n_exp = int(df[B.PID].notna().sum())

        # (a) data loaded with the delivered "Referrals" query
        I = MM.Interp(files={M_PATH: workbook_mock(MM, columns, rows)})
        loaded = load_register(I, f'{scen}, Referrals query', n_exp)
        if loaded is None:
            all_ok = False
        else:
            I.define('Referrals', loaded)
            all_ok &= check_summary(I, exp, f'{scen}, loaded by Referrals query')
            all_ok &= check_blocks(I, exp, f'{scen}, loaded by Referrals query')
        if loaded is not None:
            all_ok &= check_calendar(I, f'{scen}, loaded by Referrals query')
        if mutate is None and loaded is not None:
            # the original template spellings + padded / empty text must load to exactly the same table
            hdr = [TEMPLATE_HEADERS.get(c, c) for c in columns]
            rows2 = [[(' ' + TEMPLATE_VALUES.get(v, v) + '  ') if isinstance(v, str) else ('' if (v is None and j > 10) else v)
                      for j, v in enumerate(r)] for r in rows]
            I2 = MM.Interp(files={M_PATH: workbook_mock(MM, hdr, rows2)})
            loaded2, err = run_query(I2, q_ref)
            ok = not err and loaded2.columns == loaded.columns and loaded2.rows == loaded.rows
            print(f'MEXEC  {"OK  " if ok else "FAIL"} {"template spellings, padded and empty text":44s} ' + (err or f'Referrals query returns the same table: {ok}'))
            all_ok &= ok
            for name, cnt in I2.used.items():
                used[name] = used.get(name, 0) + cnt
        for name, cnt in I.used.items():
            used[name] = used.get(name, 0) + cnt

        # (b) data loaded the standard way (Get data > Excel workbook): Power BI's own query, dates typed date or datetime
        for date_type in ('type date', 'type datetime'):
            I = MM.Interp(files={M_PATH: workbook_mock(MM, columns, rows)})
            ui, err = run_query(I, ui_import_query(date_type))
            label = f'{scen}, Get data import ({date_type[5:]})'
            if err:
                print(f'MEXEC  FAIL {label:44s} {err}')
                all_ok = False
                continue
            I.define('Referrals', ui)
            all_ok &= check_summary(I, exp, label)
            all_ok &= check_calendar(I, label)
            if mutate is None:                                          # the single queries read Referrals exactly as it is
                all_ok &= check_blocks(I, exp, label)
            for name, cnt in I.used.items():
                used[name] = used.get(name, 0) + cnt
    print(f'MEXEC  library functions executed: {len(used)}  ->  {", ".join(sorted(used))}')
    return bool(all_ok)


def run_dax_measures():
    """Parse every measure with the DAX Formatter and refresh the formatted-text cache used by the DAX text file."""
    K = B.KP.build_kpis(L)
    errors = B.refresh_dax_cache(K)
    for name, err in errors:
        print('DAX FAIL:', name, '=>', err[0] if err else 'empty')
    print(f'DAX    measures checked={len(K)} failed={len(errors)}')
    return not errors


def run_dax_script(K, texts, notes):
    """The delivered DAX text file as a whole (comment header + DEFINE MEASURE ... EVALUATE)."""
    text = texts[B.CODE_FILES['dax']].replace('\r\n', '\n')
    res = B.dax_format_request([text])[0]
    bad = bool(res.get('errors')) or not res.get('formatted')
    lines = [ln.strip() for ln in text.split('\n')]
    at = [i for i, ln in enumerate(lines) if ln.startswith('MEASURE ')]
    names_ok = [lines[i] for i in at] == [f'MEASURE Referrals[{k.name}] =' for k in K]
    # above every measure: "// <no> | <category> | format: <format>" and "/// <definition>"
    commented = sum(1 for j, i in enumerate(at) if lines[i - 1].startswith('/// ') and lines[i - 2].startswith(f'// {j + 1} | ')
                    and lines[i - 2].endswith('format: ' + B.KP.FMT_LABEL[K[j].fmt])) if names_ok else 0
    print(f'DAX    text file: lines={len(lines) - 1} measures={len(at)} names and order as in the KPI list={names_ok} '
          f'format + definition comments={commented} parse_errors={res.get("errors") or 0} unformatted_measures={len(notes["dax_unformatted"])}')
    return (not bad) and names_ok and commented == len(K) and not notes['dax_unformatted'] and lines[-2] == ')'


if __name__ == '__main__':
    what = sys.argv[1:] or ['recalc', 'dax', 'struct', 'm', 'mexec']
    results = {}
    if 'recalc' in what:
        results['recalc'] = run_recalc()
    if 'dax' in what:
        results['dax_measures'] = run_dax_measures()          # also refreshes the cache used by the final build
    if 'm' in what:
        results['m_format'] = refresh_m_cache()               # also refreshes the cache used by the text files
    exp, info = B.build(B.OUT_DEFAULT, quiet=True)            # the delivered workbook
    K = info['kpis']
    written, notes = B.export_code_files(K)                   # the delivered Power BI code files ...
    texts = B.read_code_files()                               # ... checked exactly as they are on disk
    assert texts == written
    if 'dax' in what:
        results['dax_script'] = run_dax_script(K, texts, notes)
    if 'struct' in what:
        results['struct'] = run_struct(B.OUT_DEFAULT)
    if 'm' in what:
        results['m'] = run_m(K, texts) and not notes['m_unformatted']
    if 'mexec' in what:
        results['m_engine_check'] = run_m_engine_check()
        results['m_exec'] = run_m_exec(texts)
    print('SUMMARY', results)
    sys.exit(0 if all(results.values()) else 1)
