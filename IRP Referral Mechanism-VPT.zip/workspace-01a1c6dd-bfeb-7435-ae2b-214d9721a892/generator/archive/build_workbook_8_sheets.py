# ARCHIVED REFERENCE - NOT USED BY ANYTHING.
# This is the builder as it was on 10 Nov 2026 before the sheets "KPIs", "Power Query M" and "DAX Measures" were removed
# from the workbook and the file was renamed to "IRP Referral Mechanism-VPT.xlsx". Kept only so that those three sheets
# can be restored quickly if they are wanted again. The current builder is ../build_workbook.py.

#!/usr/bin/env python3
"""
Builds Maternal_Referral_Dashboard.xlsx

Sheets: Dashboard | Raw Data | Filter Data | KPIs | Power Query M | DAX Measures | Calc | Read Me

Every formula cell is written together with its Python-computed result (cached value), so the workbook shows
correct numbers even in viewers that do not recalculate. build() returns the dict of expected values so that
verify.py can compare them with an independent recalculation.
"""
import datetime as dt
import json
import math
import os
import re
import sys
from decimal import Decimal, ROUND_HALF_UP

import pandas as pd
import xlsxwriter
from xlsxwriter.utility import xl_rowcol_to_cell, xl_col_to_name

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import gen_data as L                                    # noqa: E402
import kpis as KP                                       # noqa: E402
from kpis import (TBL, FLAG, UND, PID, AGE, SITE, ENR, GA, ANOM, VIS, NVIS, PRI, HIST, COND, REAS, SHIFT, STAFF,  # noqa: E402
                  FAC, ACC, RREF, HFR, HFREAS, STAT, xcol, xrow, XFLAG)

OUT_DEFAULT = os.path.join(os.path.dirname(HERE), 'Maternal_Referral_Dashboard.xlsx')
POISON = -999

# ---------------------------------------------------------------------------------------------------------------
# palette
# ---------------------------------------------------------------------------------------------------------------
NAVY, NAVY_D = '#17324D', '#102538'
TEAL, TEAL_L = '#1A9A8A', '#D7F0EC'
CORAL, CORAL_L = '#E4572E', '#FBE3DC'
AMBER, AMBER_L = '#F0A33A', '#FDF0D9'
GREEN = '#2E9E6B'
PURPLE = '#6C5B9E'
BLUE = '#3B7DD8'
SLATE = '#7C8DA0'
TXT, GREY_T, GREY_L, GREY_LL = '#22313F', '#5F6B7A', '#D9DEE4', '#EEF1F5'
BG, WHITE = '#F3F5F8', '#FFFFFF'
STATUS_COL = {'Completed': GREEN, 'Partial Complete': AMBER, 'Incomplete': CORAL}

N_SLOTS = 30                       # slots per dropdown list on the Filter Data sheet
FD_FIRST = 4                       # first list row on Filter Data (0-indexed) -> Excel row 5
EXCEL_EPOCH = dt.date(1899, 12, 30)
DATE_MAX_SERIAL = 2958465          # 31-Dec-9999

# dropdown lists (order = column order of the template); key is used in defined names lst_<key> / flt_<key>
LISTS = [('Site', SITE, L.SITES), ('Anomaly', ANOM, L.YESNO), ('Priority', PRI, L.PRIORITY), ('History', HIST, L.HISTORY),
         ('Condition', COND, L.CONDITION), ('Reason', REAS, L.REASONS), ('Shift', SHIFT, L.SHIFTS), ('Staff', STAFF, L.STAFF),
         ('Facility', FAC, L.FACILITIES), ('Accepted', ACC, L.YESNO), ('RefusalReason', RREF, L.REFUSAL_REASONS),
         ('HFRefusal', HFR, L.YESNO), ('HFReason', HFREAS, L.HF_REASONS), ('Status', STAT, L.STATUS)]
LIST_IDX = {k: i for i, (k, _, _) in enumerate(LISTS)}
LIST_COL = {k: c for k, c, _ in LISTS}
LIST_VALUES = {k: v for k, _, v in LISTS}

# dashboard filters: (key, label on dashboard)
FILTERS = [('Site', 'Site'), ('Priority', 'Referral Priority'), ('Condition', 'Condition on Arrival'),
           ('Reason', 'Reason of Referral'), ('Shift', 'Referral Shift'), ('Staff', 'Referred by Staff'),
           ('Facility', 'Referred Facility'), ('Status', 'Referral Status'),
           ('Accepted', 'Referral Accepted'), ('RefusalReason', 'Reason for Refusal'), ('HFRefusal', 'Refusal from HF'),
           ('HFReason', 'Reason of Facility Refusal'), ('History', 'Previous History'), ('Anomaly', 'Anomaly in Scan'),
           ('DateFrom', 'Visit Date From'), ('DateTo', 'Visit Date To')]

SHEETS = ['Dashboard', 'Raw Data', 'Filter Data', 'KPIs', 'Power Query M', 'DAX Measures', 'Calc', 'Read Me']
KPI_FIRST_ROW = 5                  # first KPI row on the KPIs sheet (0-indexed)
KPI_VALUE_COL = 4                  # column E


# ---------------------------------------------------------------------------------------------------------------
# small helpers
# ---------------------------------------------------------------------------------------------------------------
def serial(d):
    return (d - EXCEL_EPOCH).days


def a1(r, c):
    return xl_rowcol_to_cell(r, c, row_abs=True, col_abs=True)


def qs(sheet):
    return f"'{sheet}'" if re.search(r'[^A-Za-z0-9_]', sheet) else sheet


def ref(sheet, r, c):
    return f'{qs(sheet)}!{a1(r, c)}'


def rng(sheet, r1, c1, r2, c2):
    return f'{qs(sheet)}!{a1(r1, c1)}:{a1(r2, c2)}'


def xl_round(x, nd=0):
    """Round like Excel (half away from zero on the 15-significant-digit value)."""
    return Decimal(f'{x:.15g}').quantize(Decimal(1).scaleb(-nd), rounding=ROUND_HALF_UP)


def t_int(v):
    return v if isinstance(v, str) else f'{int(xl_round(v, 0)):,}'


def t_pct(v, nd=1):
    if isinstance(v, str):
        return v
    d = (Decimal(f'{v:.15g}') * 100).quantize(Decimal(1).scaleb(-nd), rounding=ROUND_HALF_UP)
    return f'{d:,.{nd}f}%'


def t_dec(v, nd):
    return v if isinstance(v, str) else f'{xl_round(v, nd):.{nd}f}'


def py(v):
    """numpy scalar -> plain python."""
    if hasattr(v, 'item'):
        return v.item()
    return v


class Ctx:
    """Rows in view (= rows that pass the dashboard filters) plus NaN-safe date serials."""
    def __init__(self, df, mask):
        self.df, self.mask = df, mask
        self.d = df[mask]
        self.n = int(mask.sum())
        self.vis = self.d[VIS].map(KP.to_serial).astype(float)
        self.enr = self.d[ENR].map(KP.to_serial).astype(float)


def make_mask(df, filters):
    """Same rule as the 'In Filter' column: a record needs a Patient ID, must match every list filter and - when a
    date filter is set - must have a visit date inside the range."""
    mask = df[PID].notna()
    for key, _ in FILTERS[:14]:
        v = filters.get(key, 'All')
        if v not in ('All', '', None):
            mask &= (df[LIST_COL[key]] == v)
    lo, hi = filters.get('DateFrom'), filters.get('DateTo')
    if lo or hi:
        s_ = df[VIS].map(KP.to_serial).astype(float)
        mask &= s_.notna() & (s_ >= (serial(lo) if lo else 0)) & (s_ <= (serial(hi) if hi else DATE_MAX_SERIAL))
    return mask


# ---------------------------------------------------------------------------------------------------------------
# text content: Power Query / DAX scripts
# ---------------------------------------------------------------------------------------------------------------
def m_referrals_query():
    cols = L.COLUMNS
    types = {AGE: 'Int64.Type', GA: 'Int64.Type', NVIS: 'Int64.Type', ENR: 'type date', VIS: 'type date'}
    text_cols = [c for c in cols if c not in types]

    def chunk(items, n):
        return [items[i:i + n] for i in range(0, len(items), n)]

    lines = [
        'let',
        '    // 1. SOURCE - put the full path of the workbook between the quotes',
        '    //    (File Explorer: right-click the file > Copy as path, then paste it over the path below - keep one pair of quotes)',
        '    FilePath = "C:\\Data\\Maternal_Referral_Dashboard.xlsx",',
        '    Source = Excel.Workbook(File.Contents(FilePath), null, true),',
        '    RawTable = Source{[Item = "tblReferrals", Kind = "Table"]}[Data],',
        '    //    Only when the query is created inside this Excel workbook itself (Excel > Data > Get Data), use this line',
        '    //    instead of the 3 lines above:   RawTable = Excel.CurrentWorkbook(){[Name = "tblReferrals"]}[Content],',
        '',
        '    // 2. HEADERS - the original template spellings are accepted as well',
        '    Renamed = Table.RenameColumns(RawTable, {',
        '        {"Referral Prioroty", "Referral Priority"},',
        '        {"Previous hsitory", "Previous history"},',
        '        {"Refferal Shif", "Referral Shift"},',
        '        {"Referal Status", "Referral Status"}',
        '    }, MissingField.Ignore),',
        '',
        '    // 3. KEEP THE 22 REGISTER COLUMNS (drops the Excel helper column "In Filter")',
        '    RegisterColumns = {',
    ]
    ch = chunk([f'"{c}"' for c in cols], 4)
    for i, grp in enumerate(ch):
        lines.append('        ' + ', '.join(grp) + (',' if i < len(ch) - 1 else ''))
    lines += [
        '    },',
        '    Selected = Table.SelectColumns(Renamed, RegisterColumns, MissingField.UseNull),',
        '',
        '    // 4. DATA TYPES',
        '    Typed = Table.TransformColumnTypes(Selected, {',
    ]
    ch = chunk(['{"%s", %s}' % (c, types.get(c, 'type text')) for c in cols], 3)
    for i, grp in enumerate(ch):
        lines.append('        ' + ', '.join(grp) + (',' if i < len(ch) - 1 else ''))
    lines += [
        '    }),',
        '    //    cells that cannot be converted (e.g. text typed into a date or number column) become null instead of errors',
        '    NoErrors = Table.ReplaceErrorValues(Typed, List.Transform(RegisterColumns, each {_, null})),',
        '',
        '    // 5. CLEAN TEXT - trim spaces, turn empty strings into null, drop rows without a Patient ID',
        '    TextColumns = {',
    ]
    ch = chunk([f'"{c}"' for c in text_cols], 4)
    for i, grp in enumerate(ch):
        lines.append('        ' + ', '.join(grp) + (',' if i < len(ch) - 1 else ''))
    lines += [
        '    },',
        '    Cleaned = Table.TransformColumns(NoErrors, List.Transform(TextColumns,',
        '        (c) => {c, each if _ = null or Text.Trim(_) = "" then null else Text.Trim(_), type text})),',
        '    NonEmpty = Table.SelectRows(Cleaned, each [Patient ID] <> null),',
        '',
        '    // 6. VALUE SPELLINGS - original template spellings are mapped to the corrected ones',
        '    Fixes = [',
        '        #"PPH-Post Partum Hamerage" = "PPH-Post Partum Hemorrhage",',
        '        Preeclampcia = "Preeclampsia",',
        '        Eclampcia = "Eclampsia",',
        '        #"Financial Constrain" = "Financial Constraint"',
        '    ],',
        '    FixValue = (v) => if v = null then null else Record.FieldOrDefault(Fixes, v, v),',
        '    Fixed = Table.TransformColumns(NonEmpty, {',
        '        {"Reason of Referral", FixValue, type text},',
        '        {"Reason for refusal", FixValue, type text}',
        '    }),',
        '',
        '    // 7. DERIVED COLUMNS - handy for slicers and charts',
        '    AddMonth = Table.AddColumn(Fixed, "Visit Month", each Date.StartOfMonth([Date of visit]), type date),',
        '    AddAgeGroup = Table.AddColumn(AddMonth, "Age Group", each',
        '        if [Age] = null then null else if [Age] < 20 then "<20" else if [Age] < 25 then "20-24"',
        '        else if [Age] < 30 then "25-29" else if [Age] < 35 then "30-34"',
        '        else if [Age] < 40 then "35-39" else "40+", type text),',
        '    AddTrimester = Table.AddColumn(AddAgeGroup, "Trimester", each',
        '        if [#"Gestational Age (wks)"] = null then null',
        '        else if [#"Gestational Age (wks)"] <= 13 then "1st trimester"',
        '        else if [#"Gestational Age (wks)"] <= 27 then "2nd trimester" else "3rd trimester", type text),',
        '    AddDays = Table.AddColumn(AddTrimester, "Days Enrollment to Visit",',
        '        each Duration.Days([Date of visit] - [Date of Enrollment]), Int64.Type)',
        'in',
        '    AddDays',
    ]
    return lines


def m_calendar_query():
    return [
        'let',
        '    Source = Referrals,',
        '    VisitDates = List.RemoveNulls(Source[Date of visit]),',
        '    FirstDate = Date.StartOfMonth(List.Min(VisitDates)),',
        '    LastDate = Date.EndOfMonth(List.Max(VisitDates)),',
        '    DayCount = Duration.Days(LastDate - FirstDate) + 1,',
        '    Dates = List.Dates(FirstDate, DayCount, #duration(1, 0, 0, 0)),',
        '    AsTable = Table.FromList(Dates, Splitter.SplitByNothing(), {"Date"}),',
        '    Typed = Table.TransformColumnTypes(AsTable, {{"Date", type date}}),',
        '    AddYear = Table.AddColumn(Typed, "Year", each Date.Year([Date]), Int64.Type),',
        '    AddQuarter = Table.AddColumn(AddYear, "Quarter", each "Q" & Text.From(Date.QuarterOfYear([Date])), type text),',
        '    AddMonthNo = Table.AddColumn(AddQuarter, "Month No", each Date.Month([Date]), Int64.Type),',
        '    AddMonth = Table.AddColumn(AddMonthNo, "Month", each Date.ToText([Date], "MMM", "en-US"), type text),',
        '    AddYearMonth = Table.AddColumn(AddMonth, "Year-Month", each Date.ToText([Date], "yyyy-MM", "en-US"), type text),',
        '    AddMonthStart = Table.AddColumn(AddYearMonth, "Month Start", each Date.StartOfMonth([Date]), type date),',
        '    AddDayName = Table.AddColumn(AddMonthStart, "Day Name", each Date.ToText([Date], "ddd", "en-US"), type text),',
        '    AddDayNo = Table.AddColumn(AddDayName, "Day No", each Date.DayOfWeek([Date], Day.Monday) + 1, Int64.Type)',
        'in',
        '    AddDayNo',
    ]


def m_kpi_summary_query(K):
    lines = [
        'let',
        '    // 1. INPUT - the query "Referrals" (table tblReferrals of the workbook). Number and date types are set again here,',
        '    //    so the KPIs work whichever way the table was loaded; cells with errors (values that cannot be converted) become null.',
        '    Typed = Table.TransformColumnTypes(Referrals, {',
        '        {"Age", type number}, {"Gestational Age (wks)", type number}, {"Number of visit", type number},',
        '        {"Date of Enrollment", type date}, {"Date of visit", type date}',
        '    }),',
        '    NoErrors = Table.ReplaceErrorValues(Typed, List.Transform(Table.ColumnNames(Typed), each {_, null})),',
        '    //    Rows without a Patient ID are not referral records. Table.Buffer keeps the rows in memory (the file is read once).',
        '    Source = Table.Buffer(Table.SelectRows(NoErrors, each [Patient ID] <> null and [Patient ID] <> "")),',
        '    Total = Table.RowCount(Source),',
        '',
        '    // 2. HELPER FUNCTIONS',
        '    //    CountIf(each ...)          number of records that meet a condition',
        '    CountIf = (condition as function) as number => Table.RowCount(Table.SelectRows(Source, condition)),',
        '    //    Ratio(a, b)                a / b, or null when it cannot be calculated',
        '    Ratio = (numerator as nullable number, denominator as nullable number) as nullable number =>',
        '        if numerator = null or denominator = null or denominator = 0 then null else numerator / denominator,',
        '    //    Values("column")           the filled-in values of a column (blank cells are left out)',
        '    Values = (columnName as text) as list =>',
        '        List.Select(Table.Column(Source, columnName), each _ <> null and _ <> ""),',
        '    //    DistinctCount("column")    how many different values a column holds',
        '    DistinctCount = (columnName as text) as number => List.Count(List.Distinct(Values(columnName))),',
        '    //    TopValue("column")         the most frequent value of a column (ties: first in alphabetical order)',
        '    TopValue = (columnName as text) as nullable text =>',
        '        let',
        '            Filled = Table.SelectRows(Source, each Record.Field(_, columnName) <> null and Record.Field(_, columnName) <> ""),',
        '            Grouped = Table.Group(Filled, {columnName}, {{"Referrals", each Table.RowCount(_), Int64.Type}}),',
        '            Sorted = Table.Sort(Grouped, {{"Referrals", Order.Descending}, {columnName, Order.Ascending}})',
        '        in',
        '            if Table.IsEmpty(Sorted) then null else Record.Field(Sorted{0}, columnName),',
        '    //    Show(value, format)        the value as display text, e.g. 0.406 -> "40.6%"',
        '    Show = (value as any, format as text) as text =>',
        '        if value = null then "n/a"',
        '        else if format = "Text" then value',
        '        else if format = "Percentage" then Number.ToText(value, "0.0%", "en-US")',
        '        else if format = "Whole number" then Number.ToText(value, "#,##0", "en-US")',
        '        else if format = "Decimal (2 dp)" then Number.ToText(value, "0.00", "en-US")',
        '        else Number.ToText(value, "0.0", "en-US"),',
        '',
        '    // 3. THE KPIs - one row each: {No, Category, KPI, Format, calculation}',
        '    Rows = {',
    ]
    for i, k in enumerate(K):
        expr = k.m_inline
        if expr.startswith('let '):
            expr = f'({expr})'
        comma = ',' if i < len(K) - 1 else ''
        lines.append(f'        {{{k.no}, "{k.cat}", "{k.name}", "{KP.FMT_LABEL[k.fmt]}", {expr}}}{comma}')
    lines += [
        '    },',
        '',
        '    // 4. RESULT TABLE:  No | Category | KPI | Value | Display | Format',
        '    AsTable = Table.FromRows(Rows, {"No", "Category", "KPI", "Format", "Result"}),',
        '    WithValue = Table.AddColumn(AsTable, "Value", each if [Format] = "Text" then null else [Result], type nullable number),',
        '    WithDisplay = Table.AddColumn(WithValue, "Display", each Show([Result], [Format]), type text),',
        '    Final = Table.TransformColumnTypes(',
        '        Table.SelectColumns(WithDisplay, {"No", "Category", "KPI", "Value", "Display", "Format"}),',
        '        {{"No", Int64.Type}, {"Category", type text}, {"KPI", type text}, {"Format", type text}})',
        'in',
        '    Final',
    ]
    return lines


# ---------------------------------------------------------------------------------------------------------------
# stand-alone text files with the M code (same text as on the workbook sheets) for pasting into Power BI
# ---------------------------------------------------------------------------------------------------------------
M_DIR_DEFAULT = '/home/user/Power_BI_M_code'
M_CACHE = os.path.join(HERE, 'm_formatted.json')
M_FILES = {'referrals': '1_Referrals.txt', 'summary': '2_KPI_Summary.txt', 'single': '3_KPIs_one_by_one.txt'}
RULE = '// ' + '=' * 108
THIN = '// ' + '-' * 108


def load_m_cache(K):
    """key -> multi-line M text produced by Microsoft's formatter, only while the single-line source is unchanged."""
    if not os.path.exists(M_CACHE):
        return {}
    cache = json.load(open(M_CACHE))
    return {k.key: cache[k.key]['formatted'] for k in K
            if isinstance(cache.get(k.key), dict) and cache[k.key].get('src') == k.m}


def m_file_texts(K):
    """Returns ({file name: text}, [KPI names that could not be shown in formatted form])."""
    n = len(K)
    formatted = load_m_cache(K)
    referrals = [
        RULE,
        '// QUERY "Referrals"  -  loads the referral register of Maternal_Referral_Dashboard.xlsx into Power BI',
        THIN,
        '// OPTIONAL. The quick way to load the data is  Home > Get data > Excel workbook  (then rename the table to Referrals).',
        '// Use this query instead when the data should also be cleaned while loading: text is trimmed, the original template',
        '// spellings are accepted, rows without a Patient ID are dropped, and four helper columns are added',
        '// (Visit Month, Age Group, Trimester, Days Enrollment to Visit).',
        '//',
        '// HOW TO USE',
        '//   1. Power BI Desktop > Home > Get data > Blank query',
        '//   2. Home > Advanced Editor > delete the text that is there > paste this whole file',
        '//   3. In the line  FilePath = "..."  put the place where your workbook is saved > Done',
        '//   4. Rename the query to  Referrals  (pane on the right: Query Settings > Name)',
        '//   5. Home > Close & Apply',
        '//',
        '// IF POWER BI SHOWS AN ERROR',
        '//   * "Could not find file ..."                      -> the path in the FilePath line is not where the workbook is saved',
        '//   * "The key didn\'t match any rows in the table"   -> the workbook has no Excel table named tblReferrals',
        RULE,
    ] + m_referrals_query()
    summary = [
        RULE,
        f'// QUERY "KPI_Summary"  -  all {n} KPIs of the maternal referral register, calculated in Power Query (M)',
        THIN,
        '// NEEDS    a query named  Referrals  (the table tblReferrals of Maternal_Referral_Dashboard.xlsx)',
        '// RETURNS  one row per KPI:  No | Category | KPI | Value | Display | Format',
        '//',
        '// HOW TO USE',
        '//   1. Power BI Desktop > Home > Transform data          (opens the Power Query Editor)',
        '//   2. Home > New Source > Blank Query',
        '//   3. Home > Advanced Editor > delete the text that is there > paste this whole file > Done',
        '//   4. Rename the query to  KPI_Summary  (pane on the right: Query Settings > Name)',
        '//   5. Home > Close & Apply',
        '//   6. Report view: add a Table visual and tick  No, KPI  and  Display  of KPI_Summary',
        '//',
        '// IF POWER BI SHOWS AN ERROR',
        '//   * "The name \'Referrals\' wasn\'t recognized"        -> the data query has another name: rename it to Referrals',
        '//   * "The column \'...\' of the table wasn\'t found"    -> a column heading of your Excel table differs from the workbook',
        '//',
        '// GOOD TO KNOW',
        '//   * M is calculated when the data is refreshed. The values cover the whole register and do not change with slicers.',
        '//     For cards that follow slicers use the DAX measures (sheet "DAX Measures" of the workbook).',
        '//   * Percentages are stored as fractions in Value (0.406) and as text in Display ("40.6%").',
        '//   * "n/a" / null = the KPI cannot be calculated (for example a division by zero).',
        RULE,
    ] + m_kpi_summary_query(K)
    single = [
        RULE,
        f'// THE {n} KPIs ONE BY ONE  -  every block below is a complete Power Query (M) query that returns one value',
        THIN,
        '// Each block reads the query named  Referrals  (load the data first - see 1_Referrals.txt or Get data > Excel workbook).',
        '// To use a block: Blank Query > Advanced Editor > paste the block > Done.',
        '// To get all KPIs at once as a table, use 2_KPI_Summary.txt instead.',
        '// null = the KPI cannot be calculated (for example a division by zero).',
        RULE,
    ]
    unformatted = []
    plain = str.maketrans({'\u00f7': '/', '\u2212': '-', '\u2013': '-', '\u2014': '-', '\u2264': '<=', '\u2265': '>=', '\u2019': "'"})
    for k in K:
        code = formatted.get(k.key)
        if code is None:
            unformatted.append(k.name)
            code = k.m
        single += ['', THIN, f'// KPI {k.no}  |  {k.cat}  |  {k.name}  |  format: {KP.FMT_LABEL[k.fmt]}', f'// {k.desc.translate(plain)}', THIN]
        single += code.rstrip('\n').split('\n')
    texts = {M_FILES['referrals']: referrals, M_FILES['summary']: summary, M_FILES['single']: single}
    out = {name: '\r\n'.join(lines) + '\r\n' for name, lines in texts.items()}
    for name, text in out.items():
        text.encode('ascii')                               # raises if a non-ASCII character slipped in
    return out, unformatted


def export_m_files(K, folder=M_DIR_DEFAULT):
    os.makedirs(folder, exist_ok=True)
    texts, unformatted = m_file_texts(K)
    for name, text in texts.items():
        with open(os.path.join(folder, name), 'w', encoding='ascii', newline='') as f:
            f.write(text)
    return texts, unformatted


def read_m_files(folder=M_DIR_DEFAULT):
    """The delivered text files exactly as they are on disk."""
    return {name: open(os.path.join(folder, name), encoding='ascii', newline='').read() for name in M_FILES.values()}


DAX_CACHE = os.path.join(HERE, 'dax_formatted.json')
DAX_API = 'https://api.daxformatter.com/api/DaxTextFormatMulti'


def dax_source(k):
    return f'{k.name} = {k.dax}'


def dax_format_request(texts):
    """SQLBI DAX Formatter: parses each text and returns {'formatted': ..., 'errors': [...]} per item."""
    import urllib.request
    req = urllib.request.Request(DAX_API, data=json.dumps({'Dax': texts, 'ListSeparator': ',', 'DecimalSeparator': '.',
                                                           'MaxLineLength': 110}).encode('utf-8'),
                                 headers={'Content-Type': 'application/json; charset=UTF-8', 'Accept': 'application/json',
                                          'User-Agent': 'Mozilla/5.0'})
    return json.loads(urllib.request.urlopen(req, timeout=180).read().decode('utf-8'))


def refresh_dax_cache(K):
    """Parse + format every measure; returns the list of (kpi name, error) and rewrites the cache file."""
    res = dax_format_request([dax_source(k) for k in K])
    errors, cache = [], {}
    for k, r in zip(K, res):
        if r.get('errors') or not r.get('formatted'):
            errors.append((k.name, r.get('errors')))
        else:
            cache[k.key] = {'src': dax_source(k), 'formatted': r['formatted']}
    json.dump(cache, open(DAX_CACHE, 'w'), indent=1)
    return errors


def load_dax_cache(K):
    """key -> formatted text, only for measures whose source text is unchanged since it was formatted."""
    if not os.path.exists(DAX_CACHE):
        return {}
    cache = json.load(open(DAX_CACHE))
    return {k.key: cache[k.key]['formatted'] for k in K
            if isinstance(cache.get(k.key), dict) and cache[k.key].get('src') == dax_source(k)}


def dax_script_lines(K, formatted):
    """DEFINE MEASURE script for the Power BI DAX query view (formatted with SQLBI's DAX Formatter rules)."""
    lines = ['DEFINE']
    for k in K:
        body = formatted.get(k.key)
        if body:
            body_lines = [ln.rstrip() for ln in body.replace('\r\n', '\n').strip('\n').split('\n')]
            assert body_lines[0].rstrip().endswith('='), body_lines[0]
            expr_lines = body_lines[1:]
        else:
            expr_lines = [k.dax]
        lines.append(f'    // {k.no}. {k.cat}')
        lines.append(f'    MEASURE Referrals[{k.name}] =')
        lines += ['        ' + ln for ln in expr_lines]
    lines.append('')
    lines.append('EVALUATE')
    lines.append('    ROW (')
    show = [k for k in K if k.key in ('total', 'unique', 'emerg_rate', 'accept_rate', 'hf_ref_rate', 'completion_rate')]
    for i, k in enumerate(show):
        lines.append(f'        "{k.name}", [{k.name}]' + (',' if i < len(show) - 1 else ''))
    lines.append('    )')
    return lines


# ---------------------------------------------------------------------------------------------------------------
# the builder
# ---------------------------------------------------------------------------------------------------------------
def build(out_path=OUT_DEFAULT, filters=None, poison=False, quiet=False, mutate=None):
    filters = dict(filters or {})
    df = pd.read_pickle(os.path.join(HERE, 'referrals.pkl'))
    if mutate is not None:                                # verification only: inject blanks / unlisted values
        df = mutate(df.copy())
    n = len(df)                                           # rows in the table
    n_all = int(df[PID].notna().sum())                    # records (rows with a Patient ID)
    mask = make_mask(df, filters)
    ctx = Ctx(df, mask)
    d = ctx.d
    K = KP.build_kpis(L)
    formatted_dax = load_dax_cache(K)

    wb = xlsxwriter.Workbook(out_path)
    wb.set_properties({'title': 'Maternal Referral Dashboard', 'subject': 'Referral register, KPIs, DAX and Power Query (M)',
                       'author': 'Arena Agent', 'comments': 'Synthetic demonstration data - no real patient records.',
                       'keywords': 'maternal health, referral, dashboard, KPI, DAX, Power Query'})
    S = {name: wb.add_worksheet(name) for name in SHEETS}
    expected = {}                                         # (sheet, row, col) -> value

    def mk(**kw):
        base = {'font_name': 'Calibri', 'font_size': 10, 'valign': 'vcenter', 'font_color': TXT}
        base.update(kw)
        if base.get('indent') and 'align' not in base:
            base['align'] = 'left'                        # an indent is only honoured everywhere with explicit left alignment
        return wb.add_format(base)

    def F(sheet, r, c, formula, value, fmt=None):
        """write formula + cached result (recorded for verification)."""
        value = py(value)
        if isinstance(value, float) and (math.isnan(value) or math.isinf(value)):
            raise ValueError((sheet, r, c, formula))
        expected[(sheet, r, c)] = value
        S[sheet].write_formula(r, c, formula if formula.startswith('=') else '=' + formula, fmt, POISON if poison else value)

    def FA(sheet, r, c, formula, value, fmt=None):
        """array (CSE) formula in a single cell."""
        value = py(value)
        expected[(sheet, r, c)] = value
        body = formula.lstrip('=')
        S[sheet].write_array_formula(r, c, r, c, '{=' + body + '}', fmt, POISON if poison else value)

    # ===========================================================================================================
    # 1. RAW DATA
    # ===========================================================================================================
    ws = S['Raw Data']
    f_hdr = mk(bold=True, font_color=WHITE, bg_color=NAVY, align='center', text_wrap=True, border=1, border_color='#3A5571')
    f_hdr_h = mk(bold=True, italic=True, font_color=WHITE, bg_color=SLATE, align='center', text_wrap=True, border=1, border_color='#3A5571')
    f_c = mk(align='center')
    f_ci = mk(align='center', num_format='0')
    f_cd = mk(align='center', num_format='dd-mmm-yyyy')
    f_flag = mk(align='center', num_format='0', font_color=SLATE, italic=True)
    colfmt = {AGE: f_ci, GA: f_ci, NVIS: f_ci, ENR: f_cd, VIS: f_cd}
    flag_parts = [f'{xrow(PID)}<>""']
    flag_parts += [f'OR(f_{k}="All",{xrow(LIST_COL[k])}=f_{k})' for k, _ in FILTERS[:14]]
    flag_parts += [f'OR(AND(f_DateFrom=0,f_DateTo={DATE_MAX_SERIAL}),'
                   f'AND({xrow(VIS)}<>"",{xrow(VIS)}>=f_DateFrom,{xrow(VIS)}<=f_DateTo))']
    flag_formula = 'IF(AND(' + ','.join(flag_parts) + '),1,0)'
    columns = [{'header': h, 'header_format': f_hdr, 'format': colfmt.get(h, f_c)} for h in L.COLUMNS]
    columns.append({'header': FLAG, 'header_format': f_hdr_h, 'format': f_flag, 'formula': flag_formula})
    data = [[None if (v is None or (isinstance(v, float) and math.isnan(v))) else py(v) for v in row]
            for row in df.itertuples(index=False, name=None)]
    NCOL = len(L.COLUMNS) + 1
    FLAG_C = NCOL - 1
    ws.add_table(0, 0, n, NCOL - 1, {'name': TBL, 'style': 'Table Style Light 1', 'columns': columns, 'data': data})
    mvals = mask.tolist()
    for i in range(n):
        F('Raw Data', 1 + i, FLAG_C, flag_formula, 1 if mvals[i] else 0, f_flag)
    widths = {PID: 11, 'Patient Name': 15, 'Husband Name': 15, AGE: 7, SITE: 16, ENR: 14, GA: 12, ANOM: 12, VIS: 13, NVIS: 10,
              PRI: 12, HIST: 29, COND: 12, REAS: 27, SHIFT: 11, STAFF: 14, FAC: 11, ACC: 11, RREF: 26, HFR: 11, HFREAS: 26,
              STAT: 16, FLAG: 9}
    for j, h in enumerate(L.COLUMNS + [FLAG]):
        ws.set_column(j, j, widths[h])
    ws.set_row(0, 33)
    ws.freeze_panes(1, 2)
    ws.set_tab_color(TEAL)
    COLIDX = {h: j for j, h in enumerate(L.COLUMNS)}
    msg = "Pick a value from the list. To add a new option, type it in the matching column of the 'Filter Data' sheet first."
    for key, colname, _ in LISTS:
        ws.data_validation(1, COLIDX[colname], n, COLIDX[colname],
                           {'validate': 'list', 'source': f'=lst_{key}', 'ignore_blank': True,
                            'error_title': 'Value not in list', 'error_message': msg, 'error_type': 'stop'})
    ws.data_validation(1, COLIDX[AGE], n, COLIDX[AGE], {'validate': 'integer', 'criteria': 'between', 'minimum': 10, 'maximum': 60,
                       'ignore_blank': True, 'error_title': 'Age', 'error_message': 'Enter age in completed years (10-60).', 'error_type': 'warning'})
    ws.data_validation(1, COLIDX[GA], n, COLIDX[GA], {'validate': 'integer', 'criteria': 'between', 'minimum': 1, 'maximum': 45,
                       'ignore_blank': True, 'error_title': 'Gestational age', 'error_message': 'Enter gestational age in completed weeks (1-45).', 'error_type': 'warning'})
    ws.data_validation(1, COLIDX[NVIS], n, COLIDX[NVIS], {'validate': 'integer', 'criteria': 'between', 'minimum': 1, 'maximum': 30,
                       'ignore_blank': True, 'error_title': 'Number of visit', 'error_message': 'Enter the visit number (1, 2, 3 ...).', 'error_type': 'warning'})
    for c_ in (ENR, VIS):
        ws.data_validation(1, COLIDX[c_], n, COLIDX[c_], {'validate': 'date', 'criteria': 'between', 'minimum': dt.date(2000, 1, 1),
                           'maximum': dt.date(2100, 12, 31), 'ignore_blank': True, 'error_title': 'Date',
                           'error_message': 'Enter a valid date, e.g. 05-Jan-2026.', 'error_type': 'warning'})
    f_red = wb.add_format({'font_color': '#C0392B', 'bold': True})
    f_amb = wb.add_format({'font_color': '#B9770E'})
    f_grn = wb.add_format({'font_color': '#1E8449'})
    for colname, val, f_ in ((PRI, 'Emergency', f_red), (COND, 'Unstable', f_red), (STAT, 'Incomplete', f_red),
                             (STAT, 'Partial Complete', f_amb), (STAT, 'Completed', f_grn)):
        ws.conditional_format(1, COLIDX[colname], n, COLIDX[colname],
                              {'type': 'cell', 'criteria': '==', 'value': f'"{val}"', 'format': f_})
    ws.write_comment(0, FLAG_C, "Helper column (auto-calculated): 1 = this row has a Patient ID and matches the filters selected on the Dashboard, 0 = it does not. "
                                "The Dashboard and KPIs sheets count only rows with 1. Filter this column on 1 to list the records behind "
                                "the dashboard numbers. Do not delete.", {'x_scale': 2.2, 'y_scale': 1.6})
    ws.set_landscape()
    ws.set_paper(9)
    ws.fit_to_pages(1, 0)
    ws.repeat_rows(0)
    ws.ignore_errors({'formula_differs': f'A1:{xl_col_to_name(NCOL - 1)}{n + 1}'})

    # ===========================================================================================================
    # 2. FILTER DATA (dropdown lists)
    # ===========================================================================================================
    ws = S['Filter Data']
    ws.hide_gridlines(2)
    ws.set_tab_color(TEAL)
    f_title = mk(font_size=16, bold=True, font_color=NAVY)
    f_note = mk(font_size=10, font_color=GREY_T, text_wrap=True, valign='top')
    f_lh = mk(bold=True, font_color=WHITE, bg_color=NAVY, align='center', text_wrap=True, border=1, border_color=WHITE)
    f_lv = mk(bg_color=WHITE, border=1, border_color=GREY_L, indent=1)
    f_ls = mk(bg_color='#FAFBFC', border=1, border_color=GREY_LL, indent=1, font_color=GREY_T)
    ws.set_row(0, 26)
    ws.write(0, 0, 'Filter Data - dropdown lists', f_title)
    ws.merge_range(1, 0, 1, 13,
                   "These lists drive (1) the dropdowns in the 'Raw Data' columns and (2) the filter dropdowns on the Dashboard. "
                   "To add a new option, type it in the first empty cell under the right heading (no gaps) - every dropdown picks it up "
                   "automatically. The placeholder 'a' entries of the original template were treated as empty slots.", f_note)
    ws.set_row(1, 44)
    ws.set_row(FD_FIRST - 1, 33)
    fd_w = {'Site': 17, 'Anomaly': 12, 'Priority': 12, 'History': 30, 'Condition': 12, 'Reason': 28, 'Shift': 11, 'Staff': 15,
            'Facility': 12, 'Accepted': 11, 'RefusalReason': 27, 'HFRefusal': 11, 'HFReason': 27, 'Status': 17}
    for j, (key, colname, values) in enumerate(LISTS):
        ws.set_column(j, j, fd_w[key])
        ws.write(FD_FIRST - 1, j, colname, f_lh)
        for i in range(N_SLOTS):
            if i < len(values):
                ws.write_string(FD_FIRST + i, j, values[i], f_lv)
            else:
                ws.write_blank(FD_FIRST + i, j, None, f_ls)
        col_rng = rng('Filter Data', FD_FIRST, j, FD_FIRST + N_SLOTS - 1, j)
        wb.define_name(f'lst_{key}', f"={ref('Filter Data', FD_FIRST, j)}:INDEX({col_rng},COUNTA({col_rng}))")
    ws.freeze_panes(FD_FIRST, 0)

    # ===========================================================================================================
    # 3. CALC (engine behind the dashboard)
    # ===========================================================================================================
    ws = S['Calc']
    ws.set_tab_color('#9AA5B1')
    f_ct = mk(font_size=13, bold=True, font_color=NAVY)
    f_ch = mk(bold=True, bg_color=GREY_LL, border=1, border_color=GREY_L, text_wrap=True)
    f_cv = mk()
    f_cn = mk(num_format='#,##0')
    f_cp = mk(num_format='0.0%')
    f_cdt = mk(num_format='dd-mmm-yyyy', align='left')
    f_cs = mk(num_format='0.000000', font_color=SLATE)
    f_cname = mk(font_color=SLATE, italic=True)
    ws.write(0, 0, "Calc - calculation engine behind the Dashboard and KPIs sheets (formulas only - please don't edit)", f_ct)
    ws.set_column(0, 0, 50)
    ws.set_column(1, 1, 30)
    ws.set_column(2, 2, 14)
    ws.set_column(3, 3, 12)
    ws.set_column(4, 4, 12)
    ws.set_column(5, 5, 12)
    ws.set_column(6, 6, 30)
    ws.set_column(7, 9, 12)
    ws.set_column(10, 10, 30)
    ws.set_column(11, 13, 13)
    ws.set_column(14, 14, 3)
    ws.set_column(15, 28, 16)
    C = 'Calc'

    # ---- 3a. normalised filter values -------------------------------------------------------------------------
    # Dashboard filter input cells: label row 3/5, input row 4/6 (0-indexed), 3 columns per filter starting at col B
    def filt_cell(i):
        return (4 + 2 * (i // 8), 1 + 3 * (i % 8))
    ws.write_row(2, 0, ['Dashboard filter', 'Active value (blank = All)', 'Defined name'], f_ch)
    FIL0 = 3
    for i, (key, label) in enumerate(FILTERS):
        r = FIL0 + i
        fr, fc = filt_cell(i)
        src = ref('Dashboard', fr, fc)
        ws.write(r, 0, label, f_cv)
        ws.write(r, 2, f'f_{key}', f_cname)
        if key == 'DateFrom':
            v = filters.get(key)
            F(C, r, 1, f'IF(ISNUMBER({src}),{src},0)', serial(v) if v else 0, f_cdt)
        elif key == 'DateTo':
            v = filters.get(key)
            F(C, r, 1, f'IF(ISNUMBER({src}),{src},{DATE_MAX_SERIAL})', serial(v) if v else DATE_MAX_SERIAL, f_cdt)
        else:
            v = filters.get(key, 'All') or 'All'
            F(C, r, 1, f'IF(OR({src}="",{src}="All"),"All",{src})', v, f_cv)
        wb.define_name(f'f_{key}', '=' + ref(C, r, 1))
    n_active = sum(1 for k, _ in FILTERS[:14] if filters.get(k, 'All') not in ('All', '', None)) \
        + (1 if filters.get('DateFrom') else 0) + (1 if filters.get('DateTo') else 0)

    # ---- 3b. global values ------------------------------------------------------------------------------------
    GL0 = 21
    ws.write_row(GL0, 0, ['Global value', 'Value', 'Defined name'], f_ch)
    all_max = KP.from_serial(df[VIS].map(KP.to_serial).astype(float).max())
    trend_end = dt.date(all_max.year, all_max.month, 1)
    sv = ctx.vis.dropna()
    has_dates = len(sv) > 0
    if has_dates:
        dmin, dmax = KP.from_serial(sv.min()), KP.from_serial(sv.max())
        last_month_start = dt.date(dmax.year, dmax.month, 1)
    else:
        dmin = dmax = last_month_start = None
    glob = {}

    def g(name, label, formula, value, fmt=f_cn, array=False):
        r = GL0 + 1 + len(glob)
        ws.write(r, 0, label, f_cv)
        ws.write(r, 2, name, f_cname)
        (FA if array else F)(C, r, 1, formula, value, fmt)
        wb.define_name(name, '=' + ref(C, r, 1))
        glob[name] = (r, 1)

    dated = f'({XFLAG}=1)*({xcol(VIS)}>0)'
    n_dated = f'COUNTIFS({XFLAG},1,{xcol(VIS)},">0")'
    g('c_AllRows', 'Records in the register (rows with a Patient ID)', f'COUNTA({xcol(PID)})', n_all)
    g('c_Total', 'Records in view (pass the filters)', f'COUNTIFS({XFLAG},1)', ctx.n)
    g('c_MinDate', 'First visit date in view', f'IF({n_dated}=0,"",MIN(IF({dated},{xcol(VIS)})))', serial(dmin) if has_dates else '', f_cdt, array=True)
    g('c_MaxDate', 'Last visit date in view', f'IF({n_dated}=0,"",MAX(IF({dated},{xcol(VIS)})))', serial(dmax) if has_dates else '', f_cdt, array=True)
    g('c_LastMonthStart', 'First day of the latest month in view', 'IF(c_MaxDate="","",DATE(YEAR(c_MaxDate),MONTH(c_MaxDate),1))',
      serial(last_month_start) if has_dates else '', f_cdt)
    g('c_ActiveFilters', 'Number of active filters',
      f'COUNTIF({a1(FIL0, 1)}:{a1(FIL0 + 13, 1)},"<>All")+IF(f_DateFrom>0,1,0)+IF(f_DateTo<{DATE_MAX_SERIAL},1,0)', n_active)
    g('c_TrendEnd', 'Last month shown in the trend chart (latest month in the register)',
      f'DATE(YEAR(MAX({xcol(VIS)})),MONTH(MAX({xcol(VIS)})),1)', serial(trend_end), f_cdt)
    top_rows_start = GL0 + 1 + len(glob)                      # c_Top*, c_Active*, c_Unlisted are added once their source blocks exist

    # ---- 3b-2. dropdown list check: values typed/pasted into Raw Data that are missing from the Filter Data lists ----
    LC0 = 43
    ws.write_row(LC0 - 1, 0, ['Dropdown list check (all rows)', 'Values in Raw Data that are NOT in the list', 'List'], f_ch)
    unlisted_total = 0
    for j, (key, colname, values) in enumerate(LISTS):
        r = LC0 + j
        col_rng = rng('Filter Data', FD_FIRST, j, FD_FIRST + N_SLOTS - 1, j)
        s_ = df[colname]
        cnt_unlisted = int((s_.notna() & ~s_.isin(values)).sum())
        unlisted_total += cnt_unlisted
        ws.write(r, 0, colname, f_cv)
        ws.write(r, 2, f'lst_{key}', f_cname)
        F(C, r, 1, f'SUMPRODUCT(({xcol(colname)}<>"")*(COUNTIF({col_rng},{xcol(colname)})=0))', cnt_unlisted, f_cn)

    # ---- 3c. monthly trend (last 24 months of the register) ----------------------------------------------------
    MO0, MOC = 3, 4
    ws.write_row(2, MOC, ['Month start', 'Label', 'Referrals', 'Completed', 'Completion rate'], f_ch)
    ym = sv.map(KP.ym_of)                                   # year*12+month of every dated record in view
    done_mask = (d[STAT] == 'Completed').reindex(ym.index)
    N_MONTHS = 24
    for i in range(N_MONTHS):
        r = MO0 + i
        k_ = trend_end.year * 12 + trend_end.month - 1 + (i - (N_MONTHS - 1))
        mdate = dt.date(k_ // 12, k_ % 12 + 1, 1)
        key_ = mdate.year * 12 + mdate.month
        cnt = int((ym == key_).sum()) if has_dates else 0
        comp = int(((ym == key_) & done_mask).sum()) if has_dates else 0
        mcell = a1(r, MOC)
        F(C, r, MOC, f'EDATE(c_TrendEnd,{i - (N_MONTHS - 1)})', serial(mdate), f_cdt)
        F(C, r, MOC + 1, f'TEXT({mcell},"mmm-yy")', mdate.strftime('%b-%y'), f_cv)
        F(C, r, MOC + 2, f'COUNTIFS({XFLAG},1,{xcol(VIS)},">="&{mcell},{xcol(VIS)},"<"&EDATE({mcell},1))', cnt, f_cn)
        F(C, r, MOC + 3, f'COUNTIFS({XFLAG},1,{xcol(VIS)},">="&{mcell},{xcol(VIS)},"<"&EDATE({mcell},1),{xcol(STAT)},"Completed")', comp, f_cn)
        F(C, r, MOC + 4, f'IF({a1(r, MOC + 2)}=0,NA(),{a1(r, MOC + 3)}/{a1(r, MOC + 2)})', (comp / cnt) if cnt else '#N/A', f_cp)

    # ---- 3d. small fixed blocks ---------------------------------------------------------------------------------
    BC = 10

    def cnt_of(conds):
        return KP.py_count(d, conds) if ctx.n else 0

    def cntf(conds):
        return KP.xl_count(conds)

    # status
    ST0 = 3
    ws.write_row(2, BC, ['Referral Status', 'Referrals'], f_ch)
    for i, s_ in enumerate(L.STATUS):
        ws.write(ST0 + i, BC, s_, f_cv)
        F(C, ST0 + i, BC + 1, f'COUNTIFS({XFLAG},1,{xcol(STAT)},{a1(ST0 + i, BC)})', cnt_of([(STAT, '=', s_)]), f_cn)
    # funnel
    FU0 = 9
    ws.write_row(8, BC, ['Stage (chart label)', 'Referrals', 'Stage'], f_ch)
    stages = [('Referred', []), ('Accepted by patient', [(ACC, '=', 'Yes')]),
              ('Accepted by facility', [(ACC, '=', 'Yes'), (HFR, '=', 'No')]), ('Completed', [(STAT, '=', 'Completed')])]
    for i, (name, conds) in enumerate(stages):
        r = FU0 + i
        v = cnt_of(conds)
        ws.write(r, BC + 2, name, f_cv)
        F(C, r, BC + 1, cntf(conds), v, f_cn)
        share = (v / ctx.n) if ctx.n else 0
        F(C, r, BC, f'{a1(r, BC + 2)}&"  ("&TEXT(IF(c_Total=0,0,{a1(r, BC + 1)}/c_Total),"0%")&")"', f'{name}  ({t_pct(share, 0)})', f_cv)
    # shift x priority
    SH0 = 16
    ws.write_row(15, BC, ['Shift', 'Routine', 'Emergency'], f_ch)
    for i, sh in enumerate(L.SHIFTS):
        r = SH0 + i
        ws.write(r, BC, sh, f_cv)
        for j, p_ in enumerate(L.PRIORITY):
            F(C, r, BC + 1 + j, f'COUNTIFS({XFLAG},1,{xcol(SHIFT)},{a1(r, BC)},{xcol(PRI)},{a1(15, BC + 1 + j)})',
              cnt_of([(SHIFT, '=', sh), (PRI, '=', p_)]), f_cn)
    # condition x priority
    CP0 = 22
    ws.write_row(21, BC, ['Priority', 'Stable', 'Unstable'], f_ch)
    for i, p_ in enumerate(L.PRIORITY):
        r = CP0 + i
        ws.write(r, BC, p_, f_cv)
        for j, c_ in enumerate(L.CONDITION):
            F(C, r, BC + 1 + j, f'COUNTIFS({XFLAG},1,{xcol(PRI)},{a1(r, BC)},{xcol(COND)},{a1(21, BC + 1 + j)})',
              cnt_of([(PRI, '=', p_), (COND, '=', c_)]), f_cn)
    # age groups
    AG0 = 27
    ws.write_row(26, BC, ['Age group (years)', 'Referrals'], f_ch)
    age_bands = [('<20', None, 19), ('20-24', 20, 24), ('25-29', 25, 29), ('30-34', 30, 34), ('35-39', 35, 39), ('40+', 40, None)]
    for i, (lab, lo, hi) in enumerate(age_bands):
        conds = ([(AGE, '>=', lo)] if lo is not None else []) + ([(AGE, '<=', hi)] if hi is not None else [])
        ws.write_string(AG0 + i, BC, lab, f_cv)
        F(C, AG0 + i, BC + 1, cntf(conds), cnt_of(conds), f_cn)
    # gestational-age bands
    GA0 = 36
    ws.write_row(35, BC, ['Gestational age at referral', 'Referrals'], f_ch)
    ga_bands = [('\u226413 wks', None, 13), ('14\u201327 wks', 14, 27), ('28\u201333 wks', 28, 33), ('34\u201336 wks', 34, 36), ('37+ wks', 37, None)]
    for i, (lab, lo, hi) in enumerate(ga_bands):
        conds = ([(GA, '>=', lo)] if lo is not None else []) + ([(GA, '<=', hi)] if hi is not None else [])
        ws.write_string(GA0 + i, BC, lab, f_cv)
        F(C, GA0 + i, BC + 1, cntf(conds), cnt_of(conds), f_cn)

    # ---- 3e. dashboard dropdown lists ("All" + list) --------------------------------------------------------------
    FO_C, FO_R = 15, 3
    for j, (key, colname, values) in enumerate(LISTS):
        cc = FO_C + j
        ws.write(2, cc, f'flt_{key}', f_ch)
        ws.write_string(FO_R, cc, 'All', f_cv)
        for i in range(N_SLOTS):
            src = ref('Filter Data', FD_FIRST + i, j)
            F(C, FO_R + 1 + i, cc, f'IF({src}="","",{src})', values[i] if i < len(values) else '', f_cv)
        col_rng = rng('Filter Data', FD_FIRST, j, FD_FIRST + N_SLOTS - 1, j)
        wb.define_name(f'flt_{key}', f'={ref(C, FO_R, cc)}:INDEX({rng(C, FO_R, cc, FO_R + N_SLOTS, cc)},COUNTA({col_rng})+1)')

    # ---- 3f. ranked blocks ------------------------------------------------------------------------------------------
    RB0, RB_H = 62, N_SLOTS + 4
    ranked = {}

    def ranked_block(idx, key, title, with_status=False):
        colname, values = LIST_COL[key], LIST_VALUES[key]
        j = LIST_IDX[key]
        r0 = RB0 + idx * RB_H
        ws.write(r0, 0, title, mk(bold=True, font_color=NAVY, font_size=11))
        hdr = ['Slot', 'Value (from Filter Data)', 'Referrals', 'Sort key', 'Rank', 'k-th key', 'Ranked value', 'Referrals']
        if with_status:
            hdr += L.STATUS
        ws.write_row(r0 + 1, 0, hdr, f_ch)
        first, last = r0 + 2, r0 + 1 + N_SLOTS
        vc = d[colname].value_counts() if ctx.n else {}
        counts = [int(vc.get(v, 0)) for v in values]
        order = sorted(range(len(values)), key=lambda i: (-counts[i], i))
        lab_rng = f'{a1(first, 1)}:{a1(last, 1)}'
        key_rng = f'{a1(first, 3)}:{a1(last, 3)}'
        for i in range(N_SLOTS):
            r = first + i
            has = i < len(values)
            src = ref('Filter Data', FD_FIRST + i, j)
            ws.write_number(r, 0, i + 1, f_cv)
            F(C, r, 1, f'IF({src}="","",{src})', values[i] if has else '', f_cv)
            F(C, r, 2, f'IF({a1(r, 1)}="","",COUNTIFS({XFLAG},1,{xcol(colname)},{a1(r, 1)}))', counts[i] if has else '', f_cn)
            F(C, r, 3, f'IF({a1(r, 1)}="","",{a1(r, 2)}-{a1(r, 0)}/1000000)', counts[i] - (i + 1) / 1000000 if has else '', f_cs)
            # ranked side
            ws.write_number(r, 4, i + 1, f_cv)
            if has:
                oi = order[i]
                kth = counts[oi] - (oi + 1) / 1000000
                rlab, rcnt = (values[oi], counts[oi]) if counts[oi] > 0 else ('', '')     # values without records are not listed
            else:
                kth, rlab, rcnt = '', '', ''
            F(C, r, 5, f'IFERROR(LARGE({key_rng},{a1(r, 4)}),"")', kth, f_cs)
            F(C, r, 6, f'IF(N({a1(r, 5)})<0.5,"",INDEX({lab_rng},MATCH({a1(r, 5)},{key_rng},0)))', rlab, f_cv)
            F(C, r, 7, f'IF({a1(r, 6)}="","",ROUND({a1(r, 5)},0))', rcnt, f_cn)
            if with_status:
                for s_i, s_ in enumerate(L.STATUS):
                    v = cnt_of([(colname, '=', rlab), (STAT, '=', s_)]) if (has and rlab) else ''
                    F(C, r, 8 + s_i, f'IF({a1(r, 6)}="","",COUNTIFS({XFLAG},1,{xcol(colname)},{a1(r, 6)},{xcol(STAT)},{a1(r0 + 1, 8 + s_i)}))', v, f_cn)
        ranked[key] = dict(first=first, last=last, values=values, counts=counts, order=order, colname=colname)

    ranked_block(0, 'Reason', 'Reason of Referral - ranked')
    ranked_block(1, 'Facility', 'Referred facility - ranked (with status split)', with_status=True)
    ranked_block(2, 'Staff', 'Referred by staff - ranked')
    ranked_block(3, 'RefusalReason', 'Reason for refusal (patient) - ranked')
    ranked_block(4, 'HFReason', 'Reason of facility refusal - ranked')
    ranked_block(5, 'History', 'Previous history - ranked')
    ranked_block(6, 'Site', 'Site - ranked (with status split)', with_status=True)

    def top_of(key):
        rb = ranked[key]
        if not rb['values'] or not ctx.n:
            return UND, 0
        i = rb['order'][0]
        return (rb['values'][i], rb['counts'][i]) if rb['counts'][i] > 0 else (UND, 0)

    def g_top(name, label, key, count=False):
        rb = ranked[key]
        lab_c, cnt_c = a1(rb['first'], 6), a1(rb['first'], 7)
        r = top_rows_start + g_top.i
        g_top.i += 1
        ws.write(r, 0, label, f_cv)
        ws.write(r, 2, name, f_cname)
        tv, tc = top_of(key)
        if count:
            F(C, r, 1, f'IF(ISNUMBER({cnt_c}),{cnt_c},0)', tc, f_cn)
        else:
            F(C, r, 1, f'IF(N({cnt_c})>0,{lab_c},"{UND}")', tv, f_cv)
        wb.define_name(name, '=' + ref(C, r, 1))
    g_top.i = 0
    g_top('c_TopReason', 'Most frequent reason of referral', 'Reason')
    g_top('c_TopRefusalReason', 'Most frequent reason for patient refusal', 'RefusalReason')
    g_top('c_TopHFReason', 'Most frequent reason of facility refusal', 'HFReason')
    g_top('c_TopStaff', 'Staff member with most referrals', 'Staff')
    g_top('c_TopFacility', 'Facility receiving most referrals', 'Facility')
    g_top('c_TopFacilityCount', 'Referrals to the busiest facility', 'Facility', count=True)
    g_top('c_TopSite', 'Site with most referrals', 'Site')

    def g_extra(name, label, formula, value):
        r = top_rows_start + g_top.i
        g_top.i += 1
        ws.write(r, 0, label, f_cv)
        ws.write(r, 2, name, f_cname)
        F(C, r, 1, formula, value, f_cn)
        wb.define_name(name, '=' + ref(C, r, 1))

    def n_active_values(key):
        rb = ranked[key]
        return sum(1 for c_ in rb['counts'] if c_ > 0)
    for name, label, key in (('c_ActiveSites', 'Sites with at least one record in view', 'Site'),
                             ('c_ActiveStaff', 'Staff members with at least one record in view', 'Staff'),
                             ('c_ActiveFacilities', 'Facilities with at least one record in view', 'Facility')):
        rb = ranked[key]
        g_extra(name, label, f'COUNTIF({a1(rb["first"], 2)}:{a1(rb["last"], 2)},">0")', n_active_values(key))
    g_extra('c_Unlisted', 'Values in Raw Data missing from the dropdown lists', f'SUM({a1(LC0, 1)}:{a1(LC0 + len(LISTS) - 1, 1)})', unlisted_total)
    assert top_rows_start + g_top.i <= LC0 - 2, 'globals block overlaps the list-check block'
    ws.freeze_panes(2, 0)
    ws.ignore_errors({'formula_differs': 'A1:AD400', 'formula_range': 'A1:AD400'})

    # ===========================================================================================================
    # 4. KPIs (catalogue: definition + live value + DAX + M)
    # ===========================================================================================================
    ws = S['KPIs']
    ws.hide_gridlines(2)
    ws.set_tab_color(NAVY)
    kvals = {}
    for k in K:
        kvals[k.key] = py(k.py(ctx, kvals))
    krow = {k.key: KPI_FIRST_ROW + i for i, k in enumerate(K)}

    def kref(key, local=False):
        cell = a1(krow[key], KPI_VALUE_COL)
        return cell if local else f'KPIs!{cell}'

    def expand(formula, local):
        return re.sub(r'\{k:(\w+)\}', lambda m_: kref(m_.group(1), local), formula)

    cat_colors = {'Volume & Reach': NAVY, 'Priority & Condition': CORAL, 'Patient Profile': PURPLE, 'Reasons for Referral': TEAL,
                  'Patient Acceptance': BLUE, 'Facility Response': AMBER, 'Outcomes': GREEN, 'Operations': SLATE, 'Data Quality': '#8E6E53'}
    ws.set_column(0, 0, 5)
    ws.set_column(1, 1, 21)
    ws.set_column(2, 2, 35)
    ws.set_column(3, 3, 47)
    ws.set_column(4, 4, 17)
    ws.set_column(5, 5, 14)
    ws.set_column(6, 6, 82)
    ws.set_column(7, 7, 92)
    ws.set_row(0, 28)
    ws.write(0, 0, f'KPI Catalogue - {len(K)} KPIs with live value, DAX measure and Power Query (M) expression', mk(font_size=16, bold=True, font_color=NAVY))
    f_live = mk(font_size=10, bold=True, font_color=WHITE, bg_color=TEAL, indent=1)
    msg_all = f'no filter is active - all {t_int(n_all)} records are included.'
    msg_flt = f'{n_active} filter(s) active - {t_int(ctx.n)} of {t_int(n_all)} records are included.'
    ws.merge_range(1, 0, 1, 7, '', f_live)
    F('KPIs', 1, 0, ('"LIVE VALUES follow the filters chosen on the Dashboard sheet: "&IF(c_ActiveFilters=0,"no filter is active - all "'
                     '&TEXT(c_AllRows,"#,##0")&" records are included.",c_ActiveFilters&" filter(s) active - "&TEXT(c_Total,"#,##0")'
                     '&" of "&TEXT(c_AllRows,"#,##0")&" records are included.")'),
      'LIVE VALUES follow the filters chosen on the Dashboard sheet: ' + (msg_all if n_active == 0 else msg_flt), f_live)
    ws.set_row(1, 20)
    f_how = mk(font_size=9.5, font_color=GREY_T, text_wrap=True, valign='top', indent=1)
    ws.merge_range(2, 0, 2, 7,
                   'DAX: paste a cell from column G into Power BI (Modeling > New measure) - the table must be named Referrals (see sheet "Power Query M"); '
                   'set the measure format shown in column F. All measures at once: sheet "DAX Measures".    '
                   'M: paste a cell from column H into a Blank Query (Advanced Editor) - it returns the KPI as a single value; '
                   'the query "KPI_Summary" on sheet "Power Query M" returns all KPIs as one table.    '
                   f'"{UND}" = not defined for the current selection (e.g. division by zero).', f_how)
    ws.set_row(2, 42)
    f_kh = mk(bold=True, font_color=WHITE, bg_color=NAVY, align='center', text_wrap=True, border=1, border_color='#3A5571')
    ws.write_row(KPI_FIRST_ROW - 1, 0, ['#', 'Category', 'KPI', 'Definition', 'Live value', 'Format', 'DAX measure', 'Power Query (M) expression'], f_kh)
    ws.set_row(KPI_FIRST_ROW - 1, 24)
    bord = dict(border=1, border_color=GREY_L)
    f_kno = mk(align='center', valign='top', font_color=GREY_T, **bord)
    f_kname = mk(bold=True, valign='top', text_wrap=True, **bord)
    f_kdesc = mk(valign='top', text_wrap=True, font_color=GREY_T, **bord)
    f_kfmt = mk(valign='top', align='center', font_color=GREY_T, font_size=9, text_wrap=True, **bord)
    f_code = mk(font_name='Consolas', font_size=9, valign='top', text_wrap=True, bg_color='#FAFBFC', **bord)
    vfmt = {'int': '#,##0', 'pct': '0.0%', 'dec1': '0.0', 'dec2': '0.00', 'text': '@'}
    f_kval = {t: mk(bold=True, font_size=12, valign='top', align='right' if t != 'text' else 'left', num_format=nf, font_color=NAVY,
                    bg_color='#F2FAF8', indent=1, text_wrap=(t == 'text'), **bord) for t, nf in vfmt.items()}
    f_kcat = {c_: mk(bold=True, valign='top', font_color=WHITE, bg_color=col, text_wrap=True, **bord) for c_, col in cat_colors.items()}
    for i, k in enumerate(K):
        r = KPI_FIRST_ROW + i
        dax_text = f'{k.name} = {k.dax}'
        ws.write_number(r, 0, k.no, f_kno)
        ws.write_string(r, 1, k.cat, f_kcat[k.cat])
        ws.write_string(r, 2, k.name, f_kname)
        ws.write_string(r, 3, k.desc, f_kdesc)
        (FA if k.array else F)('KPIs', r, KPI_VALUE_COL, expand(k.xl, True), kvals[k.key], f_kval[k.fmt])
        ws.write_string(r, 5, f'{KP.FMT_LABEL[k.fmt]}\n{KP.FMT_DAX[k.fmt]}', f_kfmt)
        ws.write_string(r, 6, dax_text, f_code)
        ws.write_string(r, 7, k.m, f_code)
        lines = max(math.ceil(len(dax_text) / 74), math.ceil(len(k.m) / 84), math.ceil(len(k.desc) / 50) + 0, 2)
        ws.set_row(r, 5 + 12.4 * lines)
    ws.freeze_panes(KPI_FIRST_ROW, 3)
    ws.autofilter(KPI_FIRST_ROW - 1, 0, KPI_FIRST_ROW - 1 + len(K), 7)
    ws.ignore_errors({'formula_differs': f'E{KPI_FIRST_ROW + 1}:E{KPI_FIRST_ROW + len(K)}', 'formula_range': f'E{KPI_FIRST_ROW + 1}:E{KPI_FIRST_ROW + len(K)}'})
    ws.set_landscape()
    ws.set_paper(9)
    ws.fit_to_pages(1, 0)
    ws.repeat_rows(KPI_FIRST_ROW - 1)

    # ===========================================================================================================
    # 5. POWER QUERY M  +  6. DAX MEASURES (one line per cell, so a block of cells pastes cleanly)
    # ===========================================================================================================
    f_sc_title = mk(font_size=16, bold=True, font_color=NAVY)
    f_sc_note = mk(font_size=10, font_color=GREY_T, text_wrap=True, valign='top')
    f_sc_head = mk(bold=True, font_size=11, font_color=WHITE, bg_color=NAVY, indent=1)
    f_sc_sub = mk(italic=True, font_color=GREY_T, bg_color=GREY_LL, indent=1)
    f_sc_code = mk(font_name='Consolas', font_size=10, bg_color='#FAFBFC', font_color='#1F2D3D', left=2, left_color=TEAL)
    f_sc_cmt = mk(font_name='Consolas', font_size=10, bg_color='#FAFBFC', font_color='#2E7D5B', left=2, left_color=TEAL)

    def code_block(ws_, r, title, hint, lines):
        ws_.write_string(r, 0, title, f_sc_head)
        ws_.set_row(r, 20)
        ws_.write_string(r + 1, 0, hint, f_sc_sub)
        first = r + 2
        for i, ln in enumerate(lines):
            if ln == '':
                ws_.write_blank(first + i, 0, None, f_sc_code)
            else:
                ws_.write_string(first + i, 0, ln, f_sc_cmt if ln.strip().startswith('//') else f_sc_code)
        return first, first + len(lines) - 1

    m_blocks = [('Referrals', 'QUERY 1  -  Referrals   (fact table: one row per referral visit; every KPI and DAX measure reads this query)',
                 m_referrals_query()),
                ('Calendar', 'QUERY 2  -  Calendar   (optional date table; relate Calendar[Date] to Referrals[Date of visit])', m_calendar_query()),
                ('KPI_Summary', f'QUERY 3  -  KPI_Summary   (all {len(K)} KPIs calculated in M - one row per KPI: No, Category, KPI, Value, Display, Format)', m_kpi_summary_query(K))]
    ws = S['Power Query M']
    ws.hide_gridlines(2)
    ws.set_tab_color(PURPLE)
    ws.set_column(0, 0, 150)
    ws.set_row(0, 28)
    ws.write(0, 0, 'Power Query (M) - ready-to-paste queries', f_sc_title)
    ws.write(1, 0, 'How to use: Power BI Desktop (or Excel > Data) > Get Data > Blank Query > Advanced Editor. Select the code cells of one query below '
                   '(click the first line, Shift+click the last line), copy, paste into the Advanced Editor, click Done, then rename the query exactly as '
                   'shown in its title. Create "Referrals" first - the other queries read from it. In query 1 change FilePath to where this workbook is saved.',
             f_sc_note)
    ws.set_row(1, 46)
    r = 3
    m_ranges = {}
    for name, title, lines in m_blocks:
        hint = f'Copy the cells below into the Advanced Editor and name the query:  {name}'
        first, last = code_block(ws, r, title, hint, lines)
        m_ranges[name] = (first, last)
        r = last + 3

    ws = S['DAX Measures']
    ws.hide_gridlines(2)
    ws.set_tab_color(PURPLE)
    ws.set_column(0, 0, 150)
    ws.set_row(0, 28)
    ws.write(0, 0, f'DAX - all {len(K)} measures in one script', f_sc_title)
    ws.write(1, 0, 'Fastest way to create every measure: Power BI Desktop > DAX query view (left rail) > New query. Select the code cells below '
                   '(first line to last line), copy and paste them into the editor, then click "Update model with changes" - all measures are added to the '
                   'Referrals table. Afterwards set each measure\'s format (Percentage / Whole number / Decimal) as listed in column F of the KPIs sheet. '
                   'Prefer one at a time? Use column G of the KPIs sheet with Modeling > New measure. Measures use KEEPFILTERS so they respect slicers '
                   'on the same column.', f_sc_note)
    ws.set_row(1, 60)
    dax_lines = dax_script_lines(K, formatted_dax)
    dax_first, dax_last = code_block(ws, 3, 'DAX QUERY VIEW SCRIPT  -  DEFINE MEASURE ... for all KPIs',
                                     'Requires a table named Referrals (query 1 on the "Power Query M" sheet).', dax_lines)

    # ===========================================================================================================
    # 7. DASHBOARD
    # ===========================================================================================================
    ws = S['Dashboard']
    D = 'Dashboard'
    ws.hide_gridlines(2)
    ws.hide_row_col_headers()
    ws.set_tab_color(CORAL)
    f_bg = mk(bg_color=BG)
    ws.set_column_pixels(0, 0, 14, f_bg)
    ws.set_column_pixels(1, 24, 54, f_bg)
    ws.set_column_pixels(25, 25, 14, f_bg)
    ws.set_column(26, 16383, None, None, {'hidden': True})
    LAST_COL = 24
    row_h = {0: 36, 1: 23, 2: 18, 3: 15, 4: 23, 5: 15, 6: 23, 7: 9, 8: 21, 9: 38, 10: 21, 11: 8, 12: 19, 13: 30, 14: 19, 15: 10}
    for r_, h_ in row_h.items():
        ws.set_row_pixels(r_, h_)

    # ---- banner -----------------------------------------------------------------------------------------------
    f_ban = mk(bg_color=NAVY)
    f_ban_t = mk(bg_color=NAVY, font_color=WHITE, bold=True, font_size=18, indent=1)
    f_ban_s = mk(bg_color=NAVY, font_color='#C9DCEA', font_size=10, indent=1)
    f_ban_l = mk(bg_color='#E6EEF5', font_color=NAVY, font_size=9, bold=True, align='center', underline=0,
                 top=5, bottom=5, left=5, right=5, top_color=NAVY, bottom_color=NAVY, left_color=NAVY, right_color=NAVY)
    for r_ in (0, 1):
        ws.write_blank(r_, 0, None, f_ban)
        ws.write_blank(r_, 25, None, f_ban)
    ws.merge_range(0, 1, 0, LAST_COL, 'Maternal Referral Dashboard', f_ban_t)
    links = [('KPIs', 'KPIs'), ('Raw Data', 'Raw Data'), ('Filter Data', 'Filter Data'), ('Power Query M', 'Power Query M'),
             ('DAX Measures', 'DAX Measures'), ('Read Me', 'Read Me')]
    for i, (sheet, label) in enumerate(links):
        c0 = 13 + 2 * i
        ws.merge_range(1, c0, 1, c0 + 1, '', f_ban_l)
        ws.write_url(1, c0, f"internal:{qs(sheet)}!A1", f_ban_l, string=label, tip=f'Go to the {label} sheet')
    if not ctx.n:
        period = 'No records match - set some filters back to All'
    elif not has_dates:
        period = 'No visit dates in view'
    else:
        period = f"Visit dates {dmin.strftime('%d %b %Y')} to {dmax.strftime('%d %b %Y')}"
    status_txt = f'Showing {t_int(ctx.n)} of {t_int(n_all)} referrals   |   {period}   |   Filters active: {n_active}'
    ws.merge_range(1, 1, 1, 12, '', f_ban_s)
    F(D, 1, 1, ('"Showing "&TEXT(c_Total,"#,##0")&" of "&TEXT(c_AllRows,"#,##0")&" referrals   |   "&IF(c_Total=0,'
                '"No records match - set some filters back to All",IF(c_MinDate="","No visit dates in view",'
                '"Visit dates "&TEXT(c_MinDate,"dd mmm yyyy")&" to "&TEXT(c_MaxDate,"dd mmm yyyy")))'
                '&"   |   Filters active: "&c_ActiveFilters'), status_txt, f_ban_s)

    # ---- filters ----------------------------------------------------------------------------------------------
    f_hint = mk(bg_color=BG, font_color=GREY_T, font_size=9, italic=True, indent=1)
    hint_ok = ("FILTERS  -  pick a value in any box below ('All' or an empty box = no filter). "
               "Every card, chart and table on this sheet, and all values on the KPIs sheet, update instantly.")
    hint_warn = (" value(s) in 'Raw Data' are not in the 'Filter Data' lists, so they are missing from the dropdowns, rankings and scorecards. "
                 f"Add them to the lists (which columns: sheet 'Calc', rows {LC0 + 1}-{LC0 + len(LISTS)}).")
    ws.merge_range(2, 1, 2, LAST_COL, '', f_hint)
    F(D, 2, 1, f'IF(c_Unlisted=0,"{hint_ok}","CHECK DATA  -  "&c_Unlisted&"{hint_warn}")',
      hint_ok if unlisted_total == 0 else f'CHECK DATA  -  {unlisted_total}{hint_warn}', f_hint)
    ws.conditional_format(2, 1, 2, LAST_COL, {'type': 'formula', 'criteria': '=c_Unlisted>0',
                                              'format': wb.add_format({'font_color': '#C0392B', 'bold': True})})
    f_fl = mk(bg_color=BG, font_color=GREY_T, font_size=8, bold=True, indent=1, valign='bottom')
    f_fi = mk(bg_color=WHITE, font_color=NAVY, bold=True, font_size=10, indent=1, shrink=True,
              top=1, bottom=1, left=5, right=5, top_color=GREY_L, bottom_color=GREY_L, left_color=BG, right_color=BG)
    f_fid = mk(bg_color=WHITE, font_color=NAVY, bold=True, font_size=10, indent=1, num_format='dd-mmm-yyyy', align='left',
               top=1, bottom=1, left=5, right=5, top_color=GREY_L, bottom_color=GREY_L, left_color=BG, right_color=BG)
    f_factive = wb.add_format({'bg_color': '#FFE9A8', 'font_color': '#7A4B00'})
    for i, (key, label) in enumerate(FILTERS):
        fr, fc = filt_cell(i)
        lab = label.upper() + ('  (BLANK = ALL)' if key.startswith('Date') else '')
        ws.merge_range(fr - 1, fc, fr - 1, fc + 2, lab, f_fl)
        if key.startswith('Date'):
            ws.merge_range(fr, fc, fr, fc + 2, '', f_fid)
            v = filters.get(key)
            if v:
                ws.write_datetime(fr, fc, dt.datetime(v.year, v.month, v.day), f_fid)
            ws.data_validation(fr, fc, fr, fc, {'validate': 'date', 'criteria': 'between', 'minimum': dt.date(2000, 1, 1),
                               'maximum': dt.date(2100, 12, 31), 'ignore_blank': True,
                               'input_title': label, 'input_message': 'Type a date (e.g. 01-Jan-2026) or leave empty for no limit.',
                               'error_title': 'Date needed', 'error_message': 'Enter a valid date such as 01-Jan-2026, or clear the cell.'})
            ws.conditional_format(fr, fc, fr, fc + 2, {'type': 'formula', 'criteria': f'={a1(fr, fc)}<>""', 'format': f_factive})
        else:
            ws.merge_range(fr, fc, fr, fc + 2, filters.get(key, 'All') or 'All', f_fi)
            ws.data_validation(fr, fc, fr, fc, {'validate': 'list', 'source': f'=flt_{key}', 'ignore_blank': True,
                               'error_title': 'Pick from the list', 'error_type': 'stop',
                               'error_message': "Choose a value from the dropdown, or 'All' for no filter."})
            ws.conditional_format(fr, fc, fr, fc + 2, {'type': 'formula', 'criteria': f'=AND({a1(fr, fc)}<>"",{a1(fr, fc)}<>"All")',
                                                       'format': f_factive})

    # ---- KPI cards --------------------------------------------------------------------------------------------
    def card_formats(accent, big):
        common = dict(bg_color=WHITE, left=5, right=5, left_color=BG, right_color=BG)
        return (mk(font_size=8.5 if big else 8, bold=True, font_color=GREY_T, indent=1, top=5, top_color=accent, valign='bottom', **common),
                mk(font_size=8.5 if big else 8, font_color=GREY_T, indent=1, bottom=1, bottom_color=GREY_L, valign='top', shrink=True, **common),
                common)

    def card(idx, big, title, key, kind, sub_formula, sub_value, accent, title_formula=None, title_value=None):
        r0 = 8 if big else 12
        c0 = 1 + 3 * idx
        f_t, f_s, common = card_formats(accent, big)
        nf = {'int': '#,##0', 'pct': '0.0%', 'dec1': '0.0', 'dec2': '0.00', 'wks': '0.0" wks"', 'yrs': '0.0" yrs"'}[kind]
        f_v = mk(font_size=22 if big else 16, bold=True, font_color=NAVY, indent=1, num_format=nf, align='left', **common)
        ws.merge_range(r0, c0, r0, c0 + 2, title if title_formula is None else '', f_t)
        if title_formula is not None:
            F(D, r0, c0, title_formula, title_value, f_t)
        ws.merge_range(r0 + 1, c0, r0 + 1, c0 + 2, '', f_v)
        F(D, r0 + 1, c0, '=' + kref(key), kvals[key], f_v)
        ws.merge_range(r0 + 2, c0, r0 + 2, c0 + 2, '', f_s)
        F(D, r0 + 2, c0, expand(sub_formula, False), sub_value, f_s)

    kv = kvals
    card(0, True, 'TOTAL REFERRALS', 'total', 'int', '"of "&TEXT(c_AllRows,"#,##0")&" records in the register"',
         f'of {t_int(n_all)} records in the register', NAVY)
    card(1, True, 'UNIQUE PATIENTS', 'unique', 'int', 'TEXT({k:per_patient},"0.00")&" referrals per patient"',
         f"{t_dec(kv['per_patient'], 2)} referrals per patient", NAVY)
    card(2, True, 'EMERGENCY RATE', 'emerg_rate', 'pct', 'TEXT({k:emerg},"#,##0")&" emergency referrals"',
         f"{t_int(kv['emerg'])} emergency referrals", CORAL)
    card(3, True, 'UNSTABLE ON ARRIVAL', 'unstable_rate', 'pct', 'TEXT({k:unstable},"#,##0")&" unstable patients"',
         f"{t_int(kv['unstable'])} unstable patients", CORAL)
    card(4, True, 'ACCEPTANCE RATE', 'accept_rate', 'pct', 'TEXT({k:accepted},"#,##0")&" accepted by patient"',
         f"{t_int(kv['accepted'])} accepted by patient", BLUE)
    card(5, True, 'HF REFUSAL RATE', 'hf_ref_rate', 'pct', 'TEXT({k:hf_ref},"#,##0")&" refused by facility"',
         f"{t_int(kv['hf_ref'])} refused by facility", AMBER)
    card(6, True, 'COMPLETION RATE', 'completion_rate', 'pct', 'TEXT({k:completed},"#,##0")&" referrals completed"',
         f"{t_int(kv['completed'])} referrals completed", GREEN)
    mom = kv['mom']
    if isinstance(mom, str):
        mom_txt = 'no previous month to compare'
    else:
        mom_txt = ('\u25b2 ' if mom >= 0 else '\u25bc ') + t_pct(abs(mom)) + ' vs previous month'
    card(7, True, None, 'latest', 'int',
         'IF(ISNUMBER({k:mom}),IF({k:mom}>=0,"\u25b2 ","\u25bc ")&TEXT(ABS({k:mom}),"0.0%")&" vs previous month","no previous month to compare")',
         mom_txt, TEAL,
         title_formula='IF(c_LastMonthStart="","LATEST MONTH","REFERRALS IN "&UPPER(TEXT(c_LastMonthStart,"mmm yyyy")))',
         title_value=('REFERRALS IN ' + last_month_start.strftime('%b %Y').upper()) if has_dates else 'LATEST MONTH')
    card(0, False, 'AVG MATERNAL AGE', 'age_avg', 'yrs', '"median "&TEXT({k:age_med},"0")&" years"',
         f"median {t_dec(kv['age_med'], 0)} years", PURPLE)
    card(1, False, 'TEENAGE (UNDER 20)', 'teen_rate', 'pct', 'TEXT({k:teen},"#,##0")&" referrals"', f"{t_int(kv['teen'])} referrals", PURPLE)
    card(2, False, 'AGE 35 AND OVER', 'ama_rate', 'pct', 'TEXT({k:ama},"#,##0")&" referrals"', f"{t_int(kv['ama'])} referrals", PURPLE)
    card(3, False, 'AVG GESTATIONAL AGE', 'ga_avg', 'wks', 'TEXT({k:tri3},"0.0%")&" in 3rd trimester"',
         f"{t_pct(kv['tri3'])} in 3rd trimester", PURPLE)
    card(4, False, 'SCAN ANOMALY RATE', 'anomaly_rate', 'pct', 'TEXT({k:anomaly},"#,##0")&" anomalies found"',
         f"{t_int(kv['anomaly'])} anomalies found", TEAL)
    card(5, False, 'AVG VISIT NUMBER', 'visit_avg', 'dec2', 'TEXT({k:first_visit},"0.0%")&" referred at 1st visit"',
         f"{t_pct(kv['first_visit'])} referred at 1st visit", TEAL)
    card(6, False, 'CRITICAL CASES', 'critical_rate', 'pct', 'TEXT({k:critical},"#,##0")&" emergency + unstable"',
         f"{t_int(kv['critical'])} emergency + unstable", CORAL)
    card(7, False, 'INCOMPLETE REFERRALS', 'incomplete_rate', 'pct', 'TEXT({k:incomplete},"#,##0")&" not completed"',
         f"{t_int(kv['incomplete'])} not completed", CORAL)

    # ---- charts -----------------------------------------------------------------------------------------------
    CH_ROW0, CH_BAND = 16, 14
    CH_W, CH_H = 426, 270
    FONT = 'Calibri'

    def style(ch, title, legend=None, width=CH_W):
        ch.set_title({'name': title, 'name_font': {'name': FONT, 'size': 11, 'bold': True, 'color': NAVY},
                      'overlay': False, 'layout': {'x': 0.02, 'y': 0.03}})
        ch.set_chartarea({'border': {'color': GREY_L, 'width': 0.75}, 'fill': {'color': WHITE}})
        ch.set_plotarea({'border': {'none': True}, 'fill': {'none': True}})
        if legend:
            ch.set_legend({'position': legend, 'font': {'name': FONT, 'size': 9, 'color': GREY_T}})
        else:
            ch.set_legend({'none': True})
        ch.set_size({'width': width, 'height': CH_H})

    AX_FONT = {'name': FONT, 'size': 9, 'color': GREY_T}
    LBL_NF = '#,##0;;'                                     # zero -> no label (unused slots / empty categories)
    LBL_FONT = {'name': FONT, 'size': 9, 'color': TXT}
    AX_LINE = {'color': GREY_L, 'width': 0.75}
    GRID = {'visible': True, 'line': {'color': GREY_LL, 'width': 0.75}}

    def place(ch, band, col):
        ws.insert_chart(CH_ROW0 + CH_BAND * band, col, ch, {'x_offset': 3, 'y_offset': 0, 'object_position': 2})

    def rg(r1, c1, r2, c2):
        return [C, r1, c1, r2, c2]

    def bar_ranked(title, key, n_show, color, band, col):
        rb = ranked[key]
        ch = wb.add_chart({'type': 'bar'})
        ch.add_series({'name': 'Referrals', 'categories': rg(rb['first'], 6, rb['first'] + n_show - 1, 6),
                       'values': rg(rb['first'], 7, rb['first'] + n_show - 1, 7),
                       'fill': {'color': color}, 'border': {'none': True}, 'gap': 45,
                       'data_labels': {'value': True, 'position': 'outside_end', 'font': LBL_FONT, 'num_format': LBL_NF}})
        style(ch, title)
        ch.set_y_axis({'reverse': True, 'num_font': AX_FONT, 'line': AX_LINE, 'major_tick_mark': 'none', 'interval_unit': 1})   # categories
        ch.set_x_axis({'visible': False, 'major_gridlines': {'visible': False}, 'min': 0})                                        # values
        place(ch, band, col)

    def stacked_status(title, key, n_show, kind, band, col, width=CH_W):
        rb = ranked[key]
        ch = wb.add_chart({'type': kind, 'subtype': 'stacked'})
        for s_i, s_ in enumerate(L.STATUS):
            ch.add_series({'name': [C, rb['first'] - 1, 8 + s_i],
                           'categories': rg(rb['first'], 6, rb['first'] + n_show - 1, 6),
                           'values': rg(rb['first'], 8 + s_i, rb['first'] + n_show - 1, 8 + s_i),
                           'fill': {'color': STATUS_COL[s_]}, 'border': {'color': WHITE, 'width': 0.5}, 'gap': 50})
        style(ch, title, legend='bottom', width=width)
        if kind == 'bar':
            ch.set_y_axis({'reverse': True, 'crossing': 'max', 'num_font': dict(AX_FONT, size=8), 'line': AX_LINE,
                           'major_tick_mark': 'none', 'interval_unit': 1})
            ch.set_x_axis({'num_font': AX_FONT, 'line': {'none': True}, 'major_gridlines': GRID, 'min': 0, 'num_format': '#,##0',
                           'major_tick_mark': 'none'})
        else:
            ch.set_x_axis({'num_font': AX_FONT, 'line': AX_LINE, 'major_tick_mark': 'none'})
            ch.set_y_axis({'num_font': AX_FONT, 'line': {'none': True}, 'major_gridlines': GRID, 'min': 0, 'num_format': '#,##0',
                           'major_tick_mark': 'none'})
        place(ch, band, col)

    def column_simple(title, r1, r2, cat_c, val_c, color, band, col, axis_title=None):
        ch = wb.add_chart({'type': 'column'})
        ch.add_series({'name': 'Referrals', 'categories': rg(r1, cat_c, r2, cat_c), 'values': rg(r1, val_c, r2, val_c),
                       'fill': {'color': color}, 'border': {'none': True}, 'gap': 55,
                       'data_labels': {'value': True, 'position': 'outside_end', 'font': LBL_FONT, 'num_format': LBL_NF}})
        style(ch, title)
        xa = {'num_font': AX_FONT, 'line': AX_LINE, 'major_tick_mark': 'none'}
        if axis_title:
            xa.update({'name': axis_title, 'name_font': {'name': FONT, 'size': 9, 'color': GREY_T, 'bold': False}})
        ch.set_x_axis(xa)
        ch.set_y_axis({'visible': False, 'major_gridlines': {'visible': False}, 'min': 0})
        place(ch, band, col)

    def stacked_two(title, r1, r2, cat_c, hdr_r, cols_colors, band, col):
        ch = wb.add_chart({'type': 'column', 'subtype': 'stacked'})
        for cc, color in cols_colors:
            ch.add_series({'name': [C, hdr_r, cc], 'categories': rg(r1, cat_c, r2, cat_c), 'values': rg(r1, cc, r2, cc),
                           'fill': {'color': color}, 'border': {'color': WHITE, 'width': 0.5}, 'gap': 70,
                           'data_labels': {'value': True, 'font': {'name': FONT, 'size': 9, 'color': WHITE, 'bold': True}, 'num_format': LBL_NF}})
        style(ch, title, legend='bottom')
        ch.set_x_axis({'num_font': AX_FONT, 'line': AX_LINE, 'major_tick_mark': 'none'})
        ch.set_y_axis({'num_font': AX_FONT, 'line': {'none': True}, 'major_gridlines': GRID, 'min': 0, 'num_format': '#,##0',
                       'major_tick_mark': 'none'})
        place(ch, band, col)

    # band 0: monthly trend (double width) + status doughnut
    col_ch = wb.add_chart({'type': 'column'})
    col_ch.add_series({'name': 'Referrals', 'categories': rg(MO0, MOC + 1, MO0 + N_MONTHS - 1, MOC + 1),
                       'values': rg(MO0, MOC + 2, MO0 + N_MONTHS - 1, MOC + 2), 'fill': {'color': TEAL}, 'border': {'none': True}, 'gap': 45})
    line_ch = wb.add_chart({'type': 'line'})
    line_ch.add_series({'name': 'Completion rate', 'categories': rg(MO0, MOC + 1, MO0 + N_MONTHS - 1, MOC + 1),
                        'values': rg(MO0, MOC + 4, MO0 + N_MONTHS - 1, MOC + 4), 'y2_axis': True,
                        'line': {'color': CORAL, 'width': 2.25},
                        'marker': {'type': 'circle', 'size': 5, 'fill': {'color': WHITE}, 'border': {'color': CORAL, 'width': 1.5}}})
    col_ch.combine(line_ch)
    style(col_ch, 'Monthly referrals and completion rate (last 24 months)', legend='bottom', width=2 * 432 - 6)
    col_ch.set_x_axis({'num_font': AX_FONT, 'line': AX_LINE, 'major_tick_mark': 'none'})
    col_ch.set_y_axis({'num_font': AX_FONT, 'line': {'none': True}, 'major_gridlines': GRID, 'min': 0, 'num_format': '#,##0',
                       'major_tick_mark': 'none'})
    line_ch.set_y2_axis({'num_font': AX_FONT, 'line': {'none': True}, 'min': 0, 'max': 1, 'major_unit': 0.2, 'num_format': '0%',
                         'major_tick_mark': 'none'})
    place(col_ch, 0, 1)

    dn = wb.add_chart({'type': 'doughnut'})
    dn.add_series({'name': 'Referral status', 'categories': rg(ST0, BC, ST0 + 2, BC), 'values': rg(ST0, BC + 1, ST0 + 2, BC + 1),
                   'points': [{'fill': {'color': STATUS_COL[s_]}, 'border': {'color': WHITE, 'width': 1.5}} for s_ in L.STATUS],
                   'data_labels': {'percentage': True, 'font': {'name': FONT, 'size': 10, 'color': WHITE, 'bold': True}, 'num_format': '0%;;'}})
    dn.set_hole_size(58)
    style(dn, 'Referral status', legend='bottom')
    place(dn, 0, 17)

    # band 1: reasons | pathway | shift x priority
    bar_ranked('Reasons of referral (top 10)', 'Reason', 10, TEAL, 1, 1)
    fu = wb.add_chart({'type': 'bar'})
    fu_cols = [NAVY, BLUE, TEAL, GREEN]
    fu.add_series({'name': 'Referrals', 'categories': rg(FU0, BC, FU0 + 3, BC), 'values': rg(FU0, BC + 1, FU0 + 3, BC + 1),
                   'points': [{'fill': {'color': c_}} for c_ in fu_cols], 'border': {'none': True}, 'gap': 40,
                   'data_labels': {'value': True, 'position': 'inside_end', 'font': {'name': FONT, 'size': 10, 'color': WHITE, 'bold': True},
                                   'num_format': LBL_NF}})
    style(fu, 'Referral pathway: from referral to completion')
    fu.set_y_axis({'reverse': True, 'num_font': AX_FONT, 'line': AX_LINE, 'major_tick_mark': 'none', 'interval_unit': 1})
    fu.set_x_axis({'visible': False, 'major_gridlines': {'visible': False}, 'min': 0})
    place(fu, 1, 9)
    stacked_two('Referral priority by shift', SH0, SH0 + 2, BC, 15, [(BC + 1, TEAL), (BC + 2, CORAL)], 1, 17)

    # band 2: facility by status | site by status | top staff
    stacked_status('Receiving facilities by referral status (top 12)', 'Facility', 12, 'bar', 2, 1)
    stacked_status('Sites by referral status', 'Site', 6, 'column', 2, 9)
    bar_ranked('Top 10 referring staff', 'Staff', 10, NAVY, 2, 17)

    # band 3: patient refusal reasons | facility refusal reasons | previous history
    bar_ranked('Why patients refuse the referral', 'RefusalReason', 8, CORAL, 3, 1)
    bar_ranked('Why facilities refuse the patient', 'HFReason', 6, AMBER, 3, 9)
    bar_ranked('Previous history', 'History', 8, PURPLE, 3, 17)

    # band 4: age | gestational age | condition by priority
    column_simple('Maternal age group', AG0, AG0 + 5, BC, BC + 1, BLUE, 4, 1, 'Age (years)')
    column_simple('Gestational age at referral', GA0, GA0 + 4, BC, BC + 1, TEAL, 4, 9)
    stacked_two('Condition on arrival by priority', CP0, CP0 + 1, BC, 21, [(BC + 1, SLATE), (BC + 2, CORAL)], 4, 17)

    # ---- scorecards ---------------------------------------------------------------------------------------------
    SC0 = CH_ROW0 + CH_BAND * 5                                      # first row after the charts
    f_sec = mk(bg_color=BG, font_color=NAVY, bold=True, font_size=12, indent=1, valign='bottom')
    f_tt = mk(bg_color=NAVY, font_color=WHITE, bold=True, font_size=10, indent=1)
    f_th = mk(bg_color=GREY_LL, font_color=GREY_T, bold=True, font_size=8.5, align='center', text_wrap=True, bottom=1, bottom_color=GREY_L)
    f_thl = mk(bg_color=GREY_LL, font_color=GREY_T, bold=True, font_size=8.5, indent=1, bottom=1, bottom_color=GREY_L)
    f_tn = mk(bg_color=BG, font_color=BG, indent=1, shrink=True)                       # invisible until the row has a label
    f_tv = mk(bg_color=BG, font_color=BG, align='center', num_format='#,##0')
    f_tp = mk(bg_color=BG, font_color=BG, align='center', num_format='0.0%')
    f_on = wb.add_format({'bg_color': WHITE, 'font_color': TXT, 'bottom': 1, 'bottom_color': GREY_LL})
    ws.set_row_pixels(SC0, 26)
    ws.merge_range(SC0, 1, SC0, LAST_COL, 'SCORECARDS  -  how each site, facility, shift, staff member and referral reason performs (ranked by referrals)', f_sec)

    METRICS = {
        'n': ('Referrals', []),
        'emerg': ('Emergency %', [(PRI, '=', 'Emergency')]),
        'unstable': ('Unstable %', [(COND, '=', 'Unstable')]),
        'accept': ('Patient acceptance %', [(ACC, '=', 'Yes')]),
        'hfref': ('HF refusal %', [(HFR, '=', 'Yes')]),
        'complete': ('Completion %', [(STAT, '=', 'Completed')]),
    }

    def scorecard(title, top_row, c0, dim_col, labels, label_refs, metrics, name_cols, n_rows):
        """labels: python labels in display order; label_refs: formulas returning the label for each row (or None for static)."""
        width = name_cols + 2 * len(metrics)
        ws.merge_range(top_row, c0, top_row, c0 + width - 1, title, f_tt)
        ws.merge_range(top_row + 1, c0, top_row + 1, c0 + name_cols - 1, dim_col if dim_col != STAFF else 'Staff member', f_thl)
        for mi, mkey in enumerate(metrics):
            cc = c0 + name_cols + 2 * mi
            ws.merge_range(top_row + 1, cc, top_row + 1, cc + 1, METRICS[mkey][0], f_th)
        first = top_row + 2
        for i in range(n_rows):
            r = first + i
            lab = labels[i] if i < len(labels) else ''
            ws.merge_range(r, c0, r, c0 + name_cols - 1, '', f_tn)
            if label_refs is None:
                ws.write_string(r, c0, lab, f_tn)
            else:
                F(D, r, c0, label_refs[i], lab, f_tn)
            lc = a1(r, c0)
            lcr = f'${xl_col_to_name(c0)}{r + 1}'
            n_cell = a1(r, c0 + name_cols)
            base = [(dim_col, '=', lab)]
            nval = cnt_of(base) if lab else ''
            for mi, mkey in enumerate(metrics):
                cc = c0 + name_cols + 2 * mi
                conds = METRICS[mkey][1]
                crit = ''.join(f',{xcol(cn)},"{cv}"' for cn, _, cv in conds)
                if mkey == 'n':
                    ws.merge_range(r, cc, r, cc + 1, '', f_tv)
                    F(D, r, cc, f'IF({lc}="","",COUNTIFS({XFLAG},1,{xcol(dim_col)},{lc}))', nval, f_tv)
                else:
                    if mkey == 'hfref':
                        den_f = f'COUNTIFS({XFLAG},1,{xcol(dim_col)},{lc},{xcol(ACC)},"Yes")'
                        den_v = cnt_of(base + [(ACC, '=', 'Yes')]) if lab else 0
                    else:
                        den_f, den_v = n_cell, (nval if lab else 0)
                    if lab:
                        num_v = cnt_of(base + conds)
                        val = (num_v / den_v) if den_v else UND
                    else:
                        val = ''
                    ws.merge_range(r, cc, r, cc + 1, '', f_tp)
                    F(D, r, cc, f'IF({lc}="","",IFERROR(COUNTIFS({XFLAG},1,{xcol(dim_col)},{lc}{crit})/{den_f},"{UND}"))', val, f_tp)
        last = first + n_rows - 1
        # rows become visible only when they have a label
        ws.conditional_format(first, c0, last, c0 + width - 1,
                              {'type': 'formula', 'criteria': f'=${xl_col_to_name(c0)}{first + 1}<>""', 'format': f_on})
        for mi, mkey in enumerate(metrics):
            cc = c0 + name_cols + 2 * mi
            if mkey == 'n':
                ws.conditional_format(first, cc, last, cc + 1, {'type': 'data_bar', 'bar_color': '#9ED9D0', 'bar_solid': True,
                                                                'min_type': 'num', 'min_value': 0})
            elif mkey in ('accept', 'complete'):
                ws.conditional_format(first, cc, last, cc + 1, {'type': '3_color_scale', 'min_color': '#F8C9BC', 'mid_color': '#FFFFFF',
                                                                'max_color': '#BFE5D2'})
            else:
                ws.conditional_format(first, cc, last, cc + 1, {'type': '2_color_scale', 'min_color': '#FFFFFF', 'max_color': '#F8C9BC'})
        return first, last

    def ranked_labels(key, n_rows):
        rb = ranked[key]
        labs = [rb['values'][i] if rb['counts'][i] > 0 else '' for i in rb['order']][:n_rows]
        refs = ['=' + ref(C, rb['first'] + i, 6) for i in range(n_rows)]
        return labs, refs

    T1 = SC0 + 1
    labs, refs = ranked_labels('Site', 6)
    scorecard('Sites', T1, 1, SITE, labs, refs, ['n', 'emerg', 'accept', 'hfref', 'complete'], 2, 6)
    scorecard('Shifts', T1 + 9, 1, SHIFT, L.SHIFTS, None, ['n', 'emerg', 'accept', 'hfref', 'complete'], 2, 3)
    labs, refs = ranked_labels('Facility', 12)
    scorecard('Receiving facilities', T1, 13, FAC, labs, refs, ['n', 'emerg', 'accept', 'hfref', 'complete'], 2, 12)
    T2 = T1 + 15
    labs, refs = ranked_labels('Staff', 16)
    scorecard('Referring staff', T2, 1, STAFF, labs, refs, ['n', 'emerg', 'accept', 'hfref', 'complete'], 2, 16)
    labs, refs = ranked_labels('Reason', 12)
    scorecard('Reasons of referral', T2, 13, REAS, labs, refs, ['n', 'emerg', 'accept', 'complete'], 4, 12)
    END_ROW = T2 + 2 + 16
    f_foot = mk(bg_color=BG, font_color=GREY_T, font_size=9, italic=True, indent=1)
    ws.merge_range(END_ROW + 1, 1, END_ROW + 1, LAST_COL,
                   'Demonstration data: all records are synthetic (no real patients). Replace the rows on the "Raw Data" sheet with your register '
                   'and the dashboard recalculates. Definitions of every indicator: sheet "KPIs".', f_foot)
    ws.freeze_panes(8, 0)
    ws.set_landscape()
    ws.set_paper(8)                                   # A3 landscape, 100 %: 3 pages (2 chart rows | 3 chart rows | scorecards)
    ws.print_area(0, 0, END_ROW + 1, 25)
    ws.set_print_scale(100)
    ws.repeat_rows(0, 7)                              # banner + filter panel on every printed page
    ws.set_h_pagebreaks([CH_ROW0 + 2 * CH_BAND, SC0])
    ws.center_horizontally()
    ws.set_margins(0.3, 0.3, 0.4, 0.4)
    ws.ignore_errors({'formula_differs': 'A1:Z140', 'formula_range': 'A1:Z140'})

    # ===========================================================================================================
    # 8. READ ME
    # ===========================================================================================================
    ws = S['Read Me']
    ws.hide_gridlines(2)
    ws.set_tab_color('#9AA5B1')
    ws.set_column(0, 0, 2)
    ws.set_column(1, 1, 30)
    ws.set_column(2, 2, 118)
    f_rt = mk(font_size=18, bold=True, font_color=NAVY)
    f_rs = mk(font_size=10, font_color=GREY_T)
    f_rh = mk(bold=True, font_size=11, font_color=WHITE, bg_color=NAVY, indent=1)
    f_rk = mk(bold=True, valign='top', text_wrap=True, border=1, border_color=GREY_L, bg_color=GREY_LL, indent=1)
    f_rv = mk(valign='top', text_wrap=True, border=1, border_color=GREY_L, indent=1)
    ws.set_row(0, 30)
    ws.write(0, 1, 'Maternal Referral Tracker - dashboard, data and KPI pack', f_rt)
    ws.write(1, 1, f'Built {dt.date(2026, 11, 10).strftime("%d %b %Y")}  |  {t_int(n_all)} synthetic referral records  |  {len(K)} KPIs  |  '
                   'no macros - works in Excel 2010 and later', f_rs)
    r = 3

    def section(title, rows):
        nonlocal r
        ws.merge_range(r, 1, r, 2, title, f_rh)
        ws.set_row(r, 20)
        r += 1
        for kq, vq in rows:
            ws.write_string(r, 1, kq, f_rk)
            ws.write_string(r, 2, vq, f_rv)
            ws.set_row(r, max(16, 13.5 * max(math.ceil(len(vq) / 128), math.ceil(len(kq) / 30))) + 4)
            r += 1
        r += 1

    section('1. SHEETS', [
        ('Dashboard', 'Interactive overview: 16 filters, 16 KPI cards, 14 charts and 5 scorecards. Everything is formula-driven and reacts to the filters.'),
        ('Raw Data', f'The register: {t_int(n_all)} referral records in the 22 columns of your template (Excel table "tblReferrals"). Dropdown columns are validated '
                     'against the Filter Data lists. The last column "In Filter" is a helper (1 = the row matches the Dashboard filters).'),
        ('Filter Data', 'The dropdown lists from your template (image 2). They feed the data-entry dropdowns and the Dashboard filters.'),
        ('KPIs', f'{len(K)} KPIs: definition, live value (follows the Dashboard filters), DAX measure and Power Query (M) expression.'),
        ('Power Query M', 'Three ready-to-paste M queries: Referrals (loads and cleans the register), Calendar (date table), KPI_Summary (all KPIs in M).'),
        ('DAX Measures', 'All measures in one DEFINE MEASURE script for the Power BI DAX query view.'),
        ('Calc', 'Calculation engine behind the Dashboard (filter values, ranked lists, monthly trend, list check). No need to edit.'),
    ])
    section('2. USING THE DASHBOARD', [
        ('Filter', "Click a white box in the FILTERS panel and pick a value from its dropdown. 'All' (or an empty box) means no filter. Active filters turn yellow; "
                   'the dark banner shows how many records are in view.'),
        ('Reset', "Set the yellow boxes back to 'All' and clear the two date boxes."),
        ('See the records', "On 'Raw Data', filter the column 'In Filter' on 1 to list exactly the records behind the current dashboard numbers."),
        ('Dates', "'Visit Date From / To' filter on Date of visit. The trend chart always shows the last 24 months found in the register."),
        ('Ranked charts', 'Bars are sorted by volume and show the top entries: 10 reasons, 12 facilities, 10 staff, 6 sites, 8 refusal reasons, 6 facility-refusal reasons, '
                          '8 histories. The scorecards at the bottom list up to 16 staff, 12 facilities, 12 reasons and 6 sites.'),
        ('Printing', 'The Dashboard is set up for A3 landscape on three pages; the title and filter panel repeat on every page.'),
    ])
    section('3. ADDING OR REPLACING DATA', [
        ('New records', "Type or paste below the last row of 'Raw Data' - the table grows automatically and formulas, dropdowns and the dashboard follow. "
                        'To load your own register, paste your rows over the sample rows in the 22 columns (keep the header row) and delete any sample rows left over.'),
        ('What counts as a record', 'A row is counted when it has a Patient ID. Rows without one (for example cleared rows) are ignored everywhere.'),
        ('New dropdown option', "Add it in the first empty cell of the list on 'Filter Data' (e.g. a new site or facility). Data-entry dropdowns, dashboard filters, "
                                'rankings and scorecards pick it up automatically.'),
        ('CHECK DATA message', "If pasted data contains a value that is not in the 'Filter Data' lists (e.g. a new staff name), a red CHECK DATA message appears under "
                               f"the Dashboard banner and sheet 'Calc' (rows {LC0 + 1}-{LC0 + len(LISTS)}) shows which column is affected. Add the value to the list and the message disappears."),
        ('Blank cells', f'Averages ignore blank ages, weeks and dates. KPIs {K[-3].no}-{K[-1].no} (Data Quality) count date errors, refusals without a reason and records with '
                        'missing key fields - all three should be 0.'),
        ('Business rules in the sample', 'Referral Accepted = No  ->  Reason for refusal is filled, Refusal from HF = No, Referral Status = Incomplete.   '
                                         'Refusal from HF = Yes  ->  Reason of facility refusal is filled and the status is never Completed.   '
                                         'A patient can appear on several rows (one row per referral visit) - Patient ID identifies the woman.'),
    ])
    section('4. USING THE DAX AND M IN POWER BI', [
        ('Step 1 - load the data', "Power BI Desktop > Home > Get data > Excel workbook > choose this file > in the Navigator tick tblReferrals > Transform Data > "
                                   "rename the query to Referrals (Query Settings > Name) > Close & Apply.   Alternative that also cleans the data: paste query 1 "
                                   "from 'Power Query M' into a Blank Query (Advanced Editor) and set FilePath."),
        ('Step 2 - add measures', "DAX query view > paste the script from 'DAX Measures' > Update model with changes. Or paste single measures from column G of 'KPIs' "
                                  'into Modeling > New measure.'),
        ('Step 3 - formats', "Rates are returned as ratios (0.638 = 63.8%): set the Percentage format for the '%' measures (column F of 'KPIs')."),
        ('KPIs in M', "Query 3 (KPI_Summary) on 'Power Query M' returns every KPI as one table (No, Category, KPI, Value, Display, Format); column H of 'KPIs' has "
                      'one stand-alone M expression per KPI. M is calculated when the data is refreshed, so these values cover the whole register and do not '
                      'react to slicers - the DAX measures do.'),
        ('Slicers', 'The measures use KEEPFILTERS, so a slicer on the same column is respected (slicing Priority = Routine makes the Emergency measures blank instead of '
                    'showing the overall emergency count).'),
        ('Cross-check', 'The DAX measures and M expressions follow the same definitions as the live values on the KPIs sheet, so with no Dashboard filter set the '
                        'numbers should match - a quick way to check your Power BI model.'),
    ])
    section('5. NOTES AND ASSUMPTIONS', [
        ('Synthetic data', 'All names, IDs and records are randomly generated for demonstration - they are not real patients. The first row reproduces the sample '
                           'row of the template (AB-1234, Jasmeen, Bahadur, 25, Ali Akber Shah). Visit dates run from 01 Nov 2024 to 31 Oct 2026.'),
        ('Sites', 'The template showed one site (Ali Akber Shah). Three illustrative Karachi sites were added so that sites can be compared: '
                  "Ibrahim Hyderi, Rehri Goth, Bhains Colony. Edit the Site list on 'Filter Data' to match your programme."),
        ("Placeholder 'a'", "The 'a' entries in the template lists were treated as empty slots for future options and are not used as values."),
        ('Spelling normalised (headers)', 'Referral Prioroty -> Referral Priority   |   Previous hsitory -> Previous history   |   '
                                          'Refferal Shif -> Referral Shift   |   Referal Status -> Referral Status'),
        ('Spelling normalised (values)', 'PPH-Post Partum Hamerage -> PPH-Post Partum Hemorrhage   |   Preeclampcia -> Preeclampsia   |   Eclampcia -> Eclampsia   |   '
                                         'Financial Constrain -> Financial Constraint   |   staff names capitalised (Sumaira, Ambreen, Naheed, Shelina). '
                                         'The Referrals M query also accepts the original spellings of these headers and values.'),
        ('Bands used', 'Trimester: 1st = up to 13 weeks, 2nd = 14-27 weeks, 3rd = 28 weeks or more. Teenage = under 20 years. Advanced maternal age = 35 years or more.'),
        ('HF refusal rate', 'Calculated on referrals the patient accepted (only those can be refused by a facility).'),
    ])

    for name_ in ('Filter Data', 'Power Query M', 'DAX Measures', 'Calc', 'Read Me'):
        S[name_].set_landscape()
        S[name_].set_paper(9)
        S[name_].fit_to_pages(1, 0)
    S['Dashboard'].activate()
    S['Dashboard'].set_first_sheet()
    wb.close()
    info = dict(n=n, in_view=ctx.n, kpis=K, kvals=kvals, krow=krow, m_ranges=m_ranges, dax_range=(dax_first, dax_last),
                m_blocks=m_blocks, dax_lines=dax_lines, end_row=END_ROW, dax_unformatted=[k.name for k in K if k.key not in formatted_dax])
    if not quiet:
        print(f'written {out_path}  ({os.path.getsize(out_path) / 1024:.0f} KB)  rows={n} in_view={ctx.n} kpis={len(K)} formulas={len(expected)}')
    return expected, info


if __name__ == '__main__':
    build()
