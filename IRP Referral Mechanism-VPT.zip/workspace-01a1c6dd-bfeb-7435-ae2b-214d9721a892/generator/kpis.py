"""
KPI catalogue for the maternal-referral workbook.

Every KPI is declared once and rendered four ways from the same definition:
  * xl   - live Excel formula (responds to the Dashboard filters through the 'In Filter' helper column)
  * py   - Python value (used as the cached result stored in the workbook and for verification)
  * dax  - DAX measure expression (table name: Referrals)
  * m    - Power Query (M) expression returning the same scalar (query name: Referrals)
"""
import datetime as _dt
import re
import statistics

TBL = 'tblReferrals'          # Excel table name
FLAG = 'In Filter'            # helper column (1 = row passes the Dashboard filters)
DT = 'Referrals'              # DAX table / Power Query query name
UND = '\u2013'                # shown when a KPI is undefined (e.g. division by zero)

# column names (exactly as in the Raw Data header row)
PID, PNAME, HNAME, AGE, SITE = 'Patient ID', 'Patient Name', 'Husband Name', 'Age', 'Site'
ENR, GA, ANOM, VIS, NVIS = 'Date of Enrollment', 'Gestational Age (wks)', 'Any anomaly in scan', 'Date of visit', 'Number of visit'
PRI, HIST, COND, REAS, SHIFT = 'Referral Priority', 'Previous history', 'Condition on Arrival', 'Reason of Referral', 'Referral Shift'
STAFF, FAC, ACC, RREF = 'Referred by staff name', 'Referred facility', 'Referral Accepted', 'Reason for refusal'
HFR, HFREAS, STAT = 'Refusal from HF', 'Reason of facility refusal', 'Referral Status'


EPOCH = _dt.date(1899, 12, 30)   # Excel serial 0


def to_serial(x):
    """date -> Excel serial number (NaN when the date is missing)."""
    return float((x - EPOCH).days) if isinstance(x, _dt.date) else float('nan')


def from_serial(s):
    return EPOCH + _dt.timedelta(days=int(s))


def ym_of(s):
    d = from_serial(s)
    return d.year * 12 + d.month


# ----------------------------------------------------------------------------------------------------------------
# reference helpers
# ----------------------------------------------------------------------------------------------------------------
def xcol(c):
    """Excel structured reference to a whole table column."""
    return f'{TBL}[{c}]' if re.fullmatch(r'[A-Za-z0-9 ]+', c) else f'{TBL}[[{c}]]'


def xrow(c):
    """Excel structured reference to the current row of a table column (file-format spelling of [@col])."""
    return f'{TBL}[[#This Row],[{c}]]'


XFLAG = xcol(FLAG)


def dcol(c):
    return f'{DT}[{c}]'


def mfield(c):
    """M field access; quoted identifier when the name is not a plain generalized identifier."""
    if re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*( [A-Za-z_][A-Za-z0-9_]*)*', c):
        return f'[{c}]'
    return f'[#"{c}"]'


def lit(v):
    if isinstance(v, str):
        return '"' + v.replace('"', '""') + '"'
    return str(v)


# ----------------------------------------------------------------------------------------------------------------
# condition DSL:  (column, operator, value)   operator in  = < <= > >= in
# ----------------------------------------------------------------------------------------------------------------
def py_mask(d, conds):
    m = None
    for col, op, val in conds:
        s = d[col]
        if op == '=':
            x = s == val
        elif op == '<':
            x = s < val
        elif op == '<=':
            x = s <= val
        elif op == '>':
            x = s > val
        elif op == '>=':
            x = s >= val
        elif op == 'in':
            x = s.isin(val)
        else:
            raise ValueError(op)
        m = x if m is None else (m & x)
    return m


def py_count(d, conds):
    if not conds:
        return int(len(d))
    return int(py_mask(d, conds).sum())


def xl_count(conds):
    """COUNTIFS over the rows that pass the dashboard filters."""
    if not conds:
        return 'c_Total'
    parts = [f'{XFLAG},1']
    n_in = 0
    for col, op, val in conds:
        if op == 'in':
            n_in += 1
            parts.append(f'{xcol(col)},{{' + ','.join(lit(v) for v in val) + '}')
        elif op == '=':
            parts.append(f'{xcol(col)},{lit(val)}')
        else:
            parts.append(f'{xcol(col)},"{op}{val}"')
    assert n_in <= 1, 'only one IN condition per count'
    f = 'COUNTIFS(' + ','.join(parts) + ')'
    return f'SUMPRODUCT({f})' if n_in else f


def dax_cond(c):
    col, op, val = c
    if op == 'in':
        return f'{dcol(col)} IN {{ ' + ', '.join(lit(v) for v in val) + ' }'
    if op in ('<', '<='):                              # DAX treats BLANK as 0 in comparisons -> exclude blanks explicitly
        return f'{dcol(col)} {op} {lit(val)} && NOT ISBLANK ( {dcol(col)} )'
    return f'{dcol(col)} {op} {lit(val)}'


def dax_count(conds):
    if not conds:
        return f'COUNTROWS ( {DT} )'
    return f'CALCULATE ( COUNTROWS ( {DT} ), ' + ', '.join(f'KEEPFILTERS ( {dax_cond(c)} )' for c in conds) + ' )'


def m_cond(c):
    col, op, val = c
    if op == 'in':
        return 'List.Contains({' + ', '.join(lit(v) for v in val) + '}, ' + mfield(col) + ')'
    if op == '=':
        return f'{mfield(col)} = {lit(val)}'
    return f'({mfield(col)} <> null and {mfield(col)} {op} {lit(val)})'   # null-safe: a null comparison would not be a logical


def m_pred(conds):
    return 'each ' + ' and '.join(m_cond(c) for c in conds)


def m_count(conds, src='Source'):
    if not conds:
        return f'Table.RowCount({src})'
    return f'Table.RowCount(Table.SelectRows({src}, {m_pred(conds)}))'


def m_count_inline(conds):
    return 'Total' if not conds else f'CountIf({m_pred(conds)})'


# ----------------------------------------------------------------------------------------------------------------
# KPI object + constructors
# ----------------------------------------------------------------------------------------------------------------
class KPI:
    def __init__(self, key, cat, name, desc, fmt, xl, py, dax, m, m_inline, array=False):
        self.key, self.cat, self.name, self.desc, self.fmt = key, cat, name, desc, fmt
        self.xl, self.py, self.dax, self.m, self.m_inline, self.array = xl, py, dax, m, m_inline, array
        self.no = None

    @property
    def is_text(self):
        return self.fmt == 'text'


KPIS = []


def _add(k):
    assert all(k.key != o.key for o in KPIS), k.key
    assert all(k.name != o.name for o in KPIS), k.name
    k.no = len(KPIS) + 1
    KPIS.append(k)
    return k


def k_count(key, cat, name, desc, conds):
    return _add(KPI(key, cat, name, desc, 'int',
                    xl='=' + xl_count(conds),
                    py=lambda c, v, conds=conds: py_count(c.d, conds),
                    dax=dax_count(conds),
                    m=f'let Source = {DT}, Result = {m_count(conds)} in Result',
                    m_inline=m_count_inline(conds)))


def k_ratio(key, cat, name, desc, num, den):
    def py(c, v, num=num, den=den):
        dn = py_count(c.d, den)
        return py_count(c.d, num) / dn if dn else UND
    return _add(KPI(key, cat, name, desc, 'pct',
                    xl=f'=IFERROR({xl_count(num)}/{xl_count(den)},"{UND}")',
                    py=py,
                    dax=f'DIVIDE ( {dax_count(num)}, {dax_count(den)} )',
                    m=(f'let Source = {DT}, Num = {m_count(num)}, Den = {m_count(den)}, '
                       f'Result = if Den = 0 then null else Num / Den in Result'),
                    m_inline=f'Ratio({m_count_inline(num)}, {m_count_inline(den)})'))


def k_avg(key, cat, name, desc, col, fmt='dec1'):
    def py(c, v, col=col):
        s = c.d[col].dropna()
        return float(s.astype(float).mean()) if len(s) else UND
    return _add(KPI(key, cat, name, desc, fmt,
                    xl=f'=IFERROR(AVERAGEIFS({xcol(col)},{XFLAG},1),"{UND}")',
                    py=py,
                    dax=f'AVERAGE ( {dcol(col)} )',
                    m=f'let Source = {DT}, Result = List.Average(List.RemoveNulls(Source{mfield(col)})) in Result',
                    m_inline=f'List.Average(Values("{col}"))'))


def k_distinct(key, cat, name, desc, col):
    """Exact distinct count of a column over the rows in view (blank cells are ignored)."""
    def py(c, v, col=col):
        return int(c.d[col].nunique())
    x = xcol(col)
    xl = (f'=ROUND(SUMPRODUCT(({XFLAG}=1)*({x}<>"")/(COUNTIFS({x},{x},{XFLAG},1)+({XFLAG}<>1)+({x}=""))),0)')
    return _add(KPI(key, cat, name, desc, 'int', xl=xl, py=py,
                    dax=f'DISTINCTCOUNTNOBLANK ( {dcol(col)} )',
                    m=f'let Source = {DT}, Result = List.Count(List.Distinct(List.RemoveNulls(Source{mfield(col)}))) in Result',
                    m_inline=f'DistinctCount("{col}")'))


def k_active(key, cat, name, desc, col, named_cell, list_values):
    """Number of dropdown-list values with at least one record in view (cheap: read from the ranked block on Calc)."""
    def py(c, v, col=col, list_values=list_values):
        counts = c.d[col].value_counts()
        return int(sum(1 for item in list_values if int(counts.get(item, 0)) > 0))
    return _add(KPI(key, cat, name, desc, 'int', xl=f'={named_cell}', py=py,
                    dax=f'DISTINCTCOUNTNOBLANK ( {dcol(col)} )',
                    m=f'let Source = {DT}, Result = List.Count(List.Distinct(List.RemoveNulls(Source{mfield(col)}))) in Result',
                    m_inline=f'DistinctCount("{col}")'))


def k_top(key, cat, name, desc, col, named_cell, list_order):
    """Most frequent value of a column (text KPI). Excel value comes from the ranked block on the Calc sheet."""
    def py(c, v, col=col, list_order=list_order):
        counts = c.d[col].value_counts()
        best, best_n = None, 0
        for item in list_order:                      # ties -> first in list order (same rule as the Excel ranking)
            n = int(counts.get(item, 0))
            if n > best_n:
                best, best_n = item, n
        return best if best else UND
    dax = (f'VAR _t = ADDCOLUMNS ( FILTER ( VALUES ( {dcol(col)} ), NOT ISBLANK ( {dcol(col)} ) ), "@Referrals", CALCULATE ( COUNTROWS ( {DT} ) ) ) '
           f'RETURN CONCATENATEX ( TOPN ( 1, _t, [@Referrals], DESC ), {dcol(col)}, ", ", {dcol(col)}, ASC )')
    m = (f'let Source = Table.SelectRows({DT}, each {mfield(col)} <> null and {mfield(col)} <> ""), '
         f'Grouped = Table.Group(Source, {{"{col}"}}, {{{{"Referrals", each Table.RowCount(_), Int64.Type}}}}), '
         f'Sorted = Table.Sort(Grouped, {{{{"Referrals", Order.Descending}}, {{"{col}", Order.Ascending}}}}), '
         f'Result = if Table.IsEmpty(Sorted) then null else Sorted{{0}}{mfield(col)} in Result')
    return _add(KPI(key, cat, name, desc, 'text', xl=f'={named_cell}', py=py, dax=dax, m=m,
                    m_inline=f'TopValue("{col}")'))


def k_custom(key, cat, name, desc, fmt, xl, py, dax, m, m_inline=None, array=False):
    return _add(KPI(key, cat, name, desc, fmt, xl, py, dax, m, m_inline or f'({m})', array))


def build_kpis(L):
    """L = module with the dropdown lists (gen_data). Returns the ordered KPI list."""
    KPIS.clear()
    T = []                                             # total (no conditions)
    E, R = [(PRI, '=', 'Emergency')], [(PRI, '=', 'Routine')]
    U = [(COND, '=', 'Unstable')]
    Y, N = [(ACC, '=', 'Yes')], [(ACC, '=', 'No')]
    HF = [(HFR, '=', 'Yes')]
    DONE = [(STAT, '=', 'Completed')]
    PPH = 'PPH-Post Partum Hemorrhage'

    # ------------------------------------------------------------------ A. Volume & Reach
    c = 'Volume & Reach'
    k_count('total', c, 'Total Referrals', 'Number of referral records (one row = one referral visit).', T)
    k_distinct('unique', c, 'Unique Patients', 'Distinct Patient IDs referred at least once.', PID)
    k_custom('per_patient', c, 'Avg Referrals per Patient', 'Total Referrals \u00f7 Unique Patients. Above 1.0 means some women were referred more than once.', 'dec2',
             xl=f'=IFERROR({{k:total}}/{{k:unique}},"{UND}")',
             py=lambda c, v: v['total'] / v['unique'] if v['unique'] else UND,
             dax=f'DIVIDE ( COUNTROWS ( {DT} ), DISTINCTCOUNTNOBLANK ( {dcol(PID)} ) )',
             m=(f'let Source = {DT}, Patients = List.Count(List.Distinct(List.RemoveNulls(Source[Patient ID]))), '
                f'Result = if Patients = 0 then null else Table.RowCount(Source) / Patients in Result'),
             m_inline='Ratio(Total, DistinctCount("Patient ID"))')
    k_active('sites', c, 'Active Sites', 'Number of sites with at least one referral.', SITE, 'c_ActiveSites', L.SITES)
    k_active('staff', c, 'Active Referring Staff', 'Number of staff members who made at least one referral.', STAFF, 'c_ActiveStaff', L.STAFF)
    k_active('facilities', c, 'Receiving Facilities Used', 'Number of different health facilities patients were referred to.', FAC, 'c_ActiveFacilities', L.FACILITIES)
    def py_per_month(c, v):
        s = c.vis.dropna()
        if s.empty:
            return UND
        a, b = from_serial(s.min()), from_serial(s.max())
        return c.n / ((b.year - a.year) * 12 + b.month - a.month + 1)
    k_custom('per_month', c, 'Avg Referrals per Month', 'Total Referrals \u00f7 number of calendar months between the first and the last visit date (inclusive).', 'dec1',
             xl=(f'=IF(c_MinDate="","{UND}",c_Total/((YEAR(c_MaxDate)-YEAR(c_MinDate))*12+MONTH(c_MaxDate)-MONTH(c_MinDate)+1))'),
             py=py_per_month,
             dax=(f'VAR _first = MIN ( {dcol(VIS)} ) VAR _last = MAX ( {dcol(VIS)} ) VAR _months = DATEDIFF ( _first, _last, MONTH ) + 1 '
                  f'RETURN IF ( NOT ISBLANK ( _first ), DIVIDE ( COUNTROWS ( {DT} ), _months ) )'),
             m=(f'let Source = {DT}, Dates = List.RemoveNulls(Source[Date of visit]), First = List.Min(Dates), Last = List.Max(Dates), '
                f'Months = (Date.Year(Last) - Date.Year(First)) * 12 + Date.Month(Last) - Date.Month(First) + 1, '
                f'Result = if List.IsEmpty(Dates) then null else Table.RowCount(Source) / Months in Result'),
             m_inline=('let Dates = Values("Date of visit"), First = List.Min(Dates), Last = List.Max(Dates), '
                       'Months = (Date.Year(Last) - Date.Year(First)) * 12 + Date.Month(Last) - Date.Month(First) + 1 '
                       'in if List.IsEmpty(Dates) then null else Total / Months'))
    k_custom('per_staff', c, 'Avg Referrals per Staff Member', 'Total Referrals \u00f7 Active Referring Staff (workload indicator).', 'dec1',
             xl=f'=IFERROR({{k:total}}/{{k:staff}},"{UND}")',
             py=lambda c, v: v['total'] / v['staff'] if v['staff'] else UND,
             dax=f'DIVIDE ( COUNTROWS ( {DT} ), DISTINCTCOUNTNOBLANK ( {dcol(STAFF)} ) )',
             m=(f'let Source = {DT}, Staff = List.Count(List.Distinct(List.RemoveNulls(Source[Referred by staff name]))), '
                f'Result = if Staff = 0 then null else Table.RowCount(Source) / Staff in Result'),
             m_inline='Ratio(Total, DistinctCount("Referred by staff name"))')

    def py_latest(c, v):
        s = c.vis.dropna()
        if s.empty:
            return UND
        return int((s.map(ym_of) == ym_of(s.max())).sum())

    def py_prev(c):
        s = c.vis.dropna()
        return int((s.map(ym_of) == ym_of(s.max()) - 1).sum())

    k_custom('latest', c, 'Referrals in Latest Month', 'Referrals whose visit date falls in the calendar month of the most recent visit in the data.', 'int',
             xl=(f'=IF(c_LastMonthStart="","{UND}",COUNTIFS({XFLAG},1,{xcol(VIS)},">="&c_LastMonthStart,{xcol(VIS)},"<="&EOMONTH(c_LastMonthStart,0)))'),
             py=py_latest,
             dax=(f'VAR _last = MAX ( {dcol(VIS)} ) VAR _from = DATE ( YEAR ( _last ), MONTH ( _last ), 1 ) VAR _to = EOMONTH ( _last, 0 ) '
                  f'RETURN IF ( NOT ISBLANK ( _last ), CALCULATE ( COUNTROWS ( {DT} ), KEEPFILTERS ( {dcol(VIS)} >= _from && {dcol(VIS)} <= _to ) ) )'),
             m=(f'let Source = {DT}, Last = List.Max(List.RemoveNulls(Source[Date of visit])), '
                f'Result = if Last = null then null else Table.RowCount(Table.SelectRows(Source, each [Date of visit] <> null '
                f'and [Date of visit] >= Date.StartOfMonth(Last) and [Date of visit] <= Date.EndOfMonth(Last))) in Result'),
             m_inline=('let Last = List.Max(Values("Date of visit")) in if Last = null then null else '
                       'CountIf(each [Date of visit] <> null and [Date of visit] >= Date.StartOfMonth(Last) and [Date of visit] <= Date.EndOfMonth(Last))'))

    def py_mom(c, v):
        if isinstance(v['latest'], str):
            return UND
        prev = py_prev(c)
        return (v['latest'] - prev) / prev if prev else UND

    k_custom('mom', c, 'Month-over-Month Growth %', '(Referrals in latest month \u2212 referrals in the month before) \u00f7 referrals in the month before.', 'pct',
             xl=(f'=IFERROR(({{k:latest}}-COUNTIFS({XFLAG},1,{xcol(VIS)},">="&EDATE(c_LastMonthStart,-1),{xcol(VIS)},"<"&c_LastMonthStart))'
                 f'/COUNTIFS({XFLAG},1,{xcol(VIS)},">="&EDATE(c_LastMonthStart,-1),{xcol(VIS)},"<"&c_LastMonthStart),"{UND}")'),
             py=py_mom,
             dax=(f'VAR _last = MAX ( {dcol(VIS)} ) VAR _curFrom = DATE ( YEAR ( _last ), MONTH ( _last ), 1 ) VAR _curTo = EOMONTH ( _last, 0 ) '
                  f'VAR _prevFrom = EDATE ( _curFrom, -1 ) VAR _prevTo = EOMONTH ( _last, -1 ) '
                  f'VAR _cur = CALCULATE ( COUNTROWS ( {DT} ), KEEPFILTERS ( {dcol(VIS)} >= _curFrom && {dcol(VIS)} <= _curTo ) ) '
                  f'VAR _prev = CALCULATE ( COUNTROWS ( {DT} ), KEEPFILTERS ( {dcol(VIS)} >= _prevFrom && {dcol(VIS)} <= _prevTo ) ) '
                  f'RETURN IF ( NOT ISBLANK ( _last ), DIVIDE ( _cur - _prev, _prev ) )'),
             m=(f'let Source = {DT}, Last = List.Max(List.RemoveNulls(Source[Date of visit])), CurStart = Date.StartOfMonth(Last), PrevStart = Date.AddMonths(CurStart, -1), '
                f'Cur = Table.RowCount(Table.SelectRows(Source, each [Date of visit] <> null and [Date of visit] >= CurStart and [Date of visit] <= Date.EndOfMonth(Last))), '
                f'Prev = Table.RowCount(Table.SelectRows(Source, each [Date of visit] <> null and [Date of visit] >= PrevStart and [Date of visit] < CurStart)), '
                f'Result = if Last = null or Prev = 0 then null else (Cur - Prev) / Prev in Result'),
             m_inline=('let Last = List.Max(Values("Date of visit")), CurStart = Date.StartOfMonth(Last), PrevStart = Date.AddMonths(CurStart, -1), '
                       'Cur = CountIf(each [Date of visit] <> null and [Date of visit] >= CurStart and [Date of visit] <= Date.EndOfMonth(Last)), '
                       'Prev = CountIf(each [Date of visit] <> null and [Date of visit] >= PrevStart and [Date of visit] < CurStart) '
                       'in if Last = null or Prev = 0 then null else (Cur - Prev) / Prev'))

    # ------------------------------------------------------------------ B. Priority & Condition
    c = 'Priority & Condition'
    k_count('emerg', c, 'Emergency Referrals', 'Referrals with Referral Priority = Emergency.', E)
    k_ratio('emerg_rate', c, 'Emergency Referral Rate %', 'Emergency Referrals \u00f7 Total Referrals.', E, T)
    k_count('routine', c, 'Routine Referrals', 'Referrals with Referral Priority = Routine.', R)
    k_count('unstable', c, 'Unstable on Arrival', 'Referrals where Condition on Arrival = Unstable.', U)
    k_ratio('unstable_rate', c, 'Unstable on Arrival Rate %', 'Unstable on Arrival \u00f7 Total Referrals.', U, T)
    k_count('critical', c, 'Critical Cases (Emergency and Unstable)', 'Emergency referrals that also arrived Unstable - the highest-risk group.', E + U)
    k_ratio('critical_rate', c, 'Critical Case Rate %', 'Critical Cases \u00f7 Total Referrals.', E + U, T)
    k_ratio('unstable_emerg', c, 'Unstable Share of Emergencies %', 'Of all Emergency referrals, the share that arrived Unstable.', E + U, E)
    k_count('anomaly', c, 'Scan Anomalies Detected', 'Referrals with Any anomaly in scan = Yes.', [(ANOM, '=', 'Yes')])
    k_ratio('anomaly_rate', c, 'Scan Anomaly Rate %', 'Scan Anomalies Detected \u00f7 Total Referrals.', [(ANOM, '=', 'Yes')], T)

    # ------------------------------------------------------------------ C. Patient Profile
    c = 'Patient Profile'
    k_avg('age_avg', c, 'Average Maternal Age (yrs)', 'Mean age of referred women (per referral record).', AGE)

    def py_median(c, v):
        s = c.d[AGE].dropna()
        return float(statistics.median(s.astype(float).tolist())) if len(s) else UND
    k_custom('age_med', c, 'Median Maternal Age (yrs)', 'Middle value of maternal age - less sensitive to extreme ages than the average.', 'dec1',
             xl=f'=IFERROR(MEDIAN(IF(({XFLAG}=1)*({xcol(AGE)}<>""),{xcol(AGE)})),"{UND}")', array=True,
             py=py_median,
             dax=f'MEDIAN ( {dcol(AGE)} )',
             m=f'let Source = {DT}, Result = List.Median(List.RemoveNulls(Source[Age])) in Result',
             m_inline='List.Median(Values("Age"))')
    k_count('teen', c, 'Teenage Pregnancies (under 20)', 'Referrals where maternal Age is below 20 years.', [(AGE, '<', 20)])
    k_ratio('teen_rate', c, 'Teenage Pregnancy Rate %', 'Teenage Pregnancies \u00f7 Total Referrals.', [(AGE, '<', 20)], T)
    k_count('ama', c, 'Advanced Maternal Age Cases (35+)', 'Referrals where maternal Age is 35 years or older.', [(AGE, '>=', 35)])
    k_ratio('ama_rate', c, 'Advanced Maternal Age Rate %', 'Advanced Maternal Age Cases \u00f7 Total Referrals.', [(AGE, '>=', 35)], T)
    k_avg('ga_avg', c, 'Average Gestational Age (wks)', 'Mean Gestational Age (weeks) recorded at the referral visit.', GA)
    k_ratio('tri1', c, 'First-Trimester Referral Rate %', 'Share of referrals made at 13 weeks of gestation or earlier.', [(GA, '<=', 13)], T)
    k_ratio('tri3', c, 'Third-Trimester Referral Rate %', 'Share of referrals made at 28 weeks of gestation or later.', [(GA, '>=', 28)], T)
    k_avg('visit_avg', c, 'Average Visit Number at Referral', 'Mean of Number of visit - how many visits a woman had made when she was referred.', NVIS, fmt='dec2')
    k_ratio('first_visit', c, 'Referred at First Visit %', 'Share of referrals made at the very first visit (Number of visit = 1).', [(NVIS, '=', 1)], T)
    k_ratio('anc4', c, 'Four or More Visits Rate %', 'Share of referrals where the woman had already made 4 or more visits (ANC4+ proxy).', [(NVIS, '>=', 4)], T)

    def py_days(c, v):
        both = c.vis.notna() & c.enr.notna()
        if not both.any():
            return UND
        return float((c.vis[both] - c.enr[both]).mean())
    both_xl = f'({XFLAG}=1)*({xcol(VIS)}<>"")*({xcol(ENR)}<>"")'
    k_custom('days_avg', c, 'Avg Days from Enrollment to Referral', 'Mean number of days between Date of Enrollment and Date of visit (records with both dates).', 'dec1',
             xl=f'=IFERROR(SUMPRODUCT({both_xl}*({xcol(VIS)}-{xcol(ENR)}))/SUMPRODUCT({both_xl}),"{UND}")',
             py=py_days,
             dax=(f'AVERAGEX ( FILTER ( {DT}, NOT ISBLANK ( {dcol(ENR)} ) && NOT ISBLANK ( {dcol(VIS)} ) ), INT ( {dcol(VIS)} - {dcol(ENR)} ) )'),
             m=(f'let Source = {DT}, Both = Table.SelectRows(Source, each [Date of visit] <> null and [Date of Enrollment] <> null), '
                f'Days = List.Transform(Table.ToRecords(Both), each Duration.Days([Date of visit] - [Date of Enrollment])), '
                f'Result = List.Average(Days) in Result'),
             m_inline=('let Both = Table.SelectRows(Source, each [Date of visit] <> null and [Date of Enrollment] <> null), '
                       'Days = List.Transform(Table.ToRecords(Both), each Duration.Days([Date of visit] - [Date of Enrollment])) in List.Average(Days)'))
    LOSS = [(HIST, 'in', ['Still Birth', 'Miscarriage', 'Neonatal Death'])]
    k_ratio('loss_hist', c, 'Previous Pregnancy Loss History %', 'Share of referrals where Previous history is Still Birth, Miscarriage or Neonatal Death.', LOSS, T)

    # ------------------------------------------------------------------ D. Reasons for Referral
    c = 'Reasons for Referral'
    k_count('pph', c, 'PPH Referrals', 'Referrals where Reason of Referral = PPH-Post Partum Hemorrhage.', [(REAS, '=', PPH)])
    k_ratio('pph_share', c, 'PPH Share %', 'PPH Referrals \u00f7 Total Referrals.', [(REAS, '=', PPH)], T)
    HTN = [(REAS, 'in', ['Preeclampsia', 'Eclampsia'])]
    k_count('htn', c, 'Hypertensive Disorder Referrals', 'Referrals for Preeclampsia or Eclampsia.', HTN)
    k_ratio('htn_share', c, 'Hypertensive Disorder Share %', 'Hypertensive Disorder Referrals \u00f7 Total Referrals.', HTN, T)
    k_ratio('anemia_share', c, 'Severe Anemia Share %', 'Referrals for Severe Anemia \u00f7 Total Referrals.', [(REAS, '=', 'Severe Anemia')], T)
    k_ratio('obstructed_share', c, 'Obstructed Labor Share %', 'Referrals for Obstructed Labor \u00f7 Total Referrals.', [(REAS, '=', 'Obstructed Labor')], T)
    k_ratio('sepsis_share', c, 'Sepsis Share %', 'Referrals for Sepsis \u00f7 Total Referrals.', [(REAS, '=', 'Sepsis')], T)
    HAEM = [(REAS, 'in', [PPH, 'Placenta Abruptio', 'Placenta Previa', 'Uterine Rupture'])]
    k_ratio('haem_share', c, 'Obstetric Haemorrhage Share %', 'Referrals for bleeding-related causes (PPH, Placenta Abruptio, Placenta Previa, Uterine Rupture) \u00f7 Total Referrals.', HAEM, T)
    k_count('rupture', c, 'Uterine Rupture Cases', 'Referrals where Reason of Referral = Uterine Rupture (sentinel event).', [(REAS, '=', 'Uterine Rupture')])
    k_top('top_reason', c, 'Top Reason of Referral', 'The most frequent Reason of Referral.', REAS, 'c_TopReason', L.REASONS)

    # ------------------------------------------------------------------ E. Patient Acceptance
    c = 'Patient Acceptance'
    k_count('accepted', c, 'Referrals Accepted by Patient', 'Referrals where Referral Accepted = Yes (the woman / family agreed to go).', Y)
    k_ratio('accept_rate', c, 'Referral Acceptance Rate %', 'Referrals Accepted by Patient \u00f7 Total Referrals.', Y, T)
    k_count('refused', c, 'Patient Refusals', 'Referrals where Referral Accepted = No.', N)
    k_ratio('refuse_rate', c, 'Patient Refusal Rate %', 'Patient Refusals \u00f7 Total Referrals.', N, T)
    k_ratio('emerg_accept', c, 'Emergency Acceptance Rate %', 'Of Emergency referrals, the share accepted by the patient.', E + Y, E)
    k_ratio('routine_accept', c, 'Routine Acceptance Rate %', 'Of Routine referrals, the share accepted by the patient.', R + Y, R)
    k_ratio('fin_share', c, 'Financial Constraint Share of Refusals %', 'Of all Patient Refusals, the share where Reason for refusal = Financial Constraint.',
            N + [(RREF, '=', 'Financial Constraint')], N)
    k_top('top_refusal', c, 'Top Reason for Patient Refusal', 'The most frequent Reason for refusal among patients who declined the referral.', RREF,
          'c_TopRefusalReason', L.REFUSAL_REASONS)

    # ------------------------------------------------------------------ F. Facility Response
    c = 'Facility Response'
    k_count('hf_ref', c, 'HF Refusals', 'Referrals where Refusal from HF = Yes (the health facility turned the patient away).', HF)
    k_ratio('hf_ref_rate', c, 'HF Refusal Rate %', 'HF Refusals \u00f7 Referrals Accepted by Patient (only patients who agreed to go can be refused by a facility).', HF, Y)
    k_ratio('bed_share', c, 'Bed Occupancy Share of HF Refusals %', 'Of all HF Refusals, the share where Reason of facility refusal = Bed occupancy.',
            HF + [(HFREAS, '=', 'Bed occupancy')], HF)
    k_top('top_hf_reason', c, 'Top Reason of Facility Refusal', 'The most frequent Reason of facility refusal.', HFREAS, 'c_TopHFReason', L.HF_REASONS)
    EFF = Y + [(HFR, '=', 'No')]
    k_ratio('effective_rate', c, 'Effective Referral Rate %', 'Referrals accepted by the patient AND not refused by the facility \u00f7 Total Referrals.', EFF, T)

    # ------------------------------------------------------------------ G. Outcomes
    c = 'Outcomes'
    k_count('completed', c, 'Completed Referrals', 'Referrals where Referral Status = Completed.', DONE)
    k_ratio('completion_rate', c, 'Referral Completion Rate %', 'Completed Referrals \u00f7 Total Referrals (headline outcome indicator).', DONE, T)
    k_count('partial', c, 'Partially Completed Referrals', 'Referrals where Referral Status = Partial Complete.', [(STAT, '=', 'Partial Complete')])
    k_count('incomplete', c, 'Incomplete Referrals', 'Referrals where Referral Status = Incomplete.', [(STAT, '=', 'Incomplete')])
    k_ratio('incomplete_rate', c, 'Incomplete Referral Rate %', 'Incomplete Referrals \u00f7 Total Referrals.', [(STAT, '=', 'Incomplete')], T)
    k_ratio('completion_accepted', c, 'Completion Rate among Accepted %', 'Of referrals the patient accepted, the share that ended Completed.', Y + DONE, Y)
    k_ratio('emerg_completion', c, 'Emergency Completion Rate %', 'Of Emergency referrals, the share that ended Completed.', E + DONE, E)
    k_ratio('routine_completion', c, 'Routine Completion Rate %', 'Of Routine referrals, the share that ended Completed.', R + DONE, R)
    k_ratio('unstable_completion', c, 'Unstable Patient Completion Rate %', 'Of patients who arrived Unstable, the share whose referral ended Completed.', U + DONE, U)

    # ------------------------------------------------------------------ H. Operations
    c = 'Operations'
    for key, sh in (('morning', 'Morning'), ('evening', 'Evening'), ('night', 'Night')):
        k_ratio(key, c, f'{sh} Shift Share %', f'Referrals made in the {sh} shift \u00f7 Total Referrals.', [(SHIFT, '=', sh)], T)
    NIGHT = [(SHIFT, '=', 'Night')]
    k_ratio('night_emerg', c, 'Night Shift Emergency Rate %', 'Of referrals made in the Night shift, the share that were Emergency.', NIGHT + E, NIGHT)
    k_top('top_staff', c, 'Top Referring Staff', 'Staff member with the most referrals.', STAFF, 'c_TopStaff', L.STAFF)
    k_top('top_facility', c, 'Top Receiving Facility', 'Health facility that received the most referrals.', FAC, 'c_TopFacility', L.FACILITIES)

    def py_topshare(c, v):
        if not c.n:
            return UND
        counts = c.d[FAC].value_counts()
        return max([int(counts.get(f, 0)) for f in L.FACILITIES] + [0]) / c.n
    k_custom('top_fac_share', c, 'Top Facility Share %', 'Referrals sent to the busiest facility \u00f7 Total Referrals (concentration of referral load).', 'pct',
             xl=f'=IFERROR(c_TopFacilityCount/c_Total,"{UND}")',
             py=py_topshare,
             dax=(f'VAR _t = ADDCOLUMNS ( FILTER ( VALUES ( {dcol(FAC)} ), NOT ISBLANK ( {dcol(FAC)} ) ), "@Referrals", CALCULATE ( COUNTROWS ( {DT} ) ) ) '
                  f'RETURN DIVIDE ( MAXX ( _t, [@Referrals] ), COUNTROWS ( {DT} ) )'),
             m=(f'let Source = {DT}, Grouped = Table.Group(Table.SelectRows(Source, each [Referred facility] <> null), {{"Referred facility"}}, '
                f'{{{{"Referrals", each Table.RowCount(_), Int64.Type}}}}), '
                f'Result = if Table.IsEmpty(Grouped) then null else List.Max(Grouped[Referrals]) / Table.RowCount(Source) in Result'),
             m_inline=('let Grouped = Table.Group(Table.SelectRows(Source, each [Referred facility] <> null), {"Referred facility"}, '
                       '{{"Referrals", each Table.RowCount(_), Int64.Type}}) in if Table.IsEmpty(Grouped) then null else List.Max(Grouped[Referrals]) / Total'))
    k_top('top_site', c, 'Top Site by Volume', 'Site with the most referrals.', SITE, 'c_TopSite', L.SITES)

    # ------------------------------------------------------------------ I. Data Quality
    c = 'Data Quality'
    def py_dq_dates(c, v):
        both = c.vis.notna() & c.enr.notna()
        return int((both & (c.vis < c.enr)).sum())
    k_custom('dq_dates', c, 'Records with Date Errors', 'Records where Date of visit is earlier than Date of Enrollment (both dates filled in). Should always be 0.', 'int',
             xl=f'=SUMPRODUCT(({XFLAG}=1)*({xcol(VIS)}<>"")*({xcol(ENR)}<>"")*({xcol(VIS)}<{xcol(ENR)}))',
             py=py_dq_dates,
             dax=(f'COUNTROWS ( FILTER ( {DT}, NOT ISBLANK ( {dcol(VIS)} ) && NOT ISBLANK ( {dcol(ENR)} ) && {dcol(VIS)} < {dcol(ENR)} ) ) + 0'),
             m=(f'let Source = {DT}, Result = Table.RowCount(Table.SelectRows(Source, each [Date of visit] <> null and [Date of Enrollment] <> null '
                f'and [Date of visit] < [Date of Enrollment])) in Result'),
             m_inline='CountIf(each [Date of visit] <> null and [Date of Enrollment] <> null and [Date of visit] < [Date of Enrollment])')

    def py_missing(c, v):
        d = c.d
        a = ((d[ACC] == 'No') & d[RREF].isna()).sum()
        b = ((d[HFR] == 'Yes') & d[HFREAS].isna()).sum()
        return int(a + b)
    k_custom('dq_missing', c, 'Refusals Missing a Reason', 'Patient refusals without a Reason for refusal plus HF refusals without a Reason of facility refusal. Should always be 0.', 'int',
             xl=f'=COUNTIFS({XFLAG},1,{xcol(ACC)},"No",{xcol(RREF)},"")+COUNTIFS({XFLAG},1,{xcol(HFR)},"Yes",{xcol(HFREAS)},"")',
             py=py_missing,
             dax=(f'COUNTROWS ( FILTER ( {DT}, ( {dcol(ACC)} = "No" && ISBLANK ( {dcol(RREF)} ) ) || ( {dcol(HFR)} = "Yes" && ISBLANK ( {dcol(HFREAS)} ) ) ) ) + 0'),
             m=(f'let Source = {DT}, Result = Table.RowCount(Table.SelectRows(Source, each ([Referral Accepted] = "No" and [Reason for refusal] = null) '
                f'or ([Refusal from HF] = "Yes" and [Reason of facility refusal] = null))) in Result'),
             m_inline=('CountIf(each ([Referral Accepted] = "No" and [Reason for refusal] = null) or ([Refusal from HF] = "Yes" and [Reason of facility refusal] = null))'))
    KEYF = [AGE, SITE, VIS, PRI, COND, REAS, ACC, STAT]
    k_custom('dq_blank', c, 'Records Missing Key Fields',
             'Records where Age, Site, Date of visit, Referral Priority, Condition on Arrival, Reason of Referral, Referral Accepted or Referral Status is empty. '
             'Should always be 0.', 'int',
             xl='=SUMPRODUCT((' + XFLAG + '=1)*((' + '+'.join(f'({xcol(f)}="")' for f in KEYF) + ')>0))',
             py=lambda c, v: int(c.d[KEYF].isna().any(axis=1).sum()),
             dax=f'COUNTROWS ( FILTER ( {DT}, ' + ' || '.join(f'ISBLANK ( {dcol(f)} )' for f in KEYF) + ' ) ) + 0',
             m=f'let Source = {DT}, Result = Table.RowCount(Table.SelectRows(Source, each ' + ' or '.join(f'{mfield(f)} = null' for f in KEYF) + ')) in Result',
             m_inline='CountIf(each ' + ' or '.join(f'{mfield(f)} = null' for f in KEYF) + ')')
    return list(KPIS)


FMT_DAX = {'int': '#,0', 'pct': '0.0%', 'dec1': '0.0', 'dec2': '0.00', 'text': 'Text'}
FMT_LABEL = {'int': 'Whole number', 'pct': 'Percentage', 'dec1': 'Decimal (1 dp)', 'dec2': 'Decimal (2 dp)', 'text': 'Text'}
